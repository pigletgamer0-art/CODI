# CODI Android · corrección del cierre al abrir

**Estado:** código fuente Android preparado para compilar; **no es un APK probado en un teléfono**.

## Por qué los APK anteriores pueden fallar

Los APK v1.5–v1.9 fueron reempaquetados y firmados a partir de un `classes.dex` antiguo y extremadamente reducido (1.304 bytes). La clase Android compilada **no coincidía con** el `MainActivity.java` que se entregaba en el proyecto. Una firma válida del APK no garantiza que el código nativo de arranque sea funcional. Además, los proyectos anteriores mencionaban `@mipmap/ic_launcher` sin aportar recursos `mipmap` para reconstruirlos.

## Qué corrige este proyecto

- Código Java nativo completo en `MainActivity.java`.
- Iconos `ic_launcher.png` en 5 densidades.
- `AndroidManifest.xml` con clase de inicio totalmente cualificada.
- Los archivos educativos se sirven desde un origen interno HTTPS estable (`appassets.androidplatform.net`) mediante `WebView.shouldInterceptRequest`, lo que facilita el almacenamiento y evita cargar HTML suelto.
- Si el proceso del WebView falla, la app muestra un aviso en vez de cerrar toda la Activity.
- La app mantiene todos los archivos de CODI dentro del paquete; no depende de Vercel para sus clases.
- El script `scripts/check_assets.py` comprueba las referencias a recursos en `index.html`.
- Flujo de GitHub Actions para compilar un APK **nuevo** con Gradle y Android SDK, no reutilizar dex ni firmas antiguas.

## Compilar y probar en Android

1. Abre la carpeta en Android Studio reciente y sincroniza Gradle.
2. Compila con JDK 17 y Android SDK 35 usando la tarea `:app:assembleDebug`, o sube el proyecto a un repositorio de GitHub y ejecuta el workflow `CODI Android CrashFix APK`.
3. Instala el APK generado por Gradle y comprueba la pantalla inicial, el test, un cuestionario y el editor.
4. Si Android vuelve a cerrarse, recopila `adb logcat -d -s AndroidRuntime:E CODI-Android:D chromium:E` para identificar la excepción exacta, ocultando nombres y datos personales antes de compartir.

**La versión CrashFix usa `cl.codi.academy.crashfix` como identificador distinto:** no reemplaza las betas anteriores ni recupera automáticamente su almacenamiento privado.

**Cuentas online:** desactivadas hasta publicar un backend persistente. La app ofrece modo invitado y permite respaldos, pero aún no sincronización en la nube.
