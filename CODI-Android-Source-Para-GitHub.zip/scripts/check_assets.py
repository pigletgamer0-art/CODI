from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
assets=root/'app/src/main/assets'
index=(assets/'index.html').read_text()
refs=re.findall(r'(?:src|href)="([^"]+)"',index)
missing=[ref for ref in refs if not ref.startswith(('http:','https:','#','data:')) and not (assets/ref).is_file()]
assert not missing, f'Missing referenced assets: {missing}'
assert (root/'app/src/main/res/mipmap-hdpi/ic_launcher.png').is_file()
assert 'WebViewAssetLoader' not in (root/'app/src/main/java/cl/codi/academy/MainActivity.java').read_text()
print(f'OK: {len(refs)} references and icon resources')
