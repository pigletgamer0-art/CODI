package cl.codi.academy;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.RenderProcessGoneDetail;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Collections;

/** CODI: a real compiled Android WebView Activity. Bundled lessons have a stable HTTPS-like origin. */
public final class MainActivity extends Activity {
    private static final String TAG = "CODI-Android";
    private static final String ASSET_ORIGIN = "https://appassets.androidplatform.net";
    private static final String START_URL = ASSET_ORIGIN + "/index.html";
    private static final int REQUEST_SAVE = 4101;
    private static final int REQUEST_OPEN = 4102;
    private WebView browser;
    private ValueCallback<Uri[]> pendingChooser;
    private String pendingExport;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 19, 33));
        getWindow().setNavigationBarColor(Color.rgb(8, 19, 33));
        openWebView();
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void openWebView() {
        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(8, 19, 33));
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportZoom(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        browser.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("https".equalsIgnoreCase(u.getScheme()) && "appassets.androidplatform.net".equalsIgnoreCase(u.getHost())) {
                    String path = u.getPath() == null ? "" : u.getPath();
                    if (path.equals("/") || path.isEmpty()) path = "/index.html";
                    if (path.indexOf("..") >= 0 || path.indexOf('\\') >= 0 || path.indexOf((char)0) >= 0) return missing();
                    try {
                        InputStream input = getAssets().open(path.substring(1));
                        return new WebResourceResponse(mime(path), "UTF-8", input);
                    } catch (Exception ex) {
                        Log.w(TAG, "Missing bundled asset: " + path);
                        return missing();
                    }
                }
                return super.shouldInterceptRequest(view, req);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("https".equalsIgnoreCase(u.getScheme()) && "appassets.androidplatform.net".equalsIgnoreCase(u.getHost())) return false;
                // Never navigate the internal WebView to untrusted pages.
                if ("https".equalsIgnoreCase(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                    catch (Exception ex) { Toast.makeText(MainActivity.this,"No se puede abrir ese enlace",Toast.LENGTH_SHORT).show(); }
                }
                return true;
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG,"WebView renderer ended. Did it crash? " + detail.didCrash());
                if (browser != null) {
                    ((android.view.ViewGroup)browser.getParent()).removeView(browser);
                    browser.destroy();
                    browser = null;
                }
                TextView note = new TextView(MainActivity.this);
                note.setGravity(Gravity.CENTER);
                note.setPadding(30,30,30,30);
                note.setTextColor(Color.WHITE);
                note.setBackgroundColor(Color.rgb(8,19,33));
                note.setText("El motor de Android cerró la página. Abre CODI nuevamente o actualiza Android System WebView.");
                setContentView(note);
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingChooser != null) pendingChooser.onReceiveValue(null);
                pendingChooser = callback;
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.setType("application/json");
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(pick, "Importar respaldo CODI"), REQUEST_OPEN);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    pendingChooser.onReceiveValue(null);
                    pendingChooser = null;
                    return false;
                }
            }
        });
        browser.addJavascriptInterface(new DownloadBridge(), "CODIAndroid");
        setContentView(browser);
        browser.loadUrl(START_URL);
    }
    private static WebResourceResponse missing() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", Collections.emptyMap(),
                new ByteArrayInputStream("Asset missing".getBytes(StandardCharsets.UTF_8)));
    }
    private static String mime(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".json") || p.endsWith(".webmanifest")) return "application/json";
        if (p.endsWith(".html")) return "text/html";
        return "application/octet-stream";
    }
    public final class DownloadBridge {
        @JavascriptInterface public void saveText(String fileName, String mime, String body) {
            runOnUiThread(() -> {
                pendingExport = body;
                try {
                    Intent out = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    out.setType(mime == null || mime.isEmpty() ? "text/plain" : mime.split(";")[0]);
                    out.addCategory(Intent.CATEGORY_OPENABLE);
                    out.putExtra(Intent.EXTRA_TITLE, (fileName == null ? "CODI.txt" : fileName).replaceAll("[/\\\\]","_"));
                    startActivityForResult(out, REQUEST_SAVE);
                } catch (Exception ex) {
                    pendingExport = null;
                    Toast.makeText(MainActivity.this, "Error al elegir destino", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request == REQUEST_OPEN) {
            ValueCallback<Uri[]> cb=pendingChooser;
            pendingChooser=null;
            if (cb != null) cb.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null ? new Uri[]{data.getData()} : null);
        }
        if (request == REQUEST_SAVE) {
            if (result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingExport!=null) {
                try(OutputStream output=getContentResolver().openOutputStream(data.getData())) {
                    if(output!=null) output.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Respaldo guardado",Toast.LENGTH_SHORT).show();
                } catch(Exception ex) { Toast.makeText(this,"Error al guardar",Toast.LENGTH_LONG).show(); }
            }
            pendingExport=null;
        }
    }
    @Override public void onBackPressed() {
        if(browser!=null&&browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(browser!=null) {browser.destroy();browser=null;}
        super.onDestroy();
    }
}
