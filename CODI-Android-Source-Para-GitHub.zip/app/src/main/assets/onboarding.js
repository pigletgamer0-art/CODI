/* CODI 1.8: introducción, diagnóstico y avatar propios. Sin cuentas ni servicios de terceros. */
'use strict';
(function(root){
 const KEY='codi-onboarding-profile-v18';
 const choices={
  track:[['web','🌐','Páginas y apps web','HTML, CSS y JavaScript'],['roblox','🎮','Juegos de Roblox','Luau y Roblox Studio'],['minecraft','⛏️','Add-ons de Minecraft','Minecraft Bedrock'],['python','🐍','Programas con Python','Automatización y lógica'],['javascript','⚡','JavaScript','Interfaces y aplicaciones']],
  purpose:[['game','🎮','Crear un juego'],['app','📱','Crear una aplicación'],['website','🌐','Crear una página web'],['mods','🧱','Crear mods o add-ons'],['automate','🤖','Automatizar tareas'],['explore','💡','Explorar programación']],
  skin:['#f5d7b6','#e7bb8d','#b98660','#885939','#583b2a'],
  hair:['short','curly','spiky','long','bob','none'],
  hairColor:['#2c2432','#72432a','#c59646','#e1c8a0','#875eaa','#39afc3'],
  shirt:['#53dca6','#5d96f1','#ef9d56','#c990f2','#eb738c','#f2d65b'],
  accessory:['none','glasses','headphones','star'],
  expression:['happy','curious','wink']
 };
 const basic=[
  ['¿Qué es una variable?',['Un dato guardado con un nombre','Un tipo de pantalla','Una carpeta en el computador'],0,'Una variable permite guardar un valor para utilizarlo después.'],
  ['¿Qué hace un bucle?',['Repite instrucciones','Borra los archivos','Cambia el idioma del teléfono'],0,'Un bucle repite un bloque de instrucciones.']
 ];
 const banks={
  web:[
   ['¿Cuál etiqueta crea el título principal de una página?',['<h1>','<p>','<div>'],0,'h1 representa un encabezado principal.'],
   ['¿Qué propiedad CSS cambia el color de fondo?',['font-size','background-color','display'],1,'background-color controla el color de fondo.'],
   ['¿Qué escucha un clic en JavaScript?',['addEventListener("click", ...)','document.remove()','console.clear()'],0,'addEventListener registra un manejador para un evento.'],
   ['¿Qué valor guarda localStorage?',['Solamente archivos ZIP','Pares clave-valor de texto','Clases CSS'],1,'localStorage almacena cadenas asociadas a claves.']
  ],
  roblox:[
   ['¿Qué palabra declara una variable local en Luau?',['let','local','const'],1,'Luau utiliza local para declarar una variable local.'],
   ['¿Dónde se ubican las partes visibles del mundo Roblox?',['workspace','ServerStorage','ReplicatedFirst'],0,'workspace contiene los objetos físicos del mundo.'],
   ['¿Qué usa un RemoteEvent para recibir en el servidor?',['OnServerEvent','Touched','RenderStepped'],0,'OnServerEvent recibe los mensajes que envían clientes.'],
   ['¿Qué debes hacer con los datos que envía un cliente?',['Confiar siempre','Validarlos en el servidor','Dar permisos de administrador'],1,'El servidor debe validar los datos y permisos.']
  ],
  minecraft:[
   ['¿Qué archivo identifica los paquetes de Bedrock?',['manifest.json','level.dat','readme.txt'],0,'Los paquetes utilizan manifest.json.'],
   ['¿Qué paquete define el comportamiento de entidades?',['Resource Pack','Behavior Pack','Shader Pack'],1,'Un behavior pack aporta definiciones de comportamiento.'],
   ['¿Qué módulo de Script API contiene world?',['@minecraft/server','@roblox/server','node:fs'],0,'world está en @minecraft/server.'],
   ['¿Qué método permite escuchar playerSpawn?',['world.afterEvents.playerSpawn.subscribe','world.spawnPlayer.add','system.emit'],0,'Se usa el evento playerSpawn y su método subscribe.']
  ],
  python:[
   ['¿Qué función muestra texto en Python?',['print()','echo()','alert()'],0,'print muestra datos en la salida estándar.'],
   ['¿Qué estructura guarda varios valores ordenados?',['list','if','def'],0,'Una lista guarda una colección ordenada de elementos.'],
   ['¿Qué hace def en Python?',['Define una función','Elimina archivos','Compara cadenas'],0,'def inicia la definición de una función.'],
   ['¿Qué produce [x*2 for x in range(3)]?',['[0, 2, 4]','[1, 2, 3]','[0, 1, 2]'],0,'La comprensión aplica x*2 a los valores 0, 1 y 2.']
  ],
  javascript:[
   ['¿Cómo declaras una constante en JavaScript?',['const','def','varconst'],0,'const crea un enlace que no puede reasignarse.'],
   ['¿Qué operador compara valor y tipo?',['==','===','=','=>'],1,'=== hace una comparación estricta.'],
   ['¿Qué devuelve [1,2,3].map(x => x*2)?',['[2,4,6]','[1,2,3]','6'],0,'map construye un arreglo con los resultados de la función.'],
   ['¿Para qué sirve await?',['Esperar el resultado de una promesa','Detener el navegador','Crear CSS'],0,'await espera una promesa dentro de un contexto válido.']
  ]
 };
 const avatarDefaults={skin:1,hair:'short',hairColor:0,shirt:0,accessory:'none',expression:'happy'};
 const blank=()=>({completed:false,alias:'',track:'web',purpose:'app',idea:'',route:'test',testAnswers:[],score:0,testResult:null,avatar:{...avatarDefaults},dailyGoal:2,createdAt:null});
 function stored(){try{const p=JSON.parse(localStorage.getItem(KEY)||'null');if(p&&p.completed&&typeof p.alias==='string')return {...blank(),...p,avatar:{...avatarDefaults,...p.avatar}}}catch{}return null}
 let profile=stored();
 let draft=blank(),stage='welcome',questionIndex=0,selectedAnswer=null,feedback=null,editOnly=false,keepExisting=false,visible=false;
 const h=v=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
 const img=id=>root.CODI_IMAGES?.[id]||'assets/'+id;
 function makeAvatar(a=avatarDefaults,size='normal'){
  const skin=choices.skin[a.skin]||choices.skin[1],shirt=choices.shirt[a.shirt]||choices.shirt[0],hair=choices.hairColor[a.hairColor]||choices.hairColor[0];
  const hairShapes={
   short:'<path d="M51 83Q45 43 88 40Q129 39 128 83L117 75Q108 57 97 65L80 64L57 81Z"/>',
   curly:'<circle cx="58" cy="69" r="16"/><circle cx="72" cy="53" r="18"/><circle cx="94" cy="50" r="20"/><circle cx="116" cy="57" r="18"/><circle cx="126" cy="77" r="12"/>',
   spiky:'<path d="M53 84L42 50L63 58L65 31L84 51L102 26L110 49L131 35L127 83L112 72L93 67L75 71Z"/>',
   long:'<path d="M53 83Q44 44 89 40Q129 37 132 84L137 131L119 137L113 79Q90 62 67 78L63 135L44 134Z"/>',
   bob:'<path d="M46 92Q41 38 90 40Q137 42 137 89L126 108L116 104L119 77Q93 60 63 78L65 106L50 108Z"/>',
   none:''
  };
  const eyes=a.expression==='wink'?'<path d="M73 93h15"/><circle cx="108" cy="94" r="3"/>':a.expression==='curious'?'<circle cx="77" cy="94" r="4"/><circle cx="107" cy="92" r="5"/>':'<path d="M71 95q7-9 14 0M99 95q7-9 14 0"/>';
  const mouth=a.expression==='curious'?'<circle cx="94" cy="113" r="5" fill="#733f48"/>':'<path d="M84 113q11 12 22 0"/>';
  const extras=a.accessory==='glasses'?'<g fill="none" stroke="#2d4057" stroke-width="5"><rect x="62" y="85" width="26" height="22" rx="8"/><rect x="98" y="85" width="26" height="22" rx="8"/><path d="M88 94h10"/></g>':a.accessory==='headphones'?'<g fill="none" stroke="#222e58" stroke-width="10"><path d="M48 93Q45 32 94 33Q144 33 140 92"/></g><rect x="41" y="79" width="17" height="36" rx="8" fill="#6f8bef"/><rect x="130" y="79" width="17" height="36" rx="8" fill="#6f8bef"/>':a.accessory==='star'?'<path d="M123 43l5 10 11 2-8 8 1 11-9-5-10 5 2-11-8-8 11-2Z" fill="#f4d671" stroke="#bb882f" stroke-width="2"/>':'';
  const bg=a.shirt%2===0?'#203b54':'#332c54';
  return `<svg class="onb-avatar-svg ${size==='small'?'small':''}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 190 205" role="img" aria-label="Tu avatar personalizado"><rect x="5" y="5" width="180" height="195" rx="36" fill="${bg}"/><circle cx="95" cy="103" r="81" fill="#ffffff0b"/><path d="M17 196Q16 145 68 139L93 151L121 139Q177 151 173 196Z" fill="${shirt}" stroke="#ffffff1e" stroke-width="4"/><rect x="85" y="133" width="21" height="28" rx="11" fill="${skin}"/><ellipse cx="93" cy="95" rx="47" ry="54" fill="${skin}"/><path d="${a.hair==='none'?'':'M0 0'}" fill="none"/><g fill="${hair}">${hairShapes[a.hair]||''}</g><g fill="none" stroke="#443039" stroke-width="4" stroke-linecap="round">${eyes}${mouth}</g>${extras}<circle cx="38" cy="38" r="5" fill="#75f3c4"/><circle cx="159" cy="160" r="5" fill="#75f3c4"/></svg>`;
 }
 function testSet(){return [...basic,...banks[draft.track]].map((r,i)=>({prompt:r[0],options:r[1],answer:r[2],why:r[3],rank:i<2?'fundamentos':i<4?'intermedio':'avanzado'}))}
 function scoreResult(){const total=testSet().length,correct=draft.testAnswers.filter(a=>a.ok).length;const level=correct>=5?'advanced':correct>=3?'some':'beginner';return {correct,total,level,percent:Math.round(correct/total*100),start:level==='advanced'?4:level==='some'?2:0};}
 function progressIndex(){return stage==='test'?Math.min(4,Math.max(1,questionIndex)):[...['welcome','track','purpose','method','result','avatar','account','finish']].indexOf(stage)}
 function top(){return `<div class="onb-top"><div class="onb-logo"><img src="${img('badge.webp')}" alt=""/><span>CODI <small>ACADEMY</small></span></div><button type="button" class="onb-dismiss" data-ob="close" aria-label="Salir de la configuración">${editOnly?'✕':'↩'}</button></div><div class="onb-progress" aria-hidden="true"><span style="width:${Math.min(100,Math.max(5,(progressIndex()+1)/8*100))}%"></span></div>`}
 function header(title,subtitle,comp='codi'){return `<div class="onb-heading"><img class="onb-mentor" src="${img(comp==='codi'?'reaction-saludando.webp':`avatar-${comp}.webp`)}" alt="${comp==='codi'?'CODI':comp} te acompaña"/><div><span class="eyebrow">TU AVENTURA EMPIEZA AQUÍ</span><h1>${title}</h1><p>${subtitle}</p></div></div>`}
 function button(label,next,disabled=false){return `<button type="button" class="onb-primary" data-ob="${next}" ${disabled?'disabled':''}>${label} <span aria-hidden="true">→</span></button>`}
 const goalName=(track,purpose)=>{
  const labels={web:'una página web interactiva',roblox:'un juego de Roblox',minecraft:'un add-on de Minecraft Bedrock',python:'un programa en Python',javascript:'una aplicación en JavaScript'};
  const purposes={game:'con mecánicas y desafíos',app:'con una interfaz útil',website:'para mostrar información',mods:'que amplíe un juego',automate:'que automatice tareas',explore:'para practicar lo aprendido'};
  return `Quiero crear ${labels[track]} ${purposes[purpose]}`;
 };
 function option(kind,list,selected){return `<div class="onb-choice-list">${list.map(([val,emoji,name,detail])=>`<button type="button" class="onb-choice ${selected===val?'selected':''}" data-ob-value="${h(kind)}" data-ob-key="${h(val)}" aria-pressed="${selected===val}"><span class="onb-choice-icon">${emoji}</span><span><strong>${h(name)}</strong>${detail?`<small>${h(detail)}</small>`:''}</span><b>${selected===val?'✓':'○'}</b></button>`).join('')}</div>`}
 function screen(){switch(stage){
  case 'welcome':return `${header('¡Hola! Soy CODI 👋','Voy a ayudarte a aprender a programar desde tu primer proyecto.')}
  <div class="onb-welcome-icons"><span>🧩 Lecciones jugables</span><span>💻 Código real</span><span>🕹️ Tu personaje</span></div>
  ${button('¡Empezar!', 'next')}${root.CodeQuestApp?.state.projects.length?'<button class="onb-text-button" data-ob="existing">Ya tengo avances: conservar mis cursos</button>':''}<p class="onb-small">CODI funciona sin Premium, sin anuncios y sin conectarse a IA externa.</p>`;
  case 'track':return `${header('¿Qué quieres aprender primero?','Puedes añadir otros cursos cuando quieras.','lumina')}${option('track',choices.track,draft.track)}${button('Continuar','next')}`;
  case 'purpose':return `${header('¿Para qué quieres programar?','Construiremos una ruta según lo que quieras conseguir.','nexa')}${option('purpose',choices.purpose,draft.purpose)}<label class="onb-label" for="ob-idea">Tu idea (opcional)</label><textarea id="ob-idea" maxlength="180" rows="2" placeholder="Por ejemplo, un juego donde todos sobreviven a desastres">${h(draft.idea)}</textarea>${button('Continuar','next')}`;
  case 'method':return `${header('¿Cuánto sabes de programación?','Puedes empezar desde cero o descubrir tu nivel con una prueba.','bita')}<div class="onb-choice-list"><button type="button" class="onb-choice" data-ob="fromzero"><span class="onb-choice-icon">🌱</span><span><strong>Empezar desde cero</strong><small>No necesitas saber nada.</small></span><b>→</b></button><button type="button" class="onb-choice" data-ob="taketest"><span class="onb-choice-icon">🎯</span><span><strong>Descubrir mi nivel</strong><small>6 preguntas · Sin corazones ni castigos.</small></span><b>→</b></button></div><p class="onb-small">Puedes volver a repasar cualquier lección después.</p>`;
  case 'test':{
   const q=testSet()[questionIndex],answer=feedback;
   return `${header('Prueba de nivel',`Pregunta ${questionIndex+1} de ${testSet().length} · ${q.rank}`,questionIndex>3?'buggo':'bita')}<div class="onb-test-track"><i style="width:${(questionIndex+1)/testSet().length*100}%"></i></div><h2 class="onb-question">${h(q.prompt)}</h2><div class="onb-choice-list">${q.options.map((txt,i)=>`<button class="onb-choice ${selectedAnswer===i?'selected':''} ${answer?(i===q.answer?'right':selectedAnswer===i?'wrong':''):''}" data-ob-answer="${i}" ${answer?'disabled':''} aria-pressed="${selectedAnswer===i}"><span class="onb-choice-icon">${String.fromCharCode(65+i)}</span><strong>${h(txt)}</strong><b>${answer&&i===q.answer?'✓':selectedAnswer===i?'●':'○'}</b></button>`).join('')}</div>${answer?`<div class="onb-feedback ${answer.ok?'right':'wrong'}" role="status"><strong>${answer.ok?'¡Correcto!':'Aprendiste algo nuevo'}</strong><p>${h(q.why)}</p></div>${button(questionIndex===testSet().length-1?'Ver mi resultado':'Siguiente pregunta','testnext')}`:button('Comprobar','testcheck',selectedAnswer===null)}<button type="button" class="onb-text-button" data-ob="skiptest">Prefiero empezar desde cero</button>`;
  }
  case 'result':{
   const r=draft.testResult||scoreResult();const label={beginner:'Fundamentos',some:'Conocimientos iniciales',advanced:'Conocimientos avanzados'}[r.level];
   return `${header(draft.route==='test'?'¡Ya tenemos tu diagnóstico!':'¡Todos empezamos por algún lugar!','CODI preparará tu camino. Puedes volver a las primeras lecciones cuando quieras.','rush')}<div class="onb-result"><span>🎯 Nivel recomendado</span><strong>${label}</strong><p>${draft.route==='test'?`${r.correct} de ${r.total} respuestas correctas (${r.percent}%).`:'Empezarás con las bases, paso a paso.'}</p><p class="onb-small">Es una orientación inicial, no un certificado. Puedes mejorarla practicando.</p></div>${button('Crear mi avatar','next')}`;
  }
  case 'avatar':return `${header('¡Crea tu personaje!','Elige su aspecto. Aparecerá en tu perfil de CODI.','codi')}<div class="onb-avatar-editor"><div class="onb-avatar-stage">${makeAvatar(draft.avatar)}<small>Tu personaje en el mundo de CODI</small></div><div class="onb-avatar-controls">${avatarGroup('skin','Tono de piel',choices.skin,'color')}${avatarGroup('hair','Peinado',choices.hair,'text')}${avatarGroup('hairColor','Color de cabello',choices.hairColor,'color')}${avatarGroup('shirt','Ropa',choices.shirt,'color')}${avatarGroup('accessory','Accesorios',choices.accessory,'text')}${avatarGroup('expression','Expresión',choices.expression,'text')}</div></div>${button('Me gusta mi avatar','next')}`;
  case 'account':return `${header('Crea tu perfil CODI','Tu nombre y tu personaje se guardan solamente en este dispositivo.','codi')}<div class="onb-account-card">${makeAvatar(draft.avatar,'small')}<div><label class="onb-label" for="ob-alias">¿Cómo quieres que te llamen?</label><input id="ob-alias" type="text" autocomplete="nickname" maxlength="18" placeholder="Tu apodo" value="${h(draft.alias)}"/><p class="onb-small">Usa un apodo. No necesitas correo, contraseña ni dar datos personales.</p></div></div><div class="onb-goal-choice"><strong>🎯 Meta diaria</strong><div role="group" aria-label="Lecciones por día">${[1,2,3,4,5].map(x=>`<button type="button" data-ob-goal="${x}" class="${draft.dailyGoal===x?'active':''}" aria-pressed="${draft.dailyGoal===x}">${x}</button>`).join('')}</div></div><p class="onb-error" id="ob-error" role="alert"></p>${button(editOnly?'Guardar cambios':'Crear mi perfil local','finish')}`;
  case 'finish':return `${header(`¡Bienvenido${draft.alias?' a CODI, '+h(draft.alias):' a CODI'}!`,'Tu avatar y tu ruta están listos para comenzar.','rush')}<div class="onb-finished">${makeAvatar(draft.avatar)}<div><strong>${h(draft.alias)}</strong><p>🎯 ${h({beginner:'Fundamentos',some:'Inicial-intermedio',advanced:'Avanzado'}[draft.testResult?.level||'beginner'])}</p><p>🔥 ${draft.dailyGoal} ${draft.dailyGoal===1?'lección':'lecciones'} al día</p></div></div>${button('¡Ir a mi primera lección!','enter')}<p class="onb-small">Tus avances se quedan en este dispositivo. Puedes exportarlos como respaldo.</p>`;
 }return ''}
 function avatarGroup(key,title,values,kind){const txt={short:'Corto',curly:'Rizado',spiky:'Puntas',long:'Largo',bob:'Media melena',none:'Sin pelo',glasses:'Lentes',headphones:'Audífonos',star:'Estrella',happy:'Feliz',curious:'Curioso',wink:'Guiño'};
  return `<div class="onb-avatar-group"><strong>${title}</strong><div>${values.map((v,i)=>{const value=kind==='color'?i:v,active=draft.avatar[key]===value;return `<button type="button" class="onb-avatar-option ${active?'chosen':''}" data-ob-avatar="${key}" data-ob-avatar-value="${h(value)}" aria-label="${h(txt[v]||title+' '+(i+1))}" aria-pressed="${active}" title="${h(txt[v]||title+' '+(i+1))}">${kind==='color'?`<i style="background:${v}"></i>`:h(txt[v]||v)}</button>`}).join('')}</div></div>`}
 function render(){const host=document.querySelector('#codi-onboarding');if(!host||!visible)return;host.hidden=false;host.innerHTML=`<div class="onb-shell">${top()}<div class="onb-body">${screen()}</div></div>`;host.scrollTop=0}
 function storageSave(){try{localStorage.setItem(KEY,JSON.stringify(profile))}catch{root.CodeQuestApp?.toast('El dispositivo no permite guardar este perfil; exporta un respaldo.')};updateHeader();root.CODIAccount?.schedule()}
 function show(edit=false){editOnly=edit;keepExisting=edit;draft=edit&&profile?{...blank(),...profile,avatar:{...profile.avatar}}:blank();stage=edit?'avatar':'welcome';questionIndex=0;selectedAnswer=null;feedback=null;visible=true;const overlay=document.getElementById('codi-onboarding');overlay.hidden=false;document.body.classList.add('onb-active');document.querySelector('.app-shell')?.setAttribute('inert','');document.querySelector('.mobile-tabs')?.setAttribute('inert','');document.querySelector('.codi-companion')?.setAttribute('inert','');render();setTimeout(()=>overlay.querySelector('[data-ob="close"]')?.focus(),0)}
 function hide(){visible=false;const host=document.getElementById('codi-onboarding');if(host){host.hidden=true;host.innerHTML=''}document.body.classList.remove('onb-active');document.querySelector('.app-shell')?.removeAttribute('inert');document.querySelector('.mobile-tabs')?.removeAttribute('inert');document.querySelector('.codi-companion')?.removeAttribute('inert')}
 function finish(){const input=document.getElementById('ob-alias');if(input)draft.alias=input.value.trim();if(draft.alias.length<2){document.getElementById('ob-error').textContent='Escribe un apodo de al menos 2 caracteres.';input?.focus();return}
  const hasProject=root.CodeQuestApp?.state.projects.length>0;
  const r=(editOnly?profile?.placement:draft.testResult)||{level:'beginner',start:0,correct:0,total:6,percent:0};
  profile={completed:true,alias:draft.alias.slice(0,18),avatar:{...draft.avatar},dailyGoal:draft.dailyGoal,track:draft.track,purpose:draft.purpose,placement:{...r},createdAt:profile?.createdAt||new Date().toISOString()};storageSave();
  root.CODINavigation?.setGoal?.(draft.dailyGoal);
  if(!editOnly&&!keepExisting&&!hasProject){root.CodeQuestApp?.beginOnboardCourse(goalName(draft.track,draft.purpose)+(draft.idea?' — '+draft.idea.trim():''),draft.idea.trim()||'Aprender haciendo proyectos',draft.track,r.level,r.start)}
  if(editOnly){hide();root.CodeQuestApp?.navigate('profile');return}
  stage='finish';render();
 }
 function advance(){const steps=['welcome','track','purpose','method','result','avatar','account','finish'];if(stage==='purpose'){const el=document.querySelector('#ob-idea');if(el)draft.idea=el.value.trim()}if(stage==='account'){finish();return}if(stage==='result'){stage='avatar'}else{const i=steps.indexOf(stage);stage=steps[Math.min(i+1,steps.length-1)]}render()}
 function back(){if(editOnly){if(stage==='account')stage='avatar';else hide();render();return}const prev={track:'welcome',purpose:'track',method:'purpose',test:'method',result:'method',avatar:'result',account:'avatar',finish:'account'};if(stage==='welcome')hide();else{stage=prev[stage]||'welcome';if(stage==='method')feedback=null;render()}}
 document.addEventListener('click',event=>{
  const host=event.target.closest('#codi-onboarding');const open=event.target.closest('[data-onboard-edit]');if(open){event.preventDefault();show(true);return}if(!host)return;
  const choice=event.target.closest('[data-ob-value]');if(choice){const type=choice.dataset.obValue,key=choice.dataset.obKey;if(type==='track'&&choices.track.some(x=>x[0]===key))draft.track=key;if(type==='purpose'&&choices.purpose.some(x=>x[0]===key))draft.purpose=key;render();return}
  const a=event.target.closest('[data-ob-avatar]');if(a){const key=a.dataset.obAvatar,val=a.dataset.obAvatarValue,values=choices[key];if(!values)return;const parsed=['skin','hairColor','shirt'].includes(key)?Number(val):val;if(values.includes(parsed)||Number.isInteger(parsed)&&parsed>=0&&parsed<values.length)draft.avatar[key]=parsed;render();return}
  const pick=event.target.closest('[data-ob-answer]');if(pick&&!feedback){selectedAnswer=Number(pick.dataset.obAnswer);render();return}
  const goal=event.target.closest('[data-ob-goal]');if(goal){draft.dailyGoal=Number(goal.dataset.obGoal);render();return}
  const btn=event.target.closest('[data-ob]');if(!btn)return;switch(btn.dataset.ob){
   case 'close':back();break;case 'next':advance();break;case 'fromzero':draft.route='zero';draft.testResult={level:'beginner',start:0,correct:0,total:6,percent:0};stage='result';render();break;
   case 'taketest':draft.route='test';draft.testAnswers=[];questionIndex=0;selectedAnswer=null;feedback=null;stage='test';render();break;
   case 'skiptest':draft.route='zero';draft.testResult={level:'beginner',start:0,correct:0,total:6,percent:0};stage='result';render();break;
   case 'testcheck':{const q=testSet()[questionIndex];if(selectedAnswer===null)return;feedback={ok:selectedAnswer===q.answer};draft.testAnswers.push({question:questionIndex,choice:selectedAnswer,ok:feedback.ok});render();break}
   case 'testnext':if(questionIndex+1>=testSet().length){draft.testResult=scoreResult();stage='result'}else{questionIndex++;selectedAnswer=null;feedback=null}render();break;
   case 'existing':if(root.CodeQuestApp?.state.projects.length){keepExisting=true;stage='avatar'}else stage='account';render();break;
   case 'finish':finish();break;case 'enter':hide();root.CodeQuestApp?.navigate('route');break;
  }
 });
 document.addEventListener('input',event=>{if(event.target.id==='ob-idea')draft.idea=event.target.value;if(event.target.id==='ob-alias')draft.alias=event.target.value});
 document.addEventListener('keydown',event=>{if(!visible)return;if(event.key==='Escape'){event.preventDefault();back()}});
 function updateHeader(){const head=document.querySelector('.topbar .avatar');if(!head||!profile)return;head.innerHTML=makeAvatar(profile.avatar,'small');head.title='Perfil de '+profile.alias;head.setAttribute('aria-label','Avatar de '+profile.alias)}
 function profileHero(){if(!profile)return '';return `<div class="onb-profile-card"><div class="onb-profile-portrait">${makeAvatar(profile.avatar,'small')}</div><div><span class="eyebrow">TU AVATAR</span><h2>${h(profile.alias)}</h2><p>🎯 ${h({beginner:'Fundamentos',some:'Inicial-intermedio',advanced:'Avanzado'}[profile.placement?.level||'beginner'])} · ${profile.dailyGoal} lecciones por día</p><p class="onb-small">${root.CODIAccount?.connected?'Tu avatar se guarda con tu cuenta CODI.':'Sin cuenta conectada: guarda un respaldo para conservarlo.'}</p><button class="secondary" type="button" data-onboard-edit>✏️ Editar mi avatar y perfil</button></div></div>`}
 function exportData(){return profile?JSON.parse(JSON.stringify(profile)):null}
 function importData(value){if(!value||typeof value!=='object'||value.completed!==true||typeof value.alias!=='string'||value.alias.length<2||value.alias.length>18)return false;profile={completed:true,alias:value.alias,avatar:{...avatarDefaults},dailyGoal:[1,2,3,4,5].includes(Number(value.dailyGoal))?Number(value.dailyGoal):2,track:choices.track.some(x=>x[0]===value.track)?value.track:'web',purpose:choices.purpose.some(x=>x[0]===value.purpose)?value.purpose:'app',placement:value.placement&&['beginner','some','advanced'].includes(value.placement.level)?value.placement:{level:'beginner',start:0},createdAt:value.createdAt||null};for(const k of Object.keys(avatarDefaults)){const v=value.avatar?.[k];const list=choices[k];if(list&&(['skin','hairColor','shirt'].includes(k)?Number.isInteger(v)&&v>=0&&v<list.length:list.includes(v)))profile.avatar[k]=v}storageSave();return true}
 root.CODIOnboarding={start:show,hide,get profile(){return profile},get stage(){return stage},profileHero,avatarSvg:makeAvatar,refresh:updateHeader,exportData,importData};
 document.addEventListener('DOMContentLoaded',()=>{if(profile)updateHeader();else show(false)});
})(window);
