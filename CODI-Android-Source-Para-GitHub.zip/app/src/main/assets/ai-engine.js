/* CodeQuest IA v0.4: clasificador probabilístico entrenable + tutor con recuperación local.
   100% escrito desde cero, sin llamadas de red, librerías de ML, servicios o LLM. */
(function(root){
'use strict';
const STORAGE='codequest-local-ai-v3';
const expert=root.CodeQuestExpert;
const seed={
 tracks:{
  roblox:['quiero crear un juego de roblox','crear un obby en roblox studio','simulador con personajes y monedas en luau','un tycoon con puertas y tienda de roblox','quiero scripts lua para mi experiencia roblox','hacer un mapa de roblox con jugadores','un juego de persecucion en roblox studio','programar en luau y usar workspace','una aventura con npc en roblox','rondas de desastres naturales en roblox'],
  minecraft:['un addon para minecraft bedrock','crear mod en bedrock con mobs y items','behavior pack para minecraft','crear un bloque personalizado con minecraft','crear un mcpack para el movil','un mod de transformaciones de criaturas en minecraft','quiero un resource pack minecraft','usar la script api de minecraft bedrock','desarrollar un addon de crafting en minecraft','crear biomas para el end de minecraft'],
  web:['quiero crear una pagina web con html y css','hacer sitio web de recetas','crear una tienda online con carrito','quiero una app web de restaurante','hacer una pagina con formularios y botones','desarrollar una web para mi proyecto','crear un portfolio para mostrar fotos','una plataforma de aprendizaje en el navegador','sitio web con interfaz para celular','hacer una pagina de inicio de sesion html'],
  python:['hacer un script en python','programar un bot de discord en python','automatizar tareas con python','leer archivos csv usando python','analizar datos de un archivo con python','programa de consola para gestionar tareas','crear un juego de texto con python','quiero practicar print input y funciones python','hacer una calculadora en python','un programa que renombre archivos automaticamente'],
  javascript:['hacer un juego con javascript','programar en javascript con arrays','una calculadora con funciones de javascript','crear un bot en node js','hacer app electron con javascript','ejecutar codigo de node','usar promesas y async en javascript','programar una aplicacion en js','aprender variables funciones y eventos de javascript','hacer un script en javascript']
 },
 intents:{
  explain:['explicame este concepto','que significa esta variable','no entiendo la leccion','como funciona este codigo','para que sirve esto','dime el significado','explica con palabras sencillas'],
  hint:['dame una pista','ayudame con el ejercicio','necesito una pequeña ayuda','estoy atascado','no se como continuar el codigo','una sugerencia sin darme la respuesta','orientame en esta tarea'],
  next:['cual es el siguiente paso','que debo hacer despues','que sigue ahora','como continuo mi proyecto','cual es mi proxima mision','ya termine que viene'],
  debug:['mi codigo tiene un error','no me funciona el programa','aparece un bug','como arreglo el fallo','el codigo falla','el programa no corre','la consola muestra un error'],
  test:['como puedo probar','como se comprueba si funciona','donde ejecuto el codigo','quiero hacer pruebas','como hago una prueba real','como verifico mi script'],
  example:['dame un ejemplo de codigo','muestrame un ejemplo','quiero ver un ejemplo practico','enseñame codigo que lo haga','puedes mostrarme la sintaxis','ponme un ejemplo sencillo'],
  simplify:['explicalo mas facil','puedes hacerlo mas sencillo','no entiendo nada','explica como para principiante','quiero pasos mas pequeños','mas lento por favor'],
  features:['que funciones puedo agregar','quiero ideas para mi proyecto','que mecanicas deberia tener','que caracteristicas puedo crear','como mejorar mi idea','dame funciones nuevas'],
  plan:['hazme un plan','divide mi proyecto en pasos','quiero crear una app','como empiezo desde cero','organiza la construccion','crea una ruta personalizada']
 }
};
const stop=new Set('a al algo ante bajo cada como con contra cual cuales de del desde donde el ella en entre era es esa ese esto esta estas estos fue ha hacer hasta hay la las le les lo los mas me mi mis no o para pero por porque que quien se sea ser si sin sobre su sus te tu tus un una uno unos unas y ya yo quiero necesito puedo puedes puedes'.split(' '));
const normalize=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/node\s*\.\s*js/g,'nodejs').replace(/add[ -]?on/g,'addon').replace(/[^a-z0-9ñ]+/g,' ').trim();
function tokens(text){const terms=normalize(text).split(/\s+/).filter(w=>w.length>1&&!stop.has(w));const features=[...terms];for(let i=0;i<terms.length-1;i++)features.push(terms[i]+'_'+terms[i+1]);return features}
function newModel(labels){return {labels:Object.keys(labels),samples:{},wordCounts:{},totals:{},docs:{}}}
function teach(model,category,text,weight=1){if(!model.labels.includes(category))return false;const words=tokens(String(text).slice(0,500));if(!words.length)return false;model.docs[category]=(model.docs[category]||0)+weight;model.wordCounts[category]||={};for(const word of words){model.wordCounts[category][word]=(model.wordCounts[category][word]||0)+weight;model.totals[category]=(model.totals[category]||0)+weight}return true}
function trainBase(labels){const model=newModel(labels);for(const [key,examples] of Object.entries(labels))for(const s of examples)teach(model,key,s);return model}
function predict(model,text){const words=tokens(text);if(!words.length)return {label:null,confidence:0,ranked:[]};const classes=model.labels;const totalDocs=classes.reduce((s,c)=>s+(model.docs[c]||0),0);const vocab=new Set();for(const c of classes)for(const w in model.wordCounts[c]||{})vocab.add(w);const V=Math.max(1,vocab.size),scores=classes.map(c=>{let score=Math.log(((model.docs[c]||0)+1)/(totalDocs+classes.length));for(const w of words){const hits=(model.wordCounts[c]||{})[w]||0;score+=Math.log((hits+0.6)/((model.totals[c]||0)+0.6*V))}return {label:c,score}});const max=Math.max(...scores.map(a=>a.score));let sum=0;for(const s of scores){s.prob=Math.exp(s.score-max);sum+=s.prob}for(const s of scores)s.confidence=s.prob/sum;scores.sort((a,b)=>b.confidence-a.confidence);return {label:scores[0].label,confidence:scores[0].confidence,ranked:scores.map(x=>({label:x.label,confidence:x.confidence}))}}
function examples(goal,track){const s=normalize(goal),features=[];
 if(/restaurant|restaurante|comida|pedido|cocina|mesero|menu/.test(s))features.push('catálogo o menú','pedidos','estado de preparación');
 if(/auto|coche|carro|conduc|vehic|camion/.test(s))features.push('movimiento','controles','colisiones');
 if(/juego|obby|aventura|superviv|surviv|ronda/.test(s))features.push('reglas del juego','puntuación','reinicio de partida');
 if(/tienda|shop|vender|compr/.test(s))features.push('productos','carrito','confirmación de compra simulada');
 if(/mod|addon|mob|bloque|minecraft/.test(s))features.push('contenido personalizado','recursos','pruebas en Bedrock');
 if(/curso|aprender|duolingo|leccion|educa/.test(s))features.push('lecciones','preguntas','seguimiento del progreso');
 if(/chat|mensaj|social/.test(s))features.push('mensajes','usuarios de prueba','historial local');
 if(/bot|automat/.test(s))features.push('comandos','respuestas','manejo de errores');
 if(/musica|sonido|cancion/.test(s))features.push('reproducción de sonido','controles','lista de pistas');
 const generic={web:['pantalla principal','evento de botón','datos guardados'],roblox:['mapa básico','una interacción','prueba con jugador'],minecraft:['manifest.json','un contenido nuevo','prueba en Bedrock'],python:['entrada de datos','función principal','mensaje de salida'],javascript:['datos','función principal','resultado visible']}[track]||['pantalla','funciones','pruebas'];return [...new Set([...features,...generic])].slice(0,6)}
function createPlan(goal,purpose,track,level){const feats=examples(`${goal} ${purpose}`,track);const complexity=level==='advanced'?'Incluye validaciones y casos difíciles.':level==='some'?'Conecta dos funciones simples.':'Empieza con un ejemplo mínimo que puedas completar.';return [
 {name:'1 · Define tu versión mínima',description:`Objetivo: ${goal}. Para qué: ${purpose||'aprender y crear algo útil'}. Elige una sola acción que deba funcionar. ${complexity}`},
 {name:'2 · Construye la base',description:`Crea ${feats[0]} y ${feats[1]||'la interacción principal'}. Prueba cada cambio pequeño antes de seguir.`},
 {name:'3 · Añade funciones',description:`Incorpora ${feats.slice(2,4).join(' y ')||'una función extra'}. Comprueba entradas válidas e inválidas.`},
 {name:'4 · Prueba tu proyecto',description:`Prueba ${feats[0]} en el entorno real de ${track}. Comprueba que nada se rompa con distintos datos.`},
 {name:'5 · Mejora y comparte',description:`Prioriza ${feats.slice(4).join(' y ')||'la facilidad de uso y los errores'}. Documenta cómo abrirlo y qué falta.`}
 ]}
const safeStorage={get(){try{const raw=JSON.parse(localStorage.getItem(STORAGE));return raw&&raw.version===3?raw:null}catch{return null}},put(v){try{localStorage.setItem(STORAGE,JSON.stringify(v))}catch{}}};
let memory=safeStorage.get()||{version:3,trackExamples:[],intentExamples:[],attempts:{},likes:0,corrections:0};
function modelWithExamples(group,arr){const m=trainBase(seed[group]);for(const e of arr.slice(-200)){if(e&&typeof e.text==='string'&&Object.hasOwn(seed[group],e.label))teach(m,e.label,e.text,2)}return m}
let trackModel=modelWithExamples('tracks',memory.trackExamples),intentModel=modelWithExamples('intents',memory.intentExamples);
function teachExample(group,text,label){if(!Object.hasOwn(seed[group]||{},label))return false;const key=group==='tracks'?'trackExamples':'intentExamples';memory[key].push({text:String(text).slice(0,500),label});memory[key]=memory[key].slice(-200);if(group==='tracks')trackModel=modelWithExamples('tracks',memory[key]);else intentModel=modelWithExamples('intents',memory[key]);memory.corrections++;safeStorage.put(memory);return true}
function track(text){const match=[...memory.trackExamples].reverse().find(e=>normalize(e.text)===normalize(text));if(match)return {label:match.label,confidence:1,source:'corrección aprendida'};const result=predict(trackModel,text);const normalized=normalize(text); // Datos inequívocos de plataformas conservan prioridad.
 const strong=[['roblox',/\broblox\b|\bluau\b|\bobby\b|\bworkspace\b/],['minecraft',/\bminecraft\b|\bbedrock\b|\bmcpack\b|\bbehavior pack\b/],['python',/\bpython\b|\bdiscord bot\b/],['javascript',/\bjavascript\b|\bnodejs\b|\belectron\b/],['web',/\bhtml\b|\bcss\b|\bpagina web\b|\bsitio web\b|\bweb\b/]];for(const [name,re] of strong)if(re.test(normalized))return {label:name,confidence:1,source:'plataforma explícita'};return {...result,source:'clasificador local'}}
function intent(text){const match=[...memory.intentExamples].reverse().find(e=>normalize(e.text)===normalize(text));if(match)return {label:match.label,confidence:1,source:'corrección aprendida'};const result=predict(intentModel,text);return {...result,source:'clasificador local'}}
function recordAttempt(lessonId,correct){const key=String(lessonId||'').slice(0,60);if(!key)return;const s=memory.attempts[key]||{ok:0,fail:0};if(correct)s.ok++;else s.fail++;memory.attempts[key]=s;safeStorage.put(memory)}
function ability(lessonId){const a=memory.attempts[String(lessonId||'')]||{ok:0,fail:0};return a.fail>a.ok+1?'refuerzo':a.ok>2?'avance':'normal'}
function tutor(question,ctx={}){const p=ctx.project,l=ctx.lesson;const predicted=intent(question);
 const detectedDomain=track(question);
 const domain=p?.track||(detectedDomain.source==='plataforma explícita'?detectedDomain.label:'all');
 const coached=expert?.coach(question,domain,predicted.label==='example'?'example':predicted.label==='hint'?'hint':'explain');
 // Si la pregunta coincide con un tema documentado, usamos conocimiento concreto,
 // no una respuesta inventada a partir de un clasificador poco confiable.
 if(coached&&coached.score>=2.4&&(!/leccion actual|siguiente paso|que sigue|mi proyecto/.test(normalize(question)))){
   return {text:coached.answer+(coached.related.length?'\n\nTemas relacionados: '+coached.related.join(' · '):'')+'\n\nContenido local revisable. Verifica la compatibilidad de versiones y prueba en el entorno real.',intent:predicted.label,confidence:predicted.confidence,topic:coached.topic};
 }
 if(!p)return {text:'Puedo explicar conceptos, dar ejemplos y revisar código sin conexión. Prueba: «¿Qué es async/await en JavaScript?», «¿Cómo validar RemoteEvents en Roblox?» o «¿Qué necesita el manifest de Bedrock?». Para un plan personalizado, primero crea tu proyecto.',intent:predicted.label,confidence:predicted.confidence};
 const lesson=l||p.lessons.find(x=>!p.completed.includes(x.id))||p.lessons[0],name=lesson?.title||'tu próximo paso',obj=lesson?.objective||'hacer una función pequeña',hint=lesson?.hint||'Divide el problema en pasos pequeños.',detail=lesson?.explanation||'Practica un concepto cada vez.',code=lesson?.example||'',features=examples(p.goal,p.track),progress=p.completed.length+'/'+p.lessons.length,mode=ability(lesson?.id);
 const wrap=(text)=>({text, intent:predicted.label,confidence:predicted.confidence});
 // Ante incertidumbre se reconoce el límite y se responde con contexto sin fingir entendimiento.
 if(predicted.confidence<0.25)return wrap(`No estoy seguro de haber entendido la pregunta. Soy una IA pequeña entrenada con ejemplos locales, no un modelo de lenguaje general.\n\nSobre «${p.goal}» puedes preguntarme: «explícame ${name}», «dame una pista», «cómo pruebo el código» o «qué hago después».`);
 switch(predicted.label){
 case 'explain':return wrap(`Vamos por partes con «${name}».\n\n${detail}\n\nTu objetivo es ${obj}. Relaciónalo con «${p.goal}»: añade una función pequeña y comprueba el resultado. ${mode==='refuerzo'?'Como tuviste dificultades, empieza copiando un ejemplo pequeño y cambiando una sola línea.':''}`);
 case 'hint':return wrap(`Pista para «${name}»: ${hint}\n\nHaz solo el primer cambio. No necesitas escribir todo el proyecto hoy. ${mode==='refuerzo'?'Ve paso a paso: revisa la explicación antes de intentar otra vez.':''}`);
 case 'next':return wrap(`Llevas ${progress} lecciones. Tu siguiente paso es «${name}»: ${obj}.\n\nCuando lo completes, comprueba esa funcionalidad en tu proyecto «${p.goal}».`);
 case 'debug':return wrap(`Para revisar «${p.goal}»:\n1. Copia el mensaje exacto del error.\n2. Comprueba nombres y signos en «${name}».\n3. Cambia una sola cosa y ejecuta de nuevo.\n4. Prueba el resultado en el entorno real: el verificador interno solo busca partes del texto.\n\nPista: ${hint}`);
 case 'test':return wrap(`Haz una prueba corta de «${p.goal}»: comprueba una entrada válida, una inválida y repite la acción.\n\n${{roblox:'En Roblox Studio usa Play y Output.',minecraft:'En Minecraft Bedrock usa un mundo de prueba y el registro de contenido.',web:'En Web abre una vista previa y la consola del navegador.',python:'Ejecuta el archivo .py en Python.',javascript:'Ejecuta en el navegador o Node.js, según tu proyecto.'}[p.track]||'Usa el entorno de ejecución real.'}\n\nLa app no ejecuta directamente Roblox, Bedrock ni Python.`);
 case 'example':return wrap(`Ejemplo para «${name}» (${p.track}):\n\n${code}\n\nPrueba cambiando un valor o un nombre, y comprueba qué sucede. Es un ejemplo educativo, no necesariamente un proyecto final instalable.`);
 case 'simplify':return wrap(`Versión más sencilla:\n1. Lee el objetivo: ${obj}.\n2. Observa un ejemplo pequeño: ${code.split('\n').slice(0,2).join(' ')}\n3. Modifica una sola línea.\n4. Pulsa «Comprobar código».\n\nSi algo falla, vuelve a la pista: ${hint}`);
 case 'features':return wrap(`Para «${p.goal}», detecté estas piezas posibles:\n${features.map((s,i)=>`${i+1}. ${s}`).join('\n')}\n\nEmpieza con una sola, y añade las demás después de probarla.`);
 case 'plan':return wrap(`Plan para «${p.goal}»:\n${createPlan(p.goal,p.purpose,p.track,p.level).map(x=>`${x.name}: ${x.description}`).join('\n')}\n\nEmpieza con «${name}».`);
 default:return wrap(`Puedo ayudarte con «${name}». Pregúntame por un ejemplo, pista, prueba, siguiente paso o plan.`);
 }
}
function like(){memory.likes++;safeStorage.put(memory)}
function exportMemory(){return JSON.parse(JSON.stringify(memory))}
function importMemory(data){if(!data||data.version!==3||!Array.isArray(data.trackExamples)||!Array.isArray(data.intentExamples))return false;memory={version:3,trackExamples:data.trackExamples.filter(e=>e&&typeof e.text==='string'&&Object.hasOwn(seed.tracks,e.label)).slice(-200).map(e=>({text:e.text.slice(0,500),label:e.label})),intentExamples:data.intentExamples.filter(e=>e&&typeof e.text==='string'&&Object.hasOwn(seed.intents,e.label)).slice(-200).map(e=>({text:e.text.slice(0,500),label:e.label})),attempts:{},likes:Math.max(0,Math.min(10000,Number(data.likes)||0)),corrections:Math.max(0,Math.min(10000,Number(data.corrections)||0))};trackModel=modelWithExamples('tracks',memory.trackExamples);intentModel=modelWithExamples('intents',memory.intentExamples);safeStorage.put(memory);return true}
root.CodeQuestAI=Object.freeze({track,intent,tutor,createPlan,features:examples,teachTrack:(text,label)=>teachExample('tracks',text,label),teachIntent:(text,label)=>teachExample('intents',text,label),recordAttempt,ability,like,exportMemory,importMemory,intentLabels:Object.freeze({explain:'Explicación',hint:'Pista',next:'Siguiente paso',debug:'Depuración',test:'Pruebas',example:'Ejemplo',simplify:'Más simple',features:'Ideas de funciones',plan:'Plan de proyecto'})});
})(typeof window!=='undefined'?window:globalThis);
