/* CodeQuest Academy v0.5 — navegación educativa, práctica y taller, 100% local. */
(function (root) {
  'use strict';
  const STORE = 'codequest-academy-v05';
  const dateKey = () => { const d = new Date(); return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-'); };
  const safe = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const levels = [
    {min:0,name:'Aprendiz',symbol:'🌱'}, {min:200,name:'Explorador',symbol:'🧭'},
    {min:600,name:'Constructor',symbol:'🧱'}, {min:1200,name:'Ingeniero',symbol:'⚙️'},
    {min:2500,name:'Maestro',symbol:'🏆'}, {min:4000,name:'Arquitecto',symbol:'👑'}
  ];
  const avatars = [{id:'C',name:'Código',min:0},{id:'⚡',name:'Rayo',min:150},{id:'🧠',name:'Cerebro',min:500},{id:'🚀',name:'Cohete',min:1200},{id:'👑',name:'Corona',min:2500}];
  const templates = {
    web: {name:'Mi aplicación web',emoji:'🌐',description:'Web interactiva con datos que se conservan en tu navegador',files:[
      {name:'index.html',location:'Carpeta raíz',content:'<!doctype html>\n<html lang="es">\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Mi aplicación</title><link rel="stylesheet" href="styles.css"></head>\n<body>\n<main><h1>Mi lista</h1><form id="form"><label for="tarea">Nueva tarea</label><input id="tarea" required><button>Añadir</button></form><ul id="lista"></ul></main>\n<script src="app.js" defer></script></body></html>'},
      {name:'styles.css',location:'Carpeta raíz',content:'* { box-sizing: border-box; }\nbody { font: 16px system-ui; background: #f1f5f9; padding: 28px; color: #142033; }\nmain { max-width: 560px; margin: 0 auto; padding: 24px; border-radius: 18px; background: white; }\nform { display: flex; flex-wrap: wrap; gap: 10px; }\ninput { padding: 10px; flex: 1; }\nbutton { background: #15765b; color: white; border: 0; padding: 11px 16px; border-radius: 8px; }\nli { margin: 12px 0; }'},
      {name:'app.js',location:'Carpeta raíz',content:'"use strict";\nconst form = document.querySelector("#form");\nconst input = document.querySelector("#tarea");\nconst list = document.querySelector("#lista");\nlet tareas = [];\ntry { const saved = JSON.parse(localStorage.getItem("tareas")); if (Array.isArray(saved)) tareas = saved.filter(x => typeof x === "string"); } catch {}\nfunction dibujar() {\n  list.replaceChildren();\n  tareas.forEach((texto, indice) => {\n    const li = document.createElement("li");\n    const boton = document.createElement("button"); boton.type = "button"; boton.textContent = "Quitar";\n    boton.addEventListener("click", () => { tareas.splice(indice,1); guardar(); });\n    li.append(document.createTextNode(texto+" "),boton); list.append(li);\n  });\n}\nfunction guardar() { localStorage.setItem("tareas",JSON.stringify(tareas)); dibujar(); }\nform.addEventListener("submit", e => { e.preventDefault(); const texto = input.value.trim(); if (!texto) return; tareas.push(texto); input.value = ""; guardar(); });\ndibujar();'}
    ]},
    roblox: {name:'Juego de rondas',emoji:'🎮',description:'Un ciclo de rondas en el servidor y estado visible para todos',files:[
      {name:'RoundManager.server.lua',location:'ServerScriptService → Script',content:'-- Coloca este Script en ServerScriptService\nlocal ReplicatedStorage = game:GetService("ReplicatedStorage")\nlocal status = ReplicatedStorage:FindFirstChild("EstadoRonda")\nif not status then\n  status = Instance.new("StringValue")\n  status.Name = "EstadoRonda"\n  status.Parent = ReplicatedStorage\nend\nlocal function countdown(segundos, fase)\n  for t = segundos, 1, -1 do\n    status.Value = fase .. ": " .. t\n    task.wait(1)\n  end\nend\nwhile true do\n  countdown(10, "Intermedio")\n  countdown(30, "Ronda")\n  status.Value = "Fin de ronda"\n  task.wait(3)\nend'},
      {name:'RoundUI.client.lua',location:'StarterPlayer → StarterPlayerScripts → LocalScript',content:'-- Coloca este LocalScript en StarterPlayerScripts\nlocal Players = game:GetService("Players")\nlocal ReplicatedStorage = game:GetService("ReplicatedStorage")\nlocal state = ReplicatedStorage:WaitForChild("EstadoRonda")\nlocal gui = Instance.new("ScreenGui")\ngui.Name = "RoundHud"\ngui.ResetOnSpawn = false\ngui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")\nlocal label = Instance.new("TextLabel")\nlabel.Size = UDim2.new(0, 300, 0, 44)\nlabel.Position = UDim2.new(0.5, -150, 0, 20)\nlabel.TextScaled = true\nlabel.BackgroundColor3 = Color3.fromRGB(20,30,45)\nlabel.TextColor3 = Color3.fromRGB(255,255,255)\nlabel.Parent = gui\nlocal function refresh() label.Text = state.Value end\nstate:GetPropertyChangedSignal("Value"):Connect(refresh)\nrefresh()'}
    ]},
    minecraft: {name:'Add-on de bienvenida',emoji:'⛏️',description:'Behavior Pack inicial con Script API y mensaje al aparecer',files:[
      {name:'manifest.json',location:'Behavior Pack → manifest.json',content:'{\n  "format_version": 2,\n  "header": {"name": "CODI Bienvenida", "description":"Add-on educativo", "uuid":"__HEADER_UUID__", "version":[1,0,0], "min_engine_version":[1,21,80]},\n  "modules": [{"type":"script", "language":"javascript", "entry":"scripts/main.js", "uuid":"__MODULE_UUID__", "version":[1,0,0]}],\n  "dependencies": [{"module_name":"@minecraft/server", "version":"1.12.0"}]\n}'},
      {name:'main.js',location:'Behavior Pack → scripts/main.js',content:'import { world } from "@minecraft/server";\nworld.afterEvents.playerSpawn.subscribe(event => {\n  if (event.initialSpawn) {\n    event.player.sendMessage("¡Bienvenido al mundo!");\n  }\n});'}
    ]},
    python: {name:'Gestor de tareas',emoji:'🐍',description:'Aplicación de consola con lista guardada en JSON',files:[
      {name:'main.py',location:'Carpeta del proyecto',content:'import json\nfrom pathlib import Path\n\nARCHIVO = Path("tareas.json")\n\ndef cargar():\n    try:\n        datos = json.loads(ARCHIVO.read_text(encoding="utf-8"))\n        return datos if isinstance(datos, list) else []\n    except (OSError, json.JSONDecodeError):\n        return []\n\ndef guardar(tareas):\n    ARCHIVO.write_text(json.dumps(tareas, ensure_ascii=False, indent=2), encoding="utf-8")\n\ndef main():\n    tareas = cargar()\n    while True:\n        print("\\n1. Ver tareas | 2. Agregar | 3. Salir")\n        opcion = input("> ").strip()\n        if opcion == "1":\n            for i, tarea in enumerate(tareas, 1):\n                print(f"{i}. {tarea}")\n        elif opcion == "2":\n            texto = input("Nueva tarea: ").strip()\n            if texto:\n                tareas.append(texto)\n                guardar(tareas)\n        elif opcion == "3":\n            break\n\nif __name__ == "__main__":\n    main()'}
    ]},
    javascript: {name:'Biblioteca de utilidades',emoji:'⚡',description:'Funciones con pruebas automáticas usando Node.js',files:[
      {name:'utils.mjs',location:'Carpeta del proyecto',content:'export function sumar(a, b) {\n  if (!Number.isFinite(a) || !Number.isFinite(b)) throw new TypeError("Números requeridos");\n  return a + b;\n}\nexport function promedio(valores) {\n  if (!Array.isArray(valores) || valores.length === 0) throw new Error("Lista vacía");\n  return valores.reduce((a,b) => a+b,0)/valores.length;\n}'},
      {name:'utils.test.mjs',location:'Carpeta del proyecto',content:'import test from "node:test";\nimport assert from "node:assert/strict";\nimport { sumar, promedio } from "./utils.mjs";\ntest("suma", () => assert.equal(sumar(2,3),5));\ntest("promedio", () => assert.equal(promedio([2,4]),3));\ntest("número inválido", () => assert.throws(() => sumar("2",3)));'}
    ]}
  };
  const initial = () => ({version:1,practice:{},practiceDay:{},daily:{date:dateKey(),lesson:0,practice:0,ai:0},avatar:'C',studioDrafts:{},lastPractice:null});
  let academy;
  try { academy = {...initial(),...JSON.parse(localStorage.getItem(STORE) || '{}')}; } catch { academy = initial(); }
  let currentPractice = null,practiceMode='review',practiceChoice = null,practiceResponse = '', selectedTemplate='web',fileIndex=0,selectedArticle=null,libraryQuery='',libraryDomain='all';
  function ensureDay() { if (!academy.daily || academy.daily.date !== dateKey()) academy.daily={date:dateKey(),lesson:0,practice:0,ai:0}; }
  function persist() { try { localStorage.setItem(STORE, JSON.stringify(academy)); } catch {} }
  function record(kind) { ensureDay(); if (kind in academy.daily) { academy.daily[kind]++; persist(); } }
  const getLevel = xp => levels.filter(l=>xp>=l.min).at(-1);
  const nav = {home:'Inicio',route:'Aprender',practice:'Practicar',projects:'Proyectos',quests:'Desafíos',league:'Liga personal',shop:'Tienda',library:'Biblioteca',profile:'Perfil',achievements:'Logros',tutor:'Tutor CODI'};
  function api(){return root.CodeQuestApp;}
  function wrapTitle(title,lead){return `<div class="eyebrow">CODI ACADEMY · APRENDE CREANDO</div><h1 class="academy-title">${safe(title)}</h1><p class="lead">${safe(lead)}</p>`;}
  function render(view){
    const ctx=api(); if (!ctx) return '<p>Preparando la academia...</p>';
    const funcs={practice:renderPractice,projects:renderProjects,quests:root.CODIAdventure.renderQuests,league:root.CODIAdventure.renderLeague,shop:root.CODIAdventure.renderShop,achievements:root.CODIAdventure.renderAchievements,library:renderLibrary,profile:root.CODIAdventure.renderProfile};
    if(funcs[view]) { const node=document.getElementById('breadcrumb');if(node)node.textContent=nav[view];return funcs[view](ctx); }
    return '';
  }
  function practicePool(p) {
    if (!p) return [];
    const unlocked=p.lessons.filter(l=>p.completed.includes(l.id));
    if(practiceMode==='mistakes') {const errors=root.CODIAdventure.mistakes;return unlocked.filter(l=>errors[`${p.id}:${l.id}`]);}
    if(practiceMode==='challenge') return unlocked.length?unlocked:p.lessons.slice(0,1);
    return unlocked.length?unlocked:p.lessons.slice(0,1);
  }
  function renderPractice(ctx){
    const p=ctx.active();const lessons=p ? p.lessons.filter(l=>p.completed.includes(l.id)):[];
    const pool=practicePool(p);
    if (!currentPractice || !pool.some(l=>l.id===currentPractice)) currentPractice=pool[0]?.id||null;
    const l=p?.lessons.find(l=>l.id===currentPractice);

    return `${wrapTitle('Entrena tus habilidades','Repite conceptos, recibe explicaciones y gana hasta 10 XP por cada pregunta distinta que aciertes al día.')}
    <div class="practice-modes" role="group" aria-label="Modo de práctica"><button class="practice-mode ${practiceMode==='review'?'selected':''}" data-practice-mode="review">📚 Repaso</button><button class="practice-mode ${practiceMode==='mistakes'?'selected':''}" data-practice-mode="mistakes">🔁 Mis errores</button><button class="practice-mode ${practiceMode==='challenge'?'selected':''}" data-practice-mode="challenge">🎲 Aleatorio</button></div>
    <div class="academy-columns"><section class="panel">${!p?`<div class="empty-state"><strong>Primero elige qué quieres crear</strong><button class="primary" data-view="home">Crear ruta</button></div>`:
      !l?`<div class="empty-state"><strong>¡Ya corregiste tus errores!</strong><p>Cuando te equivoques en una pregunta, aparecerá aquí para repasarla.</p><button class="secondary" data-practice-mode="review">Volver al repaso</button></div>`:`<div class="space-between"><span class="info-pill">${safe(ctx.paths[p.track]?.label)}</span><span class="tiny-label">${lessons.length} aprendidas</span></div>
      <h2 class="academy-subtitle">${safe(l?.title||'Tu primera práctica')}</h2><p class="subtle">${safe(l?.objective)}</p><p class="quiz-prompt">${safe(l?.question)}</p>
      <div class="choices">${l.choices.map((c,i)=>`<button class="choice ${practiceChoice===i?'picked':''}" data-practice-choice="${i}"><span class="choice-tag">${String.fromCharCode(65+i)}</span>${safe(c)}</button>`).join('')}</div>
      <div class="actions mt-20"><button class="primary" data-academy="practice-check">Comprobar</button><button class="secondary" data-academy="practice-next">Siguiente pregunta →</button></div>
      <div class="mt-12" id="practice-feedback" aria-live="polite">${practiceResponse?safe(practiceResponse):''}</div>`}</section>
    <aside class="panel panel-accent"><h3>🧠 Repaso inteligente</h3><p class="subtle">Las preguntas vienen de lecciones de tu ruta. Si fallas, la IA muestra una explicación contextual, sin conectarse a internet.</p>
    <div class="status-note">Preguntas acertadas hoy: <strong>${academy.daily?.date===dateKey()?academy.daily.practice:0}</strong></div>
    <div class="actions mt-20"><button class="ghost" data-view="route">Volver a aprender</button></div></aside></div>`;
  }
  function chooseNextPractice(){const p=api()?.active();if(!p)return;const pool=practicePool(p);if(!pool.length)return;let idx=pool.findIndex(l=>l.id===currentPractice);currentPractice=pool[practiceMode==='challenge'&&pool.length>1?(idx+1+Math.floor(Math.random()*(pool.length-1)))%pool.length:(idx+1)%pool.length].id;practiceChoice=null;practiceResponse='';api().rerender();}
  function checkPractice(){const p=api()?.active(),l=p?.lessons.find(x=>x.id===currentPractice);if(!l)return;
    if(practiceChoice===null){practiceResponse='Selecciona una alternativa primero.';api().rerender();return;}
    const ok=practiceChoice===l.answer;root.CodeQuestAI.recordAttempt(l.id,ok);root.CODIAdventure.recordMistake(p.id,l.id,ok);
    if(ok){const key=`${dateKey()}:${p.id}:${l.id}`;const firstToday=!academy.practiceDay[key];if(firstToday) {academy.practiceDay[key]=true;api().state.xp+=10;api().markActivity();root.CODIAdventure.awardPractice(p.id,l.id,true);record('practice');api().save();} academy.practice[l.id]=(academy.practice[l.id]||0)+1;
      practiceResponse=`✓ ¡Correcto! ${l.explanation.slice(0,280)}${firstToday?' · +10 XP y +2 gemas.':' · Ya habías ganado la recompensa diaria por esta pregunta.'}`;
    }else{practiceResponse=`↻ Todavía no. ${l.explanation.slice(0,300)} Pista: ${l.hint}`;}
    persist();api().rerender();
  }
  const quests=[{id:'lesson',name:'Completa una lección',target:1,emoji:'📘'},{id:'practice',name:'Acierta dos preguntas de práctica',target:2,emoji:'🎯'},{id:'ai',name:'Pide ayuda a tu tutor',target:1,emoji:'🧠'}];
  function renderQuests(ctx){ensureDay();const completed=quests.filter(q=>academy.daily[q.id]>=q.target).length;return `${wrapTitle('Desafíos diarios','Tres pequeños objetivos para avanzar con constancia. Se reinician cada día en tu dispositivo.')}
    <div class="panel panel-accent mb-20"><div class="space-between"><h2 class="academy-subtitle">Tus misiones de hoy</h2><strong>${completed}/3 ✓</strong></div><div class="progress-track"><div class="progress-bar" style="width:${completed/3*100}%"></div></div></div>
    <div class="academy-cards">${quests.map(q=>`<div class="panel quest-card"><div class="quest-icon">${q.emoji}</div><h3>${safe(q.name)}</h3><p class="subtle">${Math.min(q.target,academy.daily[q.id])} / ${q.target}</p><div class="progress-track"><div class="progress-bar" style="width:${Math.min(100,academy.daily[q.id]/q.target*100)}%"></div></div><div class="mt-20">${academy.daily[q.id]>=q.target?'<span class="badge">✓ Completado</span>':`<button class="ghost" data-view="${q.id==='lesson'?'route':q.id==='practice'?'practice':'tutor'}">Ir a la misión →</button>`}</div></div>`).join('')}</div>
    <p class="footer-note">El conteo es local, no competitivo ni sincronizado con otros dispositivos.</p>`;}
  function renderLeague(ctx){const xp=ctx.state.xp,rank=getLevel(xp),next=levels.find(l=>l.min>xp);return `${wrapTitle('Liga de aprendizaje personal','Avanza de nivel con tu propio esfuerzo. No mostramos jugadores inventados ni rankings falsos.')}
    <div class="panel panel-accent academy-rank"><div class="rank-emblem">${rank.symbol}</div><div><div class="eyebrow">TU CATEGORÍA</div><h2 class="academy-rank-name">${rank.name}</h2><p class="subtle">${xp} XP acumulados ${next?`· Faltan ${next.min-xp} XP para ${next.name}`:'· ¡Alcanzaste el nivel más alto!'}</p></div></div>
    <div class="academy-timeline">${levels.map(l=>`<div class="tier ${xp>=l.min?'tier-unlocked':''}"><span>${l.symbol}</span><div><strong>${l.name}</strong><p class="subtle">Desde ${l.min} XP</p></div><b>${xp>=l.min?'✓':'🔒'}</b></div>`).join('')}</div>`;}
  function renderShop(ctx){return `${wrapTitle('Tienda de recompensas','Personaliza tu perfil con premios que desbloqueas aprendiendo. Aquí nunca se utiliza dinero real.')}
    <div class="academy-cards">${avatars.map(item=>{const unlocked=ctx.state.xp>=item.min,equipped=academy.avatar===item.id;return `<article class="panel cosmetic-card"><div class="cosmetic-icon">${item.id}</div><h3>${safe(item.name)}</h3><p class="subtle">${item.min} XP necesarios</p><button class="${equipped?'secondary':'primary'}" data-avatar="${safe(item.id)}" ${unlocked?'':'disabled'}>${equipped?'Equipado ✓':unlocked?'Equipar':'🔒 Bloqueado'}</button></article>`}).join('')}</div>`;}
  function renderProfile(ctx){const total=ctx.state.projects.reduce((sum,p)=>sum+p.completed.length,0),count=ctx.state.projects.length;const level=getLevel(ctx.state.xp);return `${wrapTitle('Tu perfil de programador','Tus avances se sincronizan con tu cuenta conectada. También puedes exportar un respaldo.')}
    ${root.CODIOnboarding?.profileHero()||`<div class="panel panel-accent mb-20"><div class="profile-hero"><div class="profile-avatar">${safe(academy.avatar)}</div><div><h2>Programador CODI</h2><p class="subtle">${level.symbol} ${level.name} · IA propia y aprendizaje local</p></div></div></div>`}
    <div class="academy-cards"><div class="panel stat-card"><strong>${ctx.state.xp}</strong><span>XP</span></div><div class="panel stat-card"><strong>${ctx.state.streak}</strong><span>Racha</span></div><div class="panel stat-card"><strong>${total}</strong><span>Lecciones superadas</span></div><div class="panel stat-card"><strong>${count}</strong><span>Proyectos</span></div></div>
    <div class="panel mt-20"><h3>📦 Tu información</h3><p class="subtle">Exporta un JSON de tus proyectos, lecciones y memoria del clasificador. Para restaurar, importa tu respaldo.</p><div class="actions"><button class="primary" data-action="export-progress">⬇ Exportar respaldo</button><button class="secondary" data-action="import-progress">⬆ Importar respaldo</button></div><p class="footer-note">Tienes un perfil local, no una cuenta con correo ni sincronización en la nube. No hay pagos. Si borras los datos del navegador sin respaldo, perderás el progreso.</p></div>`;}
  function libraryEntries(){return root.CodeQuestKnowledge.entries.filter(e=>(libraryDomain==='all'||e.track===libraryDomain||e.track==='all'&&libraryDomain==='fundamentals')&&`${e.title} ${e.explanation} ${e.tags}`.toLocaleLowerCase('es').includes(libraryQuery.toLocaleLowerCase('es')));}
  function renderLibrary(){const rows=libraryEntries(),entry=root.CodeQuestKnowledge.entries.find(e=>e.id===selectedArticle);return `${wrapTitle('Biblioteca de conocimientos','54 temas organizados con explicación, ejemplo, práctica, errores comunes y pruebas.')}
    <div class="academy-columns"><section><div class="panel mb-20"><label class="tiny-label" for="library-search">Buscar una habilidad</label><input class="academy-input" id="library-search" placeholder="Variables, seguridad, DataStore..." value="${safe(libraryQuery)}"><label class="tiny-label" for="library-domain">Categoría</label><select id="library-domain" class="ai-select"><option value="all">Todos los temas</option><option value="fundamentals" ${libraryDomain==='fundamentals'?'selected':''}>Fundamentos</option>${[['web','Web'],['javascript','JavaScript'],['python','Python'],['roblox','Roblox Luau'],['minecraft','Minecraft Bedrock']].map(([v,n])=>`<option value="${v}" ${libraryDomain===v?'selected':''}>${n}</option>`).join('')}</select></div><div class="library-list" id="library-list">${rows.map(e=>`<button class="library-item ${selectedArticle===e.id?'current':''}" data-article="${safe(e.id)}"><strong>${safe(e.title)}</strong><small>${safe(e.track==='all'?'Fundamentos':e.track)} · ${safe(e.practice.slice(0,75))}</small></button>`).join('')||'<p class="subtle">No se encontraron temas.</p>'}</div></section>
    <aside class="panel academy-article" id="library-article">${entry?articleMarkup(entry):'<h3>Selecciona un tema</h3><p class="subtle">En esta biblioteca encontrarás desde conceptos básicos hasta desarrollo seguro y pruebas reales.</p>'}</aside></div>`;}
  function articleMarkup(e){return `<span class="info-pill">${safe(e.track)}</span><h2>${safe(e.title)}</h2><p>${safe(e.explanation)}</p><h3>Ejemplo</h3><pre class="review-result">${safe(e.code)}</pre><h3>Practica</h3><p>${safe(e.practice)}</p><h3>Evita esto</h3><p>${safe(e.pitfall)}</p><h3>Comprueba tu resultado</h3><p>${safe(e.verify)}</p><button class="ghost" data-view="tutor">Preguntar a la IA ↗</button>`;}
  function uuid(){if(root.crypto?.randomUUID)return root.crypto.randomUUID();return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.floor(Math.random()*16);return(c==='x'?r:(r&3|8)).toString(16)});}
  const bpUuids = [uuid(),uuid()];
  function fileContent(track,index){const file=templates[track]?.files[index];if(!file)return '';const k=`${track}:${file.name}`;const original=file.content.replace('__HEADER_UUID__',bpUuids[0]).replace('__MODULE_UUID__',bpUuids[1]);return academy.studioDrafts[k]??original;}
  function renderProjects(ctx){const p=ctx.active();if(!templates[selectedTemplate])selectedTemplate=p?.track||'web';const item=templates[selectedTemplate],file=item.files[fileIndex]||item.files[0];return `${wrapTitle('Taller de proyectos','Convierte lecciones en archivos reales. Puedes modificar el código, guardar borradores y descargarlo.')}
    <div class="panel panel-accent mb-20"><span class="eyebrow">TU IDEA ${p?'ACTUAL':'FUTURA'}</span><h2 class="academy-subtitle">${safe(p?.goal||'¿Qué quieres construir?')}</h2><p class="subtle">${p?safe(p.purpose||'Construir y aprender'):'Crea una ruta para personalizar los pasos de tu proyecto.'}</p><div class="actions">${p?'<button class="secondary" data-view="route">Ver mi ruta →</button>':'<button class="primary" data-view="home">Crear ruta →</button>'}</div></div>
    <div class="panel mb-20"><h3>Elige una plantilla funcional de inicio</h3><div class="template-tabs">${Object.entries(templates).map(([id,v])=>`<button class="template-tab ${selectedTemplate===id?'selected':''}" data-template="${id}">${v.emoji} ${safe(id==='web'?'Web':id==='roblox'?'Roblox':id==='minecraft'?'Bedrock':id==='python'?'Python':'JavaScript')}</button>`).join('')}</div><h2>${safe(item.name)}</h2><p class="subtle">${safe(item.description)}. Los entornos externos deben instalarse y usarse por separado.</p></div>
    <div class="academy-columns"><section class="panel"><div class="space-between"><h3>Archivos del proyecto</h3><span class="info-pill">Editables</span></div><div class="file-tabs">${item.files.map((f,i)=>`<button data-studio-file="${i}" class="${fileIndex===i?'selected':''}">${safe(f.name)}</button>`).join('')}</div><p class="tiny-label">Ubicación: ${safe(file.location)}</p><label class="tiny-label" for="studio-code">Código editable</label><textarea class="code-editor studio-editor" id="studio-code" spellcheck="false" aria-label="Código del proyecto">${safe(fileContent(selectedTemplate,fileIndex))}</textarea><div class="actions mt-12"><button class="primary" data-academy="download-studio">⬇ Descargar este archivo</button><button class="secondary" data-academy="review-studio">🧠 Revisar código</button><button class="ghost" data-academy="reset-studio">Restaurar original</button></div><pre class="review-result mt-12" id="studio-review" aria-live="polite"></pre></section>
      <aside class="panel"><h3>5 etapas para construir</h3><ol class="step-list">${(p?root.CodeQuestAI.createPlan(p.goal,p.purpose,p.track,p.level):root.CodeQuestAI.createPlan(item.name,'aprender',selectedTemplate,'beginner')).map(s=>`<li><strong>${safe(s.name)}</strong><span>${safe(s.description)}</span></li>`).join('')}</ol><div class="inline-separator"></div><p class="subtle">Descarga cada archivo y colócalo en la ubicación indicada. En Bedrock revisa las versiones de API y registra UUID únicos. En Roblox prueba con Play y Output.</p><button class="ghost" data-view="tutor">Pedir ayuda a la IA ↗</button></aside></div>`;}
  function lessonPanel(p,l){return `<div class="panel panel-accent lesson-coach"><div class="overline">🧠 TU ENTRENADOR PERSONAL</div><h3>Aprende conmigo</h3><p class="subtle">Puedo explicar esta lección, ayudarte con errores y sugerir el siguiente paso. Mis respuestas se basan en conocimientos locales.</p>
    <div class="coach-actions"><button class="ghost" data-coach="explain">Explícame</button><button class="ghost" data-coach="hint">Una pista</button><button class="ghost" data-coach="review">Revisar código</button><button class="ghost" data-coach="next">¿Qué sigue?</button></div>
    <form id="lesson-ai-form"><label class="tiny-label" for="lesson-ai-question">Tu pregunta sobre «${safe(l.title)}»</label><textarea class="ask-field" id="lesson-ai-question" placeholder="¿Por qué tengo este error?" maxlength="1500"></textarea><button class="secondary mt-12" type="submit">Preguntar sin salir de la lección</button></form>
    <div class="coach-answer" id="lesson-ai-response" role="status" aria-live="polite">Tu tutor está listo para ayudarte durante la misión.</div></div>`;}
  function answerCoach(mode,question){const ctx=api(),l=ctx?.currentLesson(),p=ctx?.active();if(!l||!p)return;
    let answer='';const code=document.querySelector('#student-code')?.value||'';
    if(mode==='review'||/revis(a|ar)|mi c[oó]digo/i.test(question||'')){
      const r=root.CodeQuestExpert.reviewCode(code,p.track);
      const missing=l.checks.filter(x=>!code.toLowerCase().includes(x.toLowerCase()));
      answer=root.CodeQuestExpert.formatReview(r)+(missing.length?'\n\nPiezas que aún busca este ejercicio: '+missing.join(', '):'\n\nEncontré las piezas esperadas. Prueba el código en el entorno real.');
    }else{
      const prompts={explain:`Explícame ${l.title}`,hint:`Dame una pista de ${l.title}`,next:'¿Cuál es el siguiente paso?'};
      answer=root.CodeQuestAI.tutor(question||prompts[mode]||`Explícame ${l.title}`,{project:p,lesson:l}).text;
    }
    const result=document.querySelector('#lesson-ai-response');if(result){result.textContent=answer;result.scrollIntoView({block:'nearest'});}record('ai');
  }
  document.addEventListener('click',event=>{
    const btn=event.target.closest('[data-academy],[data-practice-choice],[data-practice-mode],[data-article],[data-template],[data-studio-file],[data-avatar],[data-coach]');if(!btn)return;
    if(btn.dataset.practiceMode){practiceMode=btn.dataset.practiceMode;currentPractice=null;practiceChoice=null;practiceResponse='';api().rerender();return;}
    if(btn.dataset.practiceChoice!==undefined){practiceChoice=Number(btn.dataset.practiceChoice);practiceResponse='';api().rerender();return;}
    if(btn.dataset.article){selectedArticle=btn.dataset.article;const e=root.CodeQuestKnowledge.entries.find(x=>x.id===selectedArticle);const target=document.querySelector('#library-article');if(target&&e)target.innerHTML=articleMarkup(e);document.querySelectorAll('[data-article]').forEach(b=>b.classList.toggle('current',b.dataset.article===selectedArticle));return;}
    if(btn.dataset.template){selectedTemplate=btn.dataset.template;fileIndex=0;api().rerender();return;}
    if(btn.dataset.studioFile!==undefined){fileIndex=Number(btn.dataset.studioFile);api().rerender();return;}
    if(btn.dataset.avatar){if(api().state.xp<avatars.find(x=>x.id===btn.dataset.avatar).min)return;academy.avatar=btn.dataset.avatar;persist();api().rerender();document.querySelector('.avatar').textContent=academy.avatar;return;}
    if(btn.dataset.coach){answerCoach(btn.dataset.coach);return;}
    switch(btn.dataset.academy){
      case 'practice-check':checkPractice();break;
      case 'practice-next':chooseNextPractice();break;
      case 'download-studio':{const item=templates[selectedTemplate].files[fileIndex];api().downloadText(item.name,fileContent(selectedTemplate,fileIndex));break;}
      case 'review-studio':{const result=root.CodeQuestExpert.reviewCode(fileContent(selectedTemplate,fileIndex),selectedTemplate);document.querySelector('#studio-review').textContent=root.CodeQuestExpert.formatReview(result);break;}
      case 'reset-studio':{const item=templates[selectedTemplate].files[fileIndex];delete academy.studioDrafts[`${selectedTemplate}:${item.name}`];persist();api().rerender();break;}
    }
  });
  document.addEventListener('submit',e=>{if(e.target.id==='lesson-ai-form'){e.preventDefault();const val=document.querySelector('#lesson-ai-question')?.value.trim();if(val)answerCoach('question',val);}});
  document.addEventListener('input',e=>{if(e.target.id==='studio-code'){const item=templates[selectedTemplate]?.files[fileIndex];if(item){academy.studioDrafts[`${selectedTemplate}:${item.name}`]=e.target.value;persist();}}if(e.target.id==='library-search'){libraryQuery=e.target.value;const items=libraryEntries(),list=document.querySelector('#library-list');if(list)list.innerHTML=items.map(x=>`<button class="library-item ${selectedArticle===x.id?'current':''}" data-article="${safe(x.id)}"><strong>${safe(x.title)}</strong><small>${safe(x.track)} · ${safe(x.practice.slice(0,75))}</small></button>`).join('')||'<p class="subtle">No se encontraron temas.</p>';}});
  document.addEventListener('change',e=>{if(e.target.id==='library-domain'){libraryDomain=e.target.value;api().rerender();}});
  ensureDay();
  function exportData(){return JSON.parse(JSON.stringify(academy));}
  function importData(value){
    if (!value || typeof value!=='object' || value.version!==1) return false;
    academy={...initial(),daily: value.daily && typeof value.daily==='object' ? value.daily : initial().daily,
      avatar:avatars.some(a=>a.id===value.avatar)?value.avatar:'C',
      practice:value.practice && typeof value.practice==='object' ? value.practice : {},
      practiceDay:value.practiceDay && typeof value.practiceDay==='object' ? value.practiceDay : {},
      studioDrafts:{}};
    if(value.studioDrafts && typeof value.studioDrafts==='object'){
      for(const [key,draft] of Object.entries(value.studioDrafts).slice(0,70)){
        if(typeof draft==='string' && draft.length<=70000) academy.studioDrafts[key]=draft;
      }
    }
    ensureDay();persist();return true;
  }
  root.CodeQuestAcademy=Object.freeze({render,lessonPanel,record,getLevel,nav,totalExtra:40,exportData,importData});
})(window);
