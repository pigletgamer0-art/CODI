/* CODI 0.8 · original learning-path + rewards experience, local-only. */
(function (root) {
  'use strict';
  const STORE = 'codi-adventure-v08';
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const today = () => {const n=new Date(); return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-${String(n.getDate()).padStart(2,'0')}`;};
  const weekKey = () => {const date=new Date();date.setHours(12,0,0,0);const offset=(date.getDay()+6)%7;date.setDate(date.getDate()-offset);return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;};
  const defaults = () => ({version:1,gems:0,claimed:{},bonusClaimed:{},earnedLessons:{},earnedPractice:{},mistakes:{},ownedThemes:['green'],theme:'green',weekly:{key:weekKey(),earned:0,lastKnownXP:null},activityDays:[]});
  const themes = [
    {id:'green',name:'Original',emoji:'💚',cost:0,subtitle:'Clásico CODI'},
    {id:'blue',name:'Neón azul',emoji:'💠',cost:45,subtitle:'Laboratorio nocturno'},
    {id:'violet',name:'Galaxia',emoji:'🪐',cost:70,subtitle:'Un toque espacial'},
    {id:'amber',name:'Retro dorado',emoji:'🌟',cost:90,subtitle:'Energía vintage'}
  ];
  const ranks = [{name:'Semilla',xp:0,emoji:'🌱'},{name:'Circuito',xp:60,emoji:'🔌'},{name:'Byte',xp:160,emoji:'💎'},{name:'Código',xp:350,emoji:'⚡'},{name:'Órbita',xp:700,emoji:'🪐'}];
  const quests = [
    {id:'lesson',emoji:'📚',title:'Primera lección del día',target:1,gems:15,view:'route',caption:'Completa un ejercicio de tu ruta'},
    {id:'practice',emoji:'🎯',title:'Dos prácticas correctas',target:2,gems:10,view:'practice',caption:'Acierta preguntas distintas'},
    {id:'ai',emoji:'🤖',title:'Pregunta a CODI',target:1,gems:5,view:'tutor',caption:'Resuelve una duda con el tutor local'}
  ];
  const achievements = [
    {id:'first',emoji:'🌱',name:'Primer paso',detail:'Completa una lección',test:(s,a)=>completed(s)>=1},
    {id:'five',emoji:'🚀',name:'Despegue',detail:'Completa cinco lecciones',test:(s,a)=>completed(s)>=5},
    {id:'ten',emoji:'🏅',name:'Constancia',detail:'Completa diez lecciones',test:(s,a)=>completed(s)>=10},
    {id:'spark',emoji:'⚡',name:'Energía',detail:'Consigue 100 XP',test:(s,a)=>s.xp>=100},
    {id:'builder',emoji:'🧰',name:'Constructor',detail:'Crea tres proyectos',test:(s,a)=>s.projects.length>=3},
    {id:'polyglot',emoji:'🌍',name:'Explorador',detail:'Prueba tres rutas distintas',test:(s,a)=>new Set(s.projects.map(p=>p.track)).size>=3},
    {id:'seven',emoji:'🔥',name:'Siete días',detail:'Alcanza siete días de racha',test:(s,a)=>s.streak>=7},
    {id:'master',emoji:'👑',name:'Curso superado',detail:'Completa una ruta base',test:(s,a)=>s.projects.some(p=>p.lessons.filter(l=>!l.generated).every(l=>p.completed.includes(l.id)))},
    {id:'review',emoji:'🎯',name:'Experto en práctica',detail:'Acierta diez ejercicios diferentes',test:(s,a)=>new Set(Object.keys(a.earnedPractice).map(k=>k.slice(k.indexOf(':')+1))).size>=10}
  ];
  function completed(s){return s.projects.reduce((n,p)=>n+p.completed.length,0)}
  let data=defaults();
  try {const raw=JSON.parse(localStorage.getItem(STORE)||'null'); if(raw&&typeof raw==='object'&&raw.version===1)data={...defaults(),...raw};}catch{}
  function save(){try {localStorage.setItem(STORE,JSON.stringify(data))}catch{}}
  function clean(){
    if(!Number.isFinite(data.gems)||data.gems<0)data.gems=0;
    if(!Array.isArray(data.ownedThemes))data.ownedThemes=['green'];
    if(!data.ownedThemes.includes('green'))data.ownedThemes.unshift('green');
    if(!data.ownedThemes.includes(data.theme)||!themes.some(t=>t.id===data.theme))data.theme='green';
    for(const key of ['claimed','bonusClaimed','earnedLessons','earnedPractice','mistakes'])if(!data[key]||typeof data[key]!=='object'||Array.isArray(data[key]))data[key]={};
    if(!Array.isArray(data.activityDays))data.activityDays=[];
    if(!data.weekly||typeof data.weekly!=='object')data.weekly=defaults().weekly;
    if(data.weekly.key!==weekKey())data.weekly={key:weekKey(),earned:0,lastKnownXP:null};
  }
  clean();
  function applyTheme(){document.body.dataset.codiTheme=data.theme;document.querySelectorAll('[data-gem-count]').forEach(el=>el.textContent=String(data.gems));}
  function syncXP(xp){clean();const w=data.weekly;
    if(w.lastKnownXP===null||!Number.isFinite(w.lastKnownXP)){w.lastKnownXP=xp;save();}
    else if(xp!==w.lastKnownXP){w.earned+=Math.max(0,xp-w.lastKnownXP);w.lastKnownXP=xp;save();}
    applyTheme();
  }
  function activity(){const day=today();if(!data.activityDays.includes(day)){data.activityDays.push(day);data.activityDays=data.activityDays.slice(-140);}save()}
  function awardLesson(projectId,lessonId){
    const key=`${projectId}:${lessonId}`;
    if(data.earnedLessons[key])return;
    data.earnedLessons[key]=true;data.gems+=5;activity();save();
  }
  function awardPractice(projectId,lessonId,firstToday){if(!firstToday)return;const key=`${today()}:${projectId}:${lessonId}`;
    if(data.earnedPractice[key])return;data.earnedPractice[key]=true;data.gems+=2;activity();save();
  }
  function recordMistake(projectId,lessonId,wasCorrect){const key=`${projectId}:${lessonId}`;
    if(wasCorrect)delete data.mistakes[key];else data.mistakes[key]=true;
    save();
  }
  function currentDaily(){const a=root.CodeQuestAcademy?.exportData();const d=a?.daily?.date===today()?a.daily:{lesson:0,practice:0,ai:0};return d;}
  function gemHeader(){return `<div class="adventure-kpis"><span class="adventure-chip">⚡ <strong>${Number(root.CodeQuestApp?.state.xp||0)}</strong> XP</span><span class="adventure-chip">💎 <strong>${data.gems}</strong> gemas</span><span class="adventure-chip">🔥 <strong>${Number(root.CodeQuestApp?.state.streak||0)}</strong> días</span></div>`}
  function renderRoute(p,ctx){const total=p.lessons.length,done=p.completed.length;
    const blocks=[];for(let i=0;i<total;i+=5)blocks.push(p.lessons.slice(i,i+5));
    const unitNames=['Fundamentos','Tu primer programa','Aprende a resolver problemas','Conecta las piezas','Crea como un profesional','Refina y prueba'];
    return `<div class="adventure-route-head"><div><div class="eyebrow">TU AVENTURA DE PROGRAMACIÓN</div><h1 class="academy-title">Aprende mientras creas</h1><p class="lead">${esc(p.goal)}</p></div><button class="secondary" data-view="home">Cambiar de proyecto</button></div>
    ${gemHeader()}<div class="adventure-layout"><section class="adventure-path-wrap"><div class="adventure-path-top"><strong>${esc(ctx.paths[p.track]?.label||p.track)}</strong><span>${done}/${total} lecciones · ${Math.round(done/Math.max(1,total)*100)}%</span></div><div class="progress-track"><div class="progress-bar" style="width:${Math.round(done/Math.max(1,total)*100)}%"></div></div>
    ${blocks.map((batch,u)=>{const completedUnit=batch.every(l=>p.completed.includes(l.id));const currentUnit=batch.some((l,j)=>{const idx=u*5+j;return idx>=(Number(p.placementStart)||0)&&!p.completed.includes(l.id)&&(idx<=Math.max(0,Math.min(4,Number(p.placementStart)||0))||p.completed.includes(p.lessons[idx-1]?.id)||(l.generated&&!p.lessons[idx-1].generated))});const status=completedUnit?'Terminada':currentUnit?'En curso':'Pendiente';return `<section class="codi-unit" aria-label="Unidad ${u+1}"><div class="codi-unit-banner"><div><span class="codi-unit-num">UNIDAD ${u+1} · ${status}</span><h2>${esc(unitNames[u%unitNames.length])}</h2><small>${esc(batch[0]?.objective||'Practica y crea')}</small></div><button class="codi-guide-btn" data-guide="${u}" aria-expanded="false" aria-controls="unit-guide-${u}">📖 Guía</button></div><div class="codi-guidebook" id="unit-guide-${u}" hidden><h3>📖 Cuaderno de la unidad ${u+1}</h3><p>Conceptos que aprenderás y pondrás en práctica:</p>${batch.map(l=>`<article><strong>${esc(l.title)}</strong><p>${esc(l.explanation)}</p></article>`).join('')}</div><div class="codi-map" role="list">${batch.map((l,j)=>{const idx=u*5+j;const done=p.completed.includes(l.id);const unlocked=idx<=Math.max(0,Math.min(4,Number(p.placementStart)||0))||p.completed.includes(p.lessons[idx-1]?.id)||(l.generated&&!p.lessons[idx-1].generated);const kind=j===4?'checkpoint':j===2?'book':'code';const icon=done?'✓':!unlocked?'🔒':kind==='checkpoint'?'🏆':kind==='book'?'📖':'⌨';return `<div class="map-row row-${j%4}" role="listitem"><button class="map-node ${done?'node-complete':unlocked?'node-current':'node-locked'} ${kind}" data-lesson="${esc(l.id)}" ${unlocked?'':'disabled aria-disabled="true"'} aria-label="Lección ${idx+1}: ${esc(l.title)}. ${done?'Completada':unlocked?'Disponible':'Bloqueada'}"><span class="map-symbol" aria-hidden="true">${icon}</span></button><div class="map-caption ${unlocked?'':'map-caption-locked'}"><strong>${esc(l.title)}</strong><small>${done?'Completada · '+l.xp+' XP':unlocked?'¡Comenzar! · '+l.xp+' XP':'Completa la anterior'}</small></div></div>`}).join('')}</div></section>`}).join('')}
    <section class="panel adventure-more"><img src="assets/reaction-emocionado.webp" alt="CODI emocionado" loading="lazy"><div><strong>¡Tu camino continúa!</strong><p>Genera cuatro misiones extra con nuestra IA local. Son combinaciones guiadas de conocimientos ya incluidos.</p><button class="primary" data-action="more-lessons" ${Number(p.generatedCount||0)>=root.CodeQuestInfinite.max?'disabled':''}>✦ Cuatro lecciones más</button><small>${Number(p.generatedCount||0)}/${root.CodeQuestInfinite.max} misiones extra</small></div></section></section>
    <aside class="adventure-rail"><section class="panel rail-panel"><h3>🎯 Misiones de hoy</h3>${miniQuests()}<button class="secondary" data-view="quests">Ver desafíos →</button></section><section class="panel rail-panel rail-mascot"><img src="assets/reaction-saludando.webp" alt="CODI te anima" loading="lazy"><strong>Un paso a la vez</strong><p>Explora las unidades y abre el cuaderno cuando necesites repasar.</p><button class="ghost" data-view="tutor">Preguntar a CODI</button></section><section class="panel rail-panel"><h3>🧠 Tu proyecto</h3><p>${esc(p.purpose||'Aprender creando')}</p><button class="secondary" data-view="projects">Abrir taller →</button></section></aside></div>`;
  }
  function miniQuests(){const d=currentDaily();return quests.map(q=>`<div class="mini-quest"><span>${q.emoji}</span><div><strong>${esc(q.title)}</strong><div class="progress-track"><div class="progress-bar" style="width:${Math.min(100,(Number(d[q.id]||0)/q.target)*100)}%"></div></div></div><b>${Math.min(q.target,Number(d[q.id]||0))}/${q.target}</b></div>`).join('')}
  function title(heading,desc){return `<div class="eyebrow">TU PROGRESO, TU AVENTURA</div><h1 class="academy-title">${esc(heading)}</h1><p class="lead">${esc(desc)}</p>${gemHeader()}`}
  function homeDash(p) {
    const s=root.CodeQuestApp?.state;
    if(!p||!s)return `<section class="home-journey"><div><span class="eyebrow">TU PRIMER PASO</span><h2>¡Hola! Soy CODI 👋</h2><p>Escribe tu idea en el formulario de abajo y crearé una ruta de aprendizaje para ti.</p><button class="secondary" data-action="focus-create">Diseñar mi ruta →</button></div><img src="assets/reaction-saludando.webp" alt="Mascota CODI dando la bienvenida" loading="lazy"/></section>`;
    const next=p.lessons.find((l,i)=>i>=(Number(p.placementStart)||0)&&!p.completed.includes(l.id)&&(i===0||i<=Number(p.placementStart)||p.completed.includes(p.lessons[i-1]?.id)||(l.generated&&!p.lessons[i-1].generated)));
    return `<section class="home-journey"><div><span class="eyebrow">RECOMENDADO PARA TI</span><h2>${next?'Tu siguiente lección':'¡Terminaste tu ruta actual!'}</h2><p>${esc(next?.title||'Pide cuatro misiones extra para seguir practicando.')}</p><div class="home-journey-actions">${next?`<button class="primary" data-lesson="${esc(next.id)}">▶ Aprender ahora · +${next.xp} XP</button>`:`<button class="primary" data-view="route">Generar misiones →</button>`}<button class="secondary" data-view="quests">🎯 Misiones de hoy</button></div></div><img src="assets/reaction-motivando.webp" alt="CODI te anima a continuar" loading="lazy"/></section>
    <div class="home-quick-cards"><button data-view="route"><span>🗺️</span><strong>Mi camino</strong><small>${p.completed.length}/${p.lessons.length} lecciones</small></button><button data-view="practice"><span>🧠</span><strong>Repasar</strong><small>Vuelve a practicar</small></button><button data-view="league"><span>🏅</span><strong>Liga</strong><small>${data.weekly.earned} XP esta semana</small></button><button data-view="shop"><span>💎</span><strong>Personalizar</strong><small>${data.gems} gemas</small></button></div>`;
  }
  function renderQuests(){const d=currentDaily(),complete=quests.filter(q=>Number(d[q.id]||0)>=q.target).length;const allClaimed=quests.every(q=>data.claimed[`${today()}:${q.id}`]);
    return `${title('Desafíos y recompensas','Completa objetivos reales, reclama gemas y mantén tu rutina. Los contadores se reinician cada día.')}
    <section class="adventure-banner"><div><span class="eyebrow">DESAFÍOS DIARIOS</span><h2>${complete} de 3 completados</h2><div class="progress-track"><div class="progress-bar" style="width:${complete/3*100}%"></div></div><p>Las recompensas se ganan aprendiendo. Nunca necesitas pagar.</p></div><img src="assets/reaction-orgulloso.webp" alt="CODI orgulloso"/></section>
    <div class="adventure-quest-grid">${quests.map(q=>{const value=Math.min(q.target,Number(d[q.id]||0)),done=value>=q.target,claimed=!!data.claimed[`${today()}:${q.id}`];return `<article class="panel quest-plus"><div class="quest-plus-emoji">${q.emoji}</div><div class="space-between"><h3>${esc(q.title)}</h3><strong class="gem-tag">+${q.gems} 💎</strong></div><p>${esc(q.caption)}</p><div class="progress-track"><div class="progress-bar" style="width:${value/q.target*100}%"></div></div><small>${value}/${q.target}</small><div class="quest-plus-actions">${claimed?'<span class="badge">✓ Recompensa cobrada</span>':done?`<button class="primary" data-claim="${q.id}">Reclamar +${q.gems} gemas</button>`:`<button class="secondary" data-view="${q.view}">Ir a la misión →</button>`}</div></article>`}).join('')}</div>
    <div class="panel bonus-box"><div><h3>🎁 Cofre diario</h3><p>Reclama las tres recompensas de hoy y abre el cofre extra de 25 gemas.</p></div><button class="primary" data-bonus="daily" ${(!allClaimed||!!data.bonusClaimed[today()])?'disabled':''}>${data.bonusClaimed[today()]?'Abierto ✓':'Abrir cofre · +25 💎'}</button></div>`;
  }
  function renderLeague(){clean();const amount=data.weekly.earned;const rank=[...ranks].reverse().find(r=>amount>=r.xp)||ranks[0];const next=ranks.find(r=>r.xp>amount);
    return `${title('Ligas de CODI','Compite con tu propia marca semanal, gana experiencia y desbloquea categorías. Todavía no hay otros jugadores ni clasificaciones online.')}
    <section class="adventure-banner"><div><span class="eyebrow">SEMANA DEL ${esc(data.weekly.key)}</span><h2>${rank.emoji} Liga ${rank.name}</h2><p><strong>${amount} XP</strong> ganados esta semana</p><div class="progress-track"><div class="progress-bar" style="width:${next?Math.min(100,100*(amount-rank.xp)/(next.xp-rank.xp)):100}%"></div></div><p>${next?`Faltan ${next.xp-amount} XP para la liga ${next.name}`:'¡Ya alcanzaste el nivel semanal más alto!'}</p></div><img src="assets/reaction-motivando.webp" alt="CODI motivando"/></section>
    <div class="codi-league-ladder">${ranks.map(r=>`<article class="panel league-tile ${amount>=r.xp?'earned':'locked'}"><span>${r.emoji}</span><div><strong>${r.name}</strong><small>Desde ${r.xp} XP semanales</small></div><b>${amount>=r.xp?'✓':'🔒'}</b></article>`).join('')}</div><p class="footer-note">La liga es personal y se reinicia cada lunes (hora de tu dispositivo). Solo registra la XP ganada desde que usas CODI v0.8. No simula un multijugador.</p>`;
  }
  function renderShop(){return `${title('Tienda de personalización','Consigue temas aprendiendo y utiliza tus gemas gratuitas. Nunca hay pagos ni suscripciones.')}
    <div class="adventure-theme-grid">${themes.map(t=>{const owned=data.ownedThemes.includes(t.id),current=t.id===data.theme;return `<article class="panel theme-card"><div class="theme-preview theme-${t.id}"><img src="assets/badge.webp" alt="Mascota CODI" loading="lazy"/><span>${t.emoji}</span></div><h3>${esc(t.name)}</h3><p>${esc(t.subtitle)}</p><div class="theme-action">${current?'<span class="badge">✓ Tema equipado</span>':owned?`<button class="secondary" data-theme="${t.id}">Equipar tema</button>`:`<button class="primary" data-buy-theme="${t.id}" ${data.gems<t.cost?'disabled':''}>Comprar · ${t.cost} 💎</button>`}</div></article>`}).join('')}</div><p class="footer-note">Las gemas no tienen valor monetario. Todo funciona sin servidor ni pagos.</p>`}
  function renderAchievements(){const s=root.CodeQuestApp.state;const unlocked=achievements.filter(a=>a.test(s,data)).length;
    return `${title('Logros e insignias','Tus recompensas reflejan avances reales; no aparecen logros desbloqueados sin cumplir sus condiciones.')}
    <div class="panel panel-accent mb-20"><div class="space-between"><strong>Insignias conseguidas</strong><strong>${unlocked}/${achievements.length}</strong></div><div class="progress-track mt-12"><div class="progress-bar" style="width:${100*unlocked/achievements.length}%"></div></div></div>
    <div class="badge-gallery">${achievements.map(a=>{const open=a.test(s,data);return `<article class="panel achievement ${open?'achieved':'locked'}"><div class="achievement-symbol">${open?a.emoji:'🔒'}</div><strong>${esc(a.name)}</strong><p>${esc(a.detail)}</p><span class="badge">${open?'✓ Desbloqueado':'Por conseguir'}</span></article>`}).join('')}</div>`;
  }
  function renderProfile(){const s=root.CodeQuestApp.state,done=completed(s),achieved=achievements.filter(a=>a.test(s,data)).length,level=root.CodeQuestAcademy.getLevel(s.xp),first=root.CodeQuestAcademy.exportData().avatar;
    return `${title('Perfil de programador','Todo tu progreso es tuyo. Se guarda en este navegador y puedes exportarlo.')}
    ${root.CODIOnboarding?.profileHero()||`<section class="profile-adventure panel"><img src="assets/badge.webp" alt="CODI"/><div><h2>Programador CODI</h2><p>${esc(level.symbol+' '+level.name)} · Avatar: ${esc(first)}</p><div class="profile-badges"><span>⚡ ${s.xp} XP</span><span>🔥 ${s.streak} días</span><span>💎 ${data.gems} gemas</span></div></div></section>`}
    <div class="adventure-stats"><div class="panel"><strong>${done}</strong><small>Lecciones</small></div><div class="panel"><strong>${s.projects.length}</strong><small>Proyectos</small></div><div class="panel"><strong>${achieved}</strong><small>Logros</small></div><div class="panel"><strong>${data.weekly.earned}</strong><small>XP esta semana</small></div></div>
    <section class="panel"><div class="space-between"><h3>🏅 Insignias</h3><button class="ghost" data-view="achievements">Ver todas →</button></div><div class="profile-badge-row">${achievements.filter(a=>a.test(s,data)).slice(0,6).map(a=>`<span title="${esc(a.name)}">${a.emoji}</span>`).join('')||'<p class="subtle">Completa una lección para obtener tu primera insignia.</p>'}</div></section>
    <section class="panel mt-20"><h3>📅 Actividad guardada</h3><div class="activity-week">${Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-6+i);const key=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;return `<div class="activity-day"><span class="${data.activityDays.includes(key)?'active':''}">${data.activityDays.includes(key)?'✓':'·'}</span><small>${d.toLocaleDateString('es-CL',{weekday:'short'})}</small></div>`}).join('')}</div><p class="subtle">Se registran los días de actividad desde la versión 0.8.</p></section>
    <section class="panel mt-20"><h3>💾 Respaldo y privacidad</h3><p>Exporta tus proyectos, XP, gemas y progreso de CODI. Para restaurarlos en otro dispositivo, importa el respaldo.</p><div class="actions"><button class="primary" data-action="export-progress">⬇ Exportar todo</button><button class="secondary" data-action="import-progress">⬆ Importar respaldo</button></div><p class="footer-note">No hay sincronización automática entre dispositivos ni cuenta en la nube.</p></section>`;
  }
  function claimQuest(id){const q=quests.find(q=>q.id===id);if(!q)return;const key=`${today()}:${id}`;if(data.claimed[key])return root.CodeQuestApp.toast('Ya reclamaste esa misión.');const d=currentDaily();if(Number(d[q.id]||0)<q.target)return root.CodeQuestApp.toast('Primero completa el desafío.');data.claimed[key]=true;data.gems+=q.gems;save();root.CODI?.react('celebrando',`¡Ganaste ${q.gems} gemas!`);root.CodeQuestApp.navigate('quests');}
  function claimBonus(){if(data.bonusClaimed[today()]||!quests.every(q=>data.claimed[`${today()}:${q.id}`]))return;data.bonusClaimed[today()]=true;data.gems+=25;save();root.CODI?.react('celebrando','¡Cofre abierto! +25 gemas.');root.CodeQuestApp.navigate('quests');}
  function equipTheme(id){if(!themes.some(t=>t.id===id)||!data.ownedThemes.includes(id))return;data.theme=id;save();applyTheme();root.CodeQuestApp.navigate('shop');}
  function buyTheme(id){const t=themes.find(t=>t.id===id);if(!t||data.ownedThemes.includes(id)||data.gems<t.cost)return;data.gems-=t.cost;data.ownedThemes.push(id);data.theme=id;save();applyTheme();root.CODI?.react('orgulloso','¡Tu nuevo tema ya está equipado!');root.CodeQuestApp.navigate('shop');}
  document.addEventListener('click',e=>{const b=e.target.closest('[data-guide],[data-claim],[data-bonus],[data-theme],[data-buy-theme]');if(!b)return;
    if(b.dataset.guide!==undefined){const panel=document.getElementById(`unit-guide-${b.dataset.guide}`);if(panel){panel.hidden=!panel.hidden;b.setAttribute('aria-expanded',String(!panel.hidden))}return;}
    if(b.dataset.claim)claimQuest(b.dataset.claim);
    if(b.dataset.bonus)claimBonus();
    if(b.dataset.theme)equipTheme(b.dataset.theme);
    if(b.dataset.buyTheme)buyTheme(b.dataset.buyTheme);
  });
  function exportData(){return JSON.parse(JSON.stringify(data))}
  function importData(input){if(!input||typeof input!=='object'||input.version!==1)return false;
    const copy=JSON.parse(JSON.stringify(input));
    data={...defaults(),...copy};
    clean();
    data.gems=Math.min(100000,Math.max(0,Math.floor(Number(data.gems)||0)));
    data.ownedThemes=data.ownedThemes.filter(x=>themes.some(t=>t.id===x.id||t.id===x));
    for(const k of ['claimed','bonusClaimed','earnedLessons','earnedPractice','mistakes'])data[k]=Object.fromEntries(Object.entries(data[k]).slice(-1500).filter(([key,v])=>key.length<180&&v===true));
    data.activityDays=data.activityDays.filter(x=>/^\d{4}-\d\d-\d\d$/.test(x)).slice(-140);
    data.weekly.lastKnownXP=Number(root.CodeQuestApp?.state.xp||0);
    save();applyTheme();return true;
  }
  root.CODIAdventure=Object.freeze({homeDash,renderRoute,renderQuests,renderLeague,renderShop,renderAchievements,renderProfile,awardLesson,awardPractice,recordMistake,syncXP,exportData,importData,applyTheme,get gems(){return data.gems},get mistakes(){return {...data.mistakes}},get weeklyXP(){return data.weekly.earned}});
  applyTheme();
})(window);
