/* CODI Academy · personajes tecnológicos y desafíos participativos, sin APIs externas. */
'use strict';
(()=>{
 const characters=[
  {id:'codi',name:'CODI',era:'Años 80',year:'1985',role:'Guía de la academia',tone:'retro80',technology:'CRT · disquetes · BASIC',description:'Nuestro ordenador ochentero. Mantiene su diseño original y enseña los fundamentos de la programación.',face:'^ᴗ^',dialogues:{greeting:'¡Hola! Comencemos una aventura entre disquetes y código.',correct:'¡Excelente! ¡Disquete de oro para ti!',mistake:'Revisa el concepto. Todos los programadores corrigieron errores alguna vez.'},questions:[{prompt:'¿Qué es un algoritmo?',options:['Un conjunto de pasos ordenados','Un monitor antiguo','Un dibujo sin instrucciones'],correct:0,hint:'Piensa en una receta.',why:'Un algoritmo describe una secuencia de pasos para resolver un problema.'},{prompt:'¿Qué ocurre primero en un programa que pide dos números?',options:['Mostrar el resultado antes de leerlos','Recibir los datos del usuario','Cerrar el programa'],correct:1,hint:'Entrada → proceso → salida.',why:'Primero recibimos los datos; después calculamos y mostramos la respuesta.'}]},
  {id:'bita',name:'BITA',era:'Años 90',year:'1995',role:'Práctica y repaso',tone:'retro90',technology:'PC familiar · CD-ROM · píxeles',description:'Una computadora noventera colorida, paciente y especialista en ayudarte a practicar hasta entender.',face:'•ᴗ•',dialogues:{greeting:'¡Hola! Tengo un CD con ejercicios preparados para ti.',correct:'¡Genial! ¡Lo entendiste perfectamente!',mistake:'Vamos a repasarlo con una pista tranquila.'},questions:[{prompt:'¿Qué instrucción de Python muestra un mensaje?',options:['print("Hola")','save("Hola")','show("Hola")'],correct:0,hint:'Comienza con la palabra print.',why:'print() muestra información en la consola de Python.'},{prompt:'Si una variable puntos vale 3 y le sumas 2, ¿cuánto vale?',options:['32','5','2'],correct:1,hint:'3 + 2 es una suma, no una concatenación.',why:'Al sumar números enteros obtenemos 5.'}]},
  {id:'buggo',name:'BUGGO',era:'Años 2000',year:'2003',role:'Errores y depuración',tone:'retro00',technology:'USB · cibercafé · ventanas emergentes',description:'Un bichito digital que localiza fallos, explica las causas y te enseña a depurar sin frustrarte.',face:'¬_¬',dialogues:{greeting:'¡Bip! ¿Encontramos juntos un bug?',correct:'¡Bug resuelto! ¡Trabajo de detective!',mistake:'Detecté una pista. Busca la causa, no solo el síntoma.'},questions:[{prompt:'¿Qué error hay en `print("Hola"` de Python?',options:['Falta un paréntesis de cierre','Sobra la letra H','La palabra print no existe'],correct:0,hint:'Cuenta los paréntesis de apertura y cierre.',why:'La llamada debe cerrarse con ): print("Hola").'},{prompt:'¿Qué es lo mejor para encontrar un error difícil?',options:['Borrar todo el proyecto','Cambiar diez cosas a la vez','Probar partes pequeñas y leer mensajes de error'],correct:2,hint:'Un experimento pequeño identifica mejor la causa.',why:'Probar una cosa a la vez y leer errores hace más precisa la depuración.'}]},
  {id:'lumina',name:'LÚMINA',era:'Años 2010',year:'2013',role:'Teoría y biblioteca',tone:'retro10',technology:'Interfaces táctiles · dispositivos móviles',description:'Una profesora holográfica que transforma ideas complejas en explicaciones sencillas.',face:'◡‿◡',dialogues:{greeting:'Comprender el porqué es tan importante como escribir el código.',correct:'Has comprendido el principio. ¡Bien hecho!',mistake:'Cambiaré de ejemplo para ayudarte a entender.'},questions:[{prompt:'¿Para qué sirve una variable?',options:['Guardar un dato para utilizarlo','Pintar la pantalla de rojo','Apagar el equipo'],correct:0,hint:'Puedes imaginarla como una caja etiquetada.',why:'Una variable relaciona un nombre con un valor que podemos utilizar.'},{prompt:'¿Cuándo conviene usar un bucle?',options:['Para repetir una acción de forma controlada','Para eliminar el teclado','Para abrir una imagen sin programa'],correct:0,hint:'Piensa en repetir 10 veces una acción.',why:'Un bucle permite ejecutar código repetidamente según un rango o condición.'}]},
  {id:'rush',name:'RUSH',era:'2020–2026',year:'2021',role:'Desafíos y ligas',tone:'retro20',technology:'Consolas · rachas · interfaz gamer',description:'Un entrenador competitivo y energético que propone retos sin castigos ni pagos.',face:'>ᴗ<',dialogues:{greeting:'¡Desafío activado! ¡La competencia es contigo mismo!',correct:'¡VICTORIA! ¡Nuevo progreso!',mistake:'¡Buen intento! Aprende del fallo y continúa.'},questions:[{prompt:'¿Qué conviene hacer antes de publicar una aplicación?',options:['Probarla en distintos escenarios','Eliminar los mensajes de error','Ignorar los errores'],correct:0,hint:'Piensa en las pruebas.',why:'Probar en varios escenarios reduce errores y problemas para usuarios.'},{prompt:'¿Cuál es una meta de aprendizaje específica?',options:['Ser el mejor de todos mañana','Crear y probar un botón hoy','Aprender todo sin practicar'],correct:1,hint:'Una meta debe poder comprobarse.',why:'Una tarea pequeña y verificable ayuda a medir avances.'}]},
  {id:'nexa',name:'NEXA',era:'2026 · Futuro',year:'2026',role:'Proyectos y creación',tone:'retro26',technology:'Planos · módulos · prototipos',description:'Una arquitecta de proyectos que convierte tus ideas en tareas manejables, archivo por archivo.',face:'✧ᴗ✧',dialogues:{greeting:'¿Qué quieres construir? Dividiremos la idea en pasos reales.',correct:'¡Componente terminado! ¡El proyecto está avanzando!',mistake:'No pasa nada. Un prototipo existe para descubrir qué mejorar.'},questions:[{prompt:'¿Cuál es la primera tarea al crear una app de tareas?',options:['Decidir qué problema resuelve','Publicar una app vacía','Añadir 100 botones distintos'],correct:0,hint:'Empieza por el objetivo.',why:'Definir el objetivo y un alcance pequeño es el primer paso de un proyecto.'},{prompt:'¿Cómo conviene construir un proyecto grande?',options:['Con todas las funciones sin probar','Por módulos pequeños que se puedan verificar','Sin guardar versiones'],correct:1,hint:'Divide y prueba.',why:'Los módulos pequeños facilitan el desarrollo, las pruebas y la depuración.'}]}
 ];
 let selected='codi',reaction='greeting';
 const STORAGE_KEY='codi-team-challenges-v1';
 const esc=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
 function load(){try{const x=JSON.parse(localStorage.getItem(STORAGE_KEY));return x&&typeof x==='object'&&!Array.isArray(x)?x:{}}catch{return {}}}
 let progress=load();let feedback=null;
 const save=()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(progress))}catch{}};
 const getChar=id=>characters.find(c=>c.id===id)||characters[0];
 const imageUrl=file=>window.CODI_IMAGES?.[file]||'assets/'+file;
 const art=id=>imageUrl(id==='codi'?'mascot.webp':`team-${id}.webp`);
 const avatar=id=>imageUrl(id==='codi'?'reaction-feliz.webp':`avatar-${id}.webp`);
 function body(c,variant='card'){
  return `<div class="actor-art actor-${esc(c.id)} reaction-${esc(reaction)}" data-actor="${esc(c.id)}"><img src="${art(c.id)}" loading="lazy" alt="${esc(c.name)}"/><span class="actor-led" aria-hidden="true"></span>${c.id==='codi'?'<span class="actor-disk" aria-hidden="true">💾</span>':''}</div>`;
 }
 function challenge(c){const step=Math.max(0,Math.min(2,Number(progress[c.id]?.step)||0));const completed=Boolean(progress[c.id]?.earned);
  const q=c.questions[step];const message=feedback?.id===c.id?`<div class="team-feedback ${feedback.ok?'correct':'wrong'}" role="status"><strong>${feedback.ok?'¡Correcto!':'Casi, prueba otra vez'}</strong><p>${esc(feedback.text)}</p></div>`:'';
  if(!q)return `<section class="team-challenge" aria-label="Desafío terminado"><span class="eyebrow">🎉 ENTRENAMIENTO SUPERADO</span><h3>¡Completaste el reto de ${esc(c.name)}!</h3><p>Has practicado dos conceptos. ${completed?'Ya obtuviste tus 15 XP; puedes repetirlo sin recibir puntos extra.':''}</p><button class="secondary" type="button" data-team-restart="${esc(c.id)}">Volver a practicar ↻</button></section>`;
  return `<section class="team-challenge" aria-label="Desafío interactivo de ${esc(c.name)}"><div class="team-challenge-heading"><span class="eyebrow">🎮 TU TURNO</span><span class="team-steps">${step+1} / 2 · ${completed?'Repaso':'+15 XP al terminar'}</span></div><h3>${esc(q.prompt)}</h3><div class="team-answer-grid">${q.options.map((v,i)=>`<button type="button" data-team-answer="${i}" data-team-owner="${esc(c.id)}" class="team-answer"><span class="team-answer-letter">${String.fromCharCode(65+i)}</span>${esc(v)}</button>`).join('')}</div>${message}<details class="team-tip"><summary>💡 ¿Necesitas una pista?</summary><p>${esc(q.hint)}</p></details></section>`;
 }
 function render(){const c=getChar(selected);const step=Math.min(2,Number(progress[c.id]?.step)||0);
  return `<section class="team-header"><span class="eyebrow">UNA ACADEMIA, SEIS ÉPOCAS</span><h1>Conoce y practica con el equipo de CODI</h1><p>Elige un personaje, descubre su época y responde sus preguntas. Cada uno reacciona a lo que haces; todos los desafíos se pueden repetir gratis.</p></section>
  <div class="team-timeline" aria-label="Épocas de la informática">${characters.map(p=>`<button type="button" data-team-id="${p.id}" class="team-year ${selected===p.id?'active':''}" aria-pressed="${selected===p.id}"><strong>${esc(p.year)}</strong></button>`).join('')}</div>
  <div class="team-layout"><div class="team-cards">${characters.map(p=>`<button type="button" class="team-card ${p.tone} ${selected===p.id?'selected':''}" data-team-id="${p.id}" aria-pressed="${selected===p.id}"><div class="team-card-art">${body(p)}</div><span class="team-card-meta">${esc(p.era)}</span><strong>${esc(p.name)}</strong><small>${esc(p.role)}</small>${progress[p.id]?.earned?'<span class="team-done">✓ 15 XP obtenidos</span>':''}</button>`).join('')}</div>
  <aside class="team-profile ${c.tone}" aria-live="polite"><div class="team-profile-head">${body(c)}<div><span class="eyebrow">${esc(c.era)} · ${esc(c.technology)}</span><h2>${esc(c.name)}</h2><strong class="team-role">${esc(c.role)}</strong></div></div><p>${esc(c.description)}</p><div class="team-speech"><span class="team-face-small" aria-hidden="true">${esc(c.face)}</span><p>${esc(feedback?.id===c.id?feedback.speech:c.dialogues[reaction]||c.dialogues.greeting)}</p></div><div class="team-reactions" aria-label="Habla con ${esc(c.name)}"><button type="button" data-team-reaction="greeting">👋 Saludar</button><button type="button" data-team-reaction="correct">🏆 Celebrar</button><button type="button" data-team-reaction="mistake">💡 Pedir ánimo</button></div>${challenge(c)}<p class="team-disclaimer">Sin internet, sin pagos y sin otros modelos de IA. Los desafíos evalúan respuestas preparadas; no ejecutan código.</p></aside></div>`;
 }
 function select(id){if(!characters.some(x=>x.id===id))return false;selected=id;reaction='greeting';feedback=null;return true}
 function react(type){if(!['greeting','correct','mistake'].includes(type))return false;reaction=type;feedback=null;return true}
 function answer(id,answerIndex){const c=getChar(id);if(c.id!==id)return {ok:false};const step=Math.max(0,Math.min(2,Number(progress[id]?.step)||0));if(step>=2)return {ok:false};const q=c.questions[step];const ok=Number(answerIndex)===q.correct;reaction=ok?'correct':'mistake';feedback={id,ok,text:ok?q.why:`${q.hint} Intenta elegir otra opción.`,speech:c.dialogues[ok?'correct':'mistake']};
  if(ok){const record=progress[id]||{step:0,earned:false};record.step=step+1;if(record.step>=2&&!record.earned){record.earned=true;const app=window.CodeQuestApp;if(app){app.state.xp+=15;app.markActivity();app.save();}feedback.text=q.why+' ¡Te ganaste 15 XP!';}progress[id]=record;save();}return {ok,finished:ok&&step===1,feedback:feedback.text};
 }
 function restart(id){if(!characters.some(x=>x.id===id))return false;progress[id]={step:0,earned:Boolean(progress[id]?.earned)};selected=id;reaction='greeting';feedback=null;save();return true}
 const sections={practice:'bita',library:'lumina',projects:'nexa',quests:'rush',league:'rush',tutor:'codi',route:'codi',lesson:'codi',home:'codi'};
 function quizMentor(project,lesson,q,session){const id=session.feedback&&!session.feedback.ok?'buggo':session.validated?'rush':q?.type==='order'?'nexa':q?.type==='fill'?'bita':q?.type==='code'?'buggo':'lumina';const c=getChar(id);
  const say=session.feedback&&!session.feedback.ok?`¡No te rindas! ${session.feedback.message}`:session.validated?'¡Bien! Avancemos cuando estés listo.':q?.type==='fill'?'Escribe el fragmento que falta. Observa las mayúsculas.':q?.type==='order'?'Toca cada línea para construir el código en orden.':q?.type==='code'?'Detecta el fragmento correcto comparándolo con el ejemplo.':'Lee todas las alternativas antes de elegir.';
  return `<div class="quiz-mentor ${session.validated?'quiz-mentor-win':session.feedback&&!session.feedback.ok?'quiz-mentor-shake':''}"><div class="quiz-mentor-avatar"><img src="${avatar(id)}" alt="${esc(c.name)}"/></div><div><strong>${esc(c.name)} te acompaña</strong><p>${esc(say)}</p></div></div>`;
 }
 function exportData(){return Object.fromEntries(characters.map(c=>[c.id,{step:Math.min(2,Number(progress[c.id]?.step)||0),earned:Boolean(progress[c.id]?.earned)}]))}
 function importData(data){if(!data||typeof data!=='object')return false;progress={};for(const c of characters){const q=data[c.id];if(q&&typeof q==='object')progress[c.id]={step:Number.isInteger(q.step)?Math.min(2,Math.max(0,q.step)):0,earned:q.earned===true};}feedback=null;save();return true}
 // Interactive learning mentor. Local knowledge only: no model or network calls.
 const GUIDE_KEY='codi-selected-guide-v1';
 let guideId='codi';
 try{const stored=localStorage.getItem(GUIDE_KEY);if(characters.some(c=>c.id===stored))guideId=stored}catch{}
 let guideMood='greeting';
 function guideChar(){return getChar(guideId)}
 function guidePicture(){return guideId==='codi'?imageUrl(guideMood==='correct'?'reaction-orgulloso.webp':guideMood==='mistake'?'reaction-confundido.webp':guideMood==='celebrate'?'reaction-celebrando.webp':guideMood==='explain'?'reaction-programando.webp':'reaction-feliz.webp'):avatar(guideId)}
 function guideText(l,mode='greeting'){
  const c=guideChar();if(!l)return c.dialogues.greeting;
  if(mode==='explain')return l.explanation;
  if(mode==='hint')return l.hint;
  if(mode==='example')return `Ejemplo para estudiar:\n${l.example}`;
  if(mode==='encourage')return `¡Puedes con «${l.title}»! Intenta una pregunta y luego revisa tu respuesta.`;
  if(mode==='correct')return `${c.dialogues.correct} Sigue con tu próximo desafío.`;
  if(mode==='celebrate')return `${c.dialogues.correct} ¡Ahora demuestra lo aprendido en el editor!`;
  if(mode==='mistake')return `${c.dialogues.mistake} Pista: ${l.hint}`;
  return `${c.dialogues.greeting} Hoy aprenderemos «${l.title}».`;
 }
 function guideMarkup(l){const c=guideChar();return `<section class="panel guide-panel" id="lesson-guide" aria-label="Acompañante de aprendizaje"><div class="guide-visual mood-${guideMood}"><img src="${guidePicture()}" alt="${esc(c.name)}, tu tutor" class="guide-image"/><span class="guide-status">● En clase</span></div><div class="guide-content"><div class="guide-top"><div><span class="eyebrow">APRENDE CON TU EQUIPO</span><h3>${esc(c.name)} <small>${esc(c.era)}</small></h3></div><label class="guide-selector">Tu profesor <select id="guide-selector" aria-label="Seleccionar personaje que enseña">${characters.map(ch=>`<option value="${ch.id}" ${c.id===ch.id?'selected':''}>${esc(ch.name)} · ${esc(ch.era)}</option>`).join('')}</select></label></div><p id="guide-dialogue" class="guide-dialogue" aria-live="polite">${esc(guideText(l))}</p><div class="guide-choices"><button type="button" data-guide-action="explain">📖 Explícame</button><button type="button" data-guide-action="hint">💡 Pista</button><button type="button" data-guide-action="example">💻 Ver ejemplo</button><button type="button" data-guide-action="encourage">🙌 Anímame</button></div></div></section>`}
 function updateGuide(lesson,message){const panel=document.querySelector('#lesson-guide');if(!panel)return;
  const c=guideChar();const img=panel.querySelector('.guide-image');img.src=guidePicture();img.alt=c.name+' '+guideMood;
  const visual=panel.querySelector('.guide-visual');visual.className='guide-visual mood-'+guideMood;
  // Replay short animations only on explicit interaction (also reduced-motion safe).
  visual.classList.remove('guide-replay');void visual.offsetWidth;visual.classList.add('guide-replay');
  panel.querySelector('h3').textContent=c.name+' · '+c.era;
  panel.querySelector('#guide-selector').value=guideId;
  panel.querySelector('#guide-dialogue').textContent=message||guideText(lesson,guideMood);
 }
 function chooseGuide(id,lesson){if(!characters.some(c=>c.id===id))return false;
  guideId=id;guideMood='greeting';try{localStorage.setItem(GUIDE_KEY,guideId)}catch{}
  updateGuide(lesson);return true;
 }
 function guideAction(action,lesson){if(!['explain','hint','example','encourage'].includes(action)||!lesson)return false;
  guideMood=action==='encourage'?'correct':action==='explain'||action==='example'?'explain':'hint';
  updateGuide(lesson,guideText(lesson,action));return true;
 }

 function guideFeedback(ok,lesson,finished=false){guideMood=finished?'celebrate':ok?'correct':'mistake';updateGuide(lesson)}
 function lessonCompanion(phase,track,guide){
  if(phase==='code')return track==='web'||track==='javascript'||track==='python'?'buggo':'nexa';
  if(phase==='quiz')return 'rush';
  return guide.id==='lumina'?'bita':'lumina';
 }
 function studentSpeech(phase,meta={}){
  if(meta.done)return '¡Terminé la lección!';
  if(phase==='code')return meta.codeOk?'¡Mi código ya pasó la revisión!' :'Voy a escribir y completar el desafío final.';
  if(phase==='quiz')return meta.quiz?.passed?'¡Listo, quiero pasar a programar!' :'Déjenme intentar responder esta parte.';
  return 'Voy a entender la idea antes de responder.';
 }
 function lessonLines(lesson,phase,guide,partner,meta={}){
  if(meta.done)return {
    guide:`¡Gran trabajo con «${lesson.title}»!`,
    partner:partner.id==='rush'?'¡Victoria desbloqueada!':'Tu progreso quedó guardado.',
    student:studentSpeech(phase,meta)
   };
  if(phase==='code')return {
    guide:meta.codeOk?'¡Eso era! Ya puedes completar la lección.':'Acércate al editor. Yo me quedo contigo mientras programas.',
    partner:partner.id==='buggo'?'Si algo falla, lo depuramos juntos línea por línea.':'Construye el resultado por partes y verifícalo.',
    student:studentSpeech(phase,meta)
  };
  if(phase==='quiz')return {
    guide:meta.quiz?.feedback&&!meta.quiz.feedback.ok?guide.dialogues.mistake:'Yo haré de tutor mientras respondes una pregunta a la vez.',
    partner:meta.quiz?.passed?'¡Lo lograste! Ahora toca programar.':'Suma XP respondiendo bien y usa una pista si la necesitas.',
    student:studentSpeech(phase,meta)
  };
  return {
    guide:`Primero entendamos «${lesson.title}».`,
    partner:'Yo te ayudaré a convertir la idea en pasos fáciles de recordar.',
    student:studentSpeech(phase,meta)
  };
 }
 function lessonScene(lesson,phase,meta={}){
  const guide=guideChar();
  const partner=getChar(lessonCompanion(phase,meta.track,guide));
  const lines=lessonLines(lesson,phase,guide,partner,meta);
  const codeMode=phase==='code';
  return `<section class="lesson-scene phase-${esc(phase)} ${codeMode?'scene-programming':''}" id="lesson-scene" aria-label="Escena interactiva de la lección">
   <div class="scene-stage">
    <div class="scene-actor actor-main ${codeMode?'actor-closer':''}"><img src="${guidePicture()}" alt="${esc(guide.name)}" class="scene-avatar"/><strong>${esc(guide.name)}</strong><p class="scene-role">${esc(guide.role)}</p></div>
    <div class="scene-dialogues">
      <div class="scene-bubble bubble-guide"><span class="scene-badge">${phase==='learn'?'Aprende':phase==='quiz'?'Responde':'Programa'}</span><strong>${esc(guide.name)}</strong><p>${esc(lines.guide)}</p></div>
      <div class="scene-bubble bubble-student"><strong>Tú</strong><p>${esc(lines.student)}</p></div>
      <div class="scene-bubble bubble-partner"><strong>${esc(partner.name)}</strong><p>${esc(lines.partner)}</p></div>
    </div>
    <div class="scene-actor actor-partner ${phase==='quiz'?'actor-cheer':''}"><img src="${avatar(partner.id)}" alt="${esc(partner.name)}" class="scene-avatar"/><strong>${esc(partner.name)}</strong><p class="scene-role">${esc(partner.role)}</p></div>
   </div>
   <div class="scene-strip" aria-hidden="true"><span></span><span></span><span></span></div>
  </section>`;
 }
 function syncLessonScene(lesson,phase,meta={}){
   const host=document.querySelector('#lesson-scene');
   if(!host||!lesson)return;
   host.outerHTML=lessonScene(lesson,phase,meta);
 }
 // CODI v1.6: each exercise is a conversation with one of the original characters.
 const coachByType={choice:'lumina',fill:'bita',code:'buggo',order:'nexa'};
 function exerciseCast(question,session){
  const cast=characters;
  const defaultId=session.step===0?'codi':(coachByType[question?.type]||'codi');
  const lead=getChar(guideId==='codi'?defaultId:guideId);
  const supportingId=lead.id==='rush'?'codi':question?.type==='order'?'nexa':question?.type==='code'?'buggo':session.reviewMode?'bita':'rush';
  const support=getChar(supportingId===lead.id?'codi':supportingId);
  return {lead,support};
 }
 function exerciseMoment(lesson,question,session){
  if(!question)return '';
  const {lead,support}=exerciseCast(question,session);
  const ok=session.feedback?.ok===true;
  const wrong=session.feedback&&!session.feedback.ok;
  const mood=ok?'happy':wrong?'oops':'idle';
  const questionNumber=session.reviewMode?'Repaso de errores':`Pregunta ${session.step+1}`;
  const nextHints={choice:'Lee con atención las opciones y elige una.',fill:'Escribe el fragmento que falta, respetando las mayúsculas.',code:'Compara los símbolos y elige el fragmento que funciona.',order:'Toca las líneas en el orden en que deben ejecutarse.'};
  let message=ok?lead.dialogues.correct:wrong?lead.dialogues.mistake:nextHints[question.type]||'¿Qué opción elegirás?';
  if(ok&&session.streak>=3)message=`¡${session.streak} aciertos consecutivos! ${message}`;
  const partnerText=ok?`${support.dialogues.correct}`:wrong?`¡Te ayudo! ${lesson.hint}`:question.type==='code'?'¡Atento a cada símbolo del código!':question.type==='order'?'¡Primero necesitamos saber qué línea va al inicio!':session.reviewMode?'¡Repasemos juntos para dominarlo!':'Yo también estoy aprendiendo contigo.';
  const poster=lead.id==='codi'&&ok?'reaction-celebrando.webp':lead.id==='codi'&&wrong?'reaction-confundido.webp':null;
  const hero=poster?imageUrl(poster):avatar(lead.id);
  const art=avatar(support.id);
  const special=session.feedback&&ok&&session.streak>=3;
  return `<section class="character-exercise char-${esc(lead.id)} mood-${mood}" id="character-exercise" aria-label="Pregunta con el equipo CODI">
    <div class="exercise-character-title"><span class="exercise-badge">${esc(questionNumber)} · ${esc(lead.era)}</span><label class="exercise-cast-label">Profesor <select id="exercise-guide-select" aria-label="Elige un personaje para la lección"><option value="codi" ${guideId==='codi'?'selected':''}>Automático · Equipo CODI</option>${characters.filter(c=>c.id!=='codi').map(c=>`<option value="${c.id}" ${guideId===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label></div>
    <div class="exercise-character-layout"><button type="button" class="exercise-portrait" data-quiz-actor-hint aria-label="Pedir pista a ${esc(lead.name)}" title="Toca al personaje para pedir una pista"><img src="${hero}" alt="${esc(lead.name)}"/><span>${esc(lead.name)}</span></button>
      <div class="exercise-conversation"><div class="exercise-speech speech-main"><strong>${esc(lead.name)} pregunta:</strong><p>${esc(question.prompt)}</p><small>${esc(message)}</small></div>
      ${question.type==='order'||question.type==='code'||session.reviewMode||Boolean(session.feedback)?`<div class="exercise-speech speech-companion"><img src="${art}" alt=""/><span><strong>${esc(support.name)}</strong> ${esc(partnerText)}</span></div>`:''}
      </div></div>
    ${special?`<div class="exercise-streak" role="status">✨ ¡${session.streak} respuestas correctas seguidas! · ${esc(lead.name)} lo celebra contigo</div>`:''}
  </section>`;
 }
 function refreshExerciseMoment(lesson,question,session){
  const card=document.querySelector('#character-exercise');
  if(card&&lesson&&question)card.outerHTML=exerciseMoment(lesson,question,session);
 }
 function viewGuide(view){const id=sections[view];if(!id||view==='home'||view==='lesson'||view==='route'||view==='tutor')return '';
  const c=getChar(id);return `<div class="team-view-banner"><img src="${avatar(id)}" alt=""/><div><strong>${esc(c.name)} te acompaña</strong><p>${esc(c.dialogues.greeting)}</p></div><button type="button" class="ghost" data-view="team">Conocer al equipo →</button></div>`;
 }

 window.CODITeam={characters,render,select,react,answer,restart,quizMentor,guideMarkup,guideAction,chooseGuide,guideFeedback,lessonScene,syncLessonScene,exerciseMoment,refreshExerciseMoment,viewGuide,exportData,importData,characterForView:view=>sections[view]||'codi',get selected(){return selected},get guideId(){return guideId},get currentReaction(){return reaction}};
})();
