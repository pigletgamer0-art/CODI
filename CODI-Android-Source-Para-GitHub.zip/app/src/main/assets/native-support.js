// CODI Android bridge. Browsers ignore this file safely.
'use strict';
if (window.CODIAndroid && typeof window.CODIAndroid.saveText === 'function') {
  window.downloadText = function(name, content, mime = 'text/plain;charset=utf-8') {
    window.CODIAndroid.saveText(String(name), String(mime), String(content));
  };
}
