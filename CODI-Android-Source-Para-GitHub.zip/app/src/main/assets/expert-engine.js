/* CodeQuest v0.4: motor experto, recuperación de conocimiento y revisión heurística.
   Todo local. Nunca ejecuta el código del estudiante. Reglas != compilador. */
(function(root){
'use strict';
const kb=root.CodeQuestKnowledge?.entries||[];
const stop=new Set('a al algo algunos ante antes asi aun aunque bien como con contra cual cuando de del desde donde el ella en entre era es eso esta este esto estos fue ha hacer hasta hay la las le les lo los los mas me mi mis no o para pero por porque puedo puedes que quien se sea ser si sin sobre son su sus te tengo tiene tu tus un una uno unos unas y ya yo quiero necesito crear hacer sirve funciona ejemplo explicame explica dame codigo proyecto paso pasos necesito ayuda'.split(' '));
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9@+#]+/g,' ').trim();
const words=s=>[...new Set(norm(s).split(/\s+/).filter(w=>w.length>2&&!stop.has(w)))];
const similarity=(query,entry,track)=>{const terms=words(query),title=words(entry.title),tags=words(entry.tags),text=words(entry.explanation);if(!terms.length)return 0;let score=0,exact=0;for(const word of terms){if(title.includes(word)){score+=4;exact++}else if(tags.includes(word)){score+=3;exact++}else if(text.includes(word)){score+=0.6}}
 if(entry.track===track)score*=1.35;else if(entry.track!=='all')score*=0.55;
 if(norm(query).includes(norm(entry.title))&&entry.title.length>4)score+=6;
 return exact?score/Math.sqrt(Math.max(1,terms.length)):0;};
function search(query,track='all',limit=3){return kb.map(entry=>({entry,score:similarity(query,entry,track)})).filter(x=>x.score>=1.7).sort((a,b)=>b.score-a.score).slice(0,limit);}
function advice(topic,style='explain'){
 const e=topic.entry;
 const rows=[`📘 ${e.title}`,e.explanation];
 if(style==='example')rows.push('Ejemplo didáctico:\n'+e.code);
 else if(style==='hint')rows.push('Empieza con este ejercicio: '+e.practice);
 else rows.push('Qué practicar: '+e.practice);
 rows.push('⚠️ Error frecuente: '+e.pitfall,'✅ Cómo comprobarlo: '+e.verify);
 return rows.join('\n\n');
}
// Diferenciamos problemas detectables de dudas de estilo y evitamos falsos positivos groseros.
const issue=(severity,title,detail,line=0,fix='')=>({severity,title,detail,line,fix});
function scanner(src,language){
 const issues=[],stack=[],pairs={')':'(',']':'[','}':'{'},open='([{';let quote=null,escaped=false,inBlock=false,inLine=false,line=1;
 const python=language==='python',luau=language==='roblox',html=language==='web';
 if(html&&/<\s*[a-z!]/i.test(src))return [];
 for(let i=0;i<src.length;i++){
   const c=src[i],n=src[i+1];if(c==='\n'){line++;inLine=false;continue}
   if(inLine)continue;
   if(inBlock){if(c==='*'&&n==='/'){inBlock=false;i++}continue}
   if(quote){if(escaped){escaped=false;continue}if(c==='\\'){escaped=true;continue}if(c===quote){quote=null}continue}
   if(python&&c==='#'){inLine=true;continue}
   if(luau&&c==='-'&&n==='-'){inLine=true;i++;continue}
   if(!python&&!luau&&c==='/'&&n==='/'){inLine=true;i++;continue}
   if(!python&&!luau&&c==='/'&&n==='*'){inBlock=true;i++;continue}
   if(c==='"'||c==="'"||(!python&&!luau&&c==='`')){quote=c;continue}
   if(open.includes(c))stack.push({ch:c,line});
   else if(Object.hasOwn(pairs,c)){if(!stack.length||stack[stack.length-1].ch!==pairs[c])issues.push(issue('error',`Delimitador «${c}» sin pareja`,`Revisa paréntesis, llaves y corchetes cerca de la línea ${line}.`,line,'Comprueba el cierre de los bloques.'));else stack.pop()}
 }
 for(const x of stack.slice(-4))issues.push(issue('error',`Falta cerrar «${x.ch}»`,'Hay un delimitador abierto sin cerrar.',x.line,'Cierra el bloque con el símbolo correspondiente.'));
 if(quote)issues.push(issue('warning','Cadena de texto sin cerrar','Detecté una comilla abierta hasta el final del archivo.',line,'Revisa comillas y saltos de línea.'));
 if(inBlock)issues.push(issue('warning','Comentario sin cerrar','Un comentario /* ... */ parece estar incompleto.',line,'Añade */ al final del comentario.'));
 return issues;
}
function location(src,index){return src.slice(0,Math.max(0,index)).split('\n').length}
function patternIssue(src,re,severity,title,detail,fix,issues){const m=re.exec(src);if(m)issues.push(issue(severity,title,detail,location(src,m.index),fix))}
function reviewCode(code,track='javascript'){
 const src=String(code||'').slice(0,60000),lang=track==='minecraft'?'minecraft':track==='roblox'?'roblox':track==='python'?'python':track==='web'?'web':'javascript',issues=[];
 if(!src.trim())return {language:lang,lines:0,issues:[issue('info','Editor vacío','Pega código para comenzar una revisión de buenas prácticas.')],checked:false};
 const lines=src.split('\n');
 if(lang==='minecraft'&&/^[\s\n]*[\[{]/.test(src)){
   try{JSON.parse(src)}catch(e){issues.push(issue('error','JSON no válido',e.message,0,'Revisa comas, comillas dobles y llaves.'))}
 }
 if(lang==='javascript'||lang==='minecraft'||lang==='web'||lang==='roblox'||lang==='python')issues.push(...scanner(src,lang));
 if(lang==='javascript'||lang==='web'||lang==='minecraft'){
  patternIssue(src,/\beval\s*\(/,'warning','Uso de eval()','Ejecutar texto como código es peligroso, especialmente si incluye datos externos.','Evita eval y usa estructuras de datos o funciones definidas.',issues);
  patternIssue(src,/\.innerHTML\s*=\s*(?!['"`])\S/,'warning','HTML dinámico potencialmente inseguro','Asignar cadenas variables a innerHTML puede habilitar XSS si incluyen datos no confiables.','Para mostrar texto, usa textContent; si necesitas HTML, sanitiza adecuadamente.',issues);
  patternIssue(src,/(?:^|[^=!])==(?!=)/m,'info','Comparación con ==','La igualdad flexible convierte tipos automáticamente. Puede ser intencionado, pero verifica la necesidad.','Prefiere === en JavaScript cuando tenga sentido.',issues);
  patternIssue(src,/localStorage\s*\.\s*setItem\s*\(\s*['"`](?:password|token|api[_-]?key|secret)/i,'warning','Dato sensible en localStorage','Los secretos accesibles a JavaScript no deben considerarse protegidos.','No guardes contraseñas ni claves privadas en localStorage.',issues);
  patternIssue(src,/\b(?:var)\s+\w+/,'info','Uso de var','En código moderno, let y const comunican mejor las reasignaciones y tienen ámbito de bloque.','Prefiere const; usa let cuando necesites reasignar.',issues);
  patternIssue(src,/\bfetch\s*\(/,'info','Operación de red','fetch requiere conectividad para URLs remotas y puede fallar por red o CORS.','Añade manejo de errores y planifica el comportamiento offline.',issues);
  if(lang==='web'){
   patternIssue(src,/<img\b(?![^>]*\balt\s*=)[^>]*>/i,'warning','Imagen sin atributo alt','Las imágenes necesitan texto alternativo apropiado o alt="" si son decorativas.','Añade alt descriptivo o alt="".',issues);
   patternIssue(src,/<button\b(?![^>]*\btype\s*=)[^>]*>/i,'info','Botón sin type','Dentro de un formulario, button es submit por defecto.','Usa type="button" si no debe enviar el formulario.',issues);
  }
 }
 if(lang==='python'){
  patternIssue(src,/(^|\n)[ \t]*except\s*:/m,'warning','except genérico','Capturar cualquier excepción sin indicar cuál complica la depuración.','Captura clases concretas como ValueError o FileNotFoundError.',issues);
  patternIssue(src,/\bexcept\b[^\n]*:\s*(?:\n\s*)?pass\b/,'warning','Error silenciado','except: pass puede ocultar fallos importantes.','Registra el error o devuelve un estado de error explícito.',issues);
  patternIssue(src,/\bdef\s+\w+\s*\([^)]*=\s*\[\s*\]/,'warning','Parámetro mutable por defecto','La lista por defecto se comparte entre llamadas.','Usa None y crea una lista dentro de la función.',issues);
  patternIssue(src,/\b(?:eval|exec)\s*\(/,'warning','Ejecución dinámica','eval/exec no son apropiados para entradas no confiables.','Utiliza parsing de formatos esperados en lugar de ejecutar texto.',issues);
  const tabs=lines.some(l=>/^\t+\S/.test(l)),spaces=lines.some(l=>/^ {2,}\S/.test(l));if(tabs&&spaces)issues.push(issue('warning','Indentación mixta','Detecté bloques indentados con tabulaciones y con espacios.',0,'Usa 4 espacios de forma consistente.'));
  lines.forEach((l,i)=>{if(/^\s*(if|elif|else|for|while|def|class|try|except|finally|with)\b/.test(l)&&!/^\s*#/.test(l)&&!/:\s*(#.*)?$/.test(l)&&!(/:\s*\S/.test(l)))issues.push(issue('info','Posible falta de dos puntos',`Revisa la cabecera del bloque en la línea ${i+1}.`,i+1,'La cabecera de if, for, def, etc. suele terminar en :.'))});
 }
 if(lang==='roblox'){
  patternIssue(src,/\bwhile\s+true\s+do\b[\s\S]{0,160}?\bend\b/,'info','Bucle continuo Luau','Un ciclo persistente necesita ceder tiempo al planificador y un criterio para detenerse.','Usa task.wait(...) y controla cuándo termina.',issues);
  patternIssue(src,/\bwait\s*\(/,'info','wait() antiguo','task.wait suele ser más apropiado para la temporización moderna en Roblox.','Usa task.wait() si corresponde.',issues);
  patternIssue(src,/OnServerEvent\s*:\s*Connect\s*\(/,'warning','Validar RemoteEvent en el servidor','Cuando el cliente pide cambios de estado, valida argumentos, permisos y frecuencia en el servidor.','Añade comprobaciones del jugador y tipos recibidos.',issues);
  patternIssue(src,/\b_G\s*\./,'info','Estado global compartido','_G complica seguir dependencias entre scripts.', 'Usa ModuleScripts para estado y funciones compartidas.',issues);
 }
 if(lang==='minecraft'){
  if(/"header"\s*:/.test(src)&&/"modules"\s*:/.test(src)&&!(/"uuid"\s*:/.test(src)))issues.push(issue('warning','Manifest sin UUID visible','Cada header y módulo del manifiesto requiere identificadores válidos.',0,'Agrega UUID distintos y versiones compatibles.'));
  patternIssue(src,/\bsystem\.runInterval\s*\([^)]*\b1\s*\)/,'info','Tarea en cada tick','Revisa si realmente necesitas ejecutar el trabajo cada tick.','Prefiere eventos o intervalos menos frecuentes si es posible.',issues);
 }
 if(lines.length>300)issues.push(issue('info','Archivo extenso','Este archivo tiene más de 300 líneas; quizá convenga dividir responsabilidades.',0,'Agrupa funciones afines en módulos cuando mejore la claridad.'));
 let errors=issues.filter(i=>i.severity==='error').length,warnings=issues.filter(i=>i.severity==='warning').length;
 return {language:lang,lines:lines.length,issues:issues.slice(0,12),total:issues.length,errors,warnings,checked:true,disclaimer:'Revisión heurística: no ejecuta ni compila el proyecto. «Sin problemas detectados» no significa «sin errores».'};
}
function formatReview(review){if(!review.checked)return 'Pega tu código para revisarlo. No lo voy a ejecutar.';
 const intro=`🔍 Revisión estática (${review.language}, ${review.lines} líneas). ${review.errors} posibles errores, ${review.warnings} advertencias.\n${review.disclaimer}`;
 if(!review.issues.length)return intro+'\n\nNo se detectaron problemas con las reglas disponibles. Próximo paso: compila o ejecuta en tu entorno y realiza pruebas.';
 return intro+'\n\n'+review.issues.map((a,i)=>`${i+1}. ${a.severity==='error'?'❌':a.severity==='warning'?'⚠️':'💡'} ${a.title}${a.line?' (línea '+a.line+')':''}\n${a.detail}${a.fix?'\nSugerencia: '+a.fix:''}`).join('\n\n');
}
function coach(question,track='all',style='explain'){
 const found=search(question,track,3);if(!found.length)return null;
 return {title:found[0].entry.title,score:found[0].score,answer:advice(found[0],style),related:found.slice(1).map(t=>t.entry.title),topic:found[0].entry.id};
}
root.CodeQuestExpert=Object.freeze({search,coach,reviewCode,formatReview,knowledgeCount:kb.length,topics:kb.map(e=>({id:e.id,track:e.track,title:e.title}))});
})(typeof window!=='undefined'?window:globalThis);
