/* CODI 1.9 · Cuenta de verdad con servidor propio; sin enviar datos al tutor de IA. */
'use strict';
(()=>{
 const overlay=document.getElementById('codi-account');
 const status=document.getElementById('cloud-status');
 const esc=v=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[x]));
 let server=false, user=null, revision=0, mode='login', guest=false, busy=false, dirty=false, syncing=false, suspend=false, revisionConflict=false, timeout=null, lastUploaded='';
 const hosted=['http:','https:'].includes(location.protocol);
 const api=async(url,options={})=>{
  const res=await fetch(url,{...options,credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json',...(options.headers||{})}});
  const data=await res.json().catch(()=>({ok:false,error:'Respuesta inválida del servidor'}));
  if(!res.ok){const error=new Error(data.error||'Error al conectar');error.status=res.status;throw error;}
  return data;
 };
 function message(text='',bad=false){const e=document.getElementById('account-message');if(e){e.textContent=text;e.classList.toggle('bad',bad)}}
 function label(){
  if(!status)return;
  status.textContent=user?dirty?'☁️ Pendiente de guardar':syncing?'☁️ Sincronizando':revisionConflict?'⚠️ Conflicto':`☁️ ${user.username}`:server?'👤 Entrar':'☁️ Sin conexión';
  status.title=user?'Cuenta '+user.username+' · tocar para gestionar':'Abrir acceso a CODI';
 }
 function show(){overlay.hidden=false;document.body.classList.add('account-open');render()}
 function hide(){overlay.hidden=true;document.body.classList.remove('account-open');}
 function render(){
  if(overlay.hidden)return;
  const header=`<div class="account-brand"><img src="${window.CODI_IMAGES?.['badge.webp']||'assets/badge.webp'}" alt=""/><div><strong>CODI</strong><span>Tu aprendizaje, a donde vayas</span></div></div>`;
  if(user){overlay.innerHTML=`<div class="account-sheet">${header}<div class="account-inner"><span class="account-tag">CUENTA SINCRONIZADA</span><h1>¡Hola, ${esc(user.username)}!</h1><p>Tu progreso se guarda en tu cuenta cuando el servidor está disponible. Las lecciones funcionan sin servicios de IA.</p><div class="account-state"><span>${revisionConflict?'⚠️ Otro dispositivo guardó datos nuevos':dirty?'⏳ Hay cambios por sincronizar':'✓ Copia en la nube al día'}</span><small>Versión del respaldo: ${revision}</small></div><button type="button" class="account-main" data-account="sync">☁️ Sincronizar ahora</button>${revisionConflict?'<button type="button" class="account-alt" data-account="resolve">Resolver conflicto de datos</button>':''}<button type="button" class="account-alt" data-account="logout">Cerrar sesión</button><button type="button" class="account-link" data-account="close">Volver a CODI</button><p id="account-message" role="status"></p></div></div>`;return;}
  overlay.innerHTML=`<div class="account-sheet">${header}<div class="account-inner"><span class="account-tag">${server?'GUARDA TU PROGRESO EN LA NUBE':'SIN SERVIDOR DE CUENTAS'}</span><h1>${server?(mode==='register'?'Crea tu cuenta CODI':'Vuelve a tus lecciones'):'CODI todavía no está conectado'}</h1><p>${server?'Usa un apodo, no tu nombre real. Tu contraseña protege los avances que se guardan en el servidor.':'Para tener una cuenta real necesitamos publicar CODI en un servidor con base de datos. Aquí puedes probar sin cuenta y guardar respaldos.'}</p>${server?`<div class="account-switch"><button data-account="login" class="${mode==='login'?'chosen':''}">Iniciar sesión</button><button data-account="register" class="${mode==='register'?'chosen':''}">Registrarse</button></div><form id="account-form" autocomplete="on"><label for="account-username">Nombre de usuario (3 a 20 caracteres)</label><input id="account-username" name="username" autocomplete="username" minlength="3" maxlength="20" pattern="[A-Za-z0-9_]+" required placeholder="TuApodo"/><label for="account-password">Contraseña (mínimo 10 caracteres)</label><input id="account-password" name="password" type="password" autocomplete="${mode==='register'?'new-password':'current-password'}" minlength="10" maxlength="128" required placeholder="Tu contraseña segura"/><button type="submit" class="account-main" ${busy?'disabled':''}>${busy?'Conectando…':mode==='register'?'Crear cuenta y guardar':'Entrar y recuperar progreso'}</button></form>`:''}<button class="account-alt" data-account="demo">Continuar sin cuenta (sin sincronización)</button><p class="account-fine">${server?'Sin correo ni anuncios. No compartas tu contraseña. Sin recuperación de contraseña por ahora.':'El perfil de invitado solo guarda datos en este dispositivo. No es una cuenta real.'} Publicar CODI para menores requiere revisar protección de datos y autorización de sus responsables.</p><p id="account-message" class="account-message" role="status"></p></div></div>`;
 }
 function progress(){return window.CodeQuestApp?.cloudSnapshot?.()||null;}
 async function saveCloud(force=false){
  if(!user||syncing||suspend||revisionConflict)return;
  const snapshot=progress();if(!snapshot)return;
  const key=JSON.stringify(snapshot);
  if(!force&&!dirty&&key===lastUploaded)return;
  if(key.length>990000){dirty=true;label();return;}
  syncing=true;label();
  try{const r=await api('/api/progress',{method:'PUT',body:JSON.stringify({revision,snapshot})});revision=r.revision;lastUploaded=key;dirty=false;revisionConflict=false;message('Progreso guardado correctamente.');}
  catch(e){dirty=true;if(e.status===409)revisionConflict=true;message(e.status===409?'Hay cambios en otro dispositivo. Resuelve el conflicto antes de guardar.':'Sin conexión. Tus cambios siguen en este dispositivo.',true)}
  finally{syncing=false;label();}
 }
 function schedule(){if(!user||suspend)return;dirty=true;label();clearTimeout(timeout);timeout=setTimeout(()=>saveCloud(),1400);}
 function localAccountOwner(){try{return localStorage.getItem('codi-account-owner')||''}catch{return ''}}
 function writeOwner(id){try{localStorage.setItem('codi-account-owner',id)}catch{}}
 function clearLocal(){for(const key of Object.keys(localStorage)){if(key.startsWith('codequest-')||key.startsWith('codi-')||key.startsWith('CODI-')){if(key!=='codi-account-owner')localStorage.removeItem(key)}}}
 async function pullProgress(){
   const r=await api('/api/progress');revision=r.revision||0;
   const owner=localAccountOwner();const current=progress();
   const hasLocal=Boolean(current?.state?.projects?.length||current?.onboarding);
   if(r.snapshot){
      if(hasLocal&&(owner!==user.id||JSON.stringify(current)!==JSON.stringify(r.snapshot))){if(!confirm('Hay datos locales que podrían ser distintos a los de la nube. ¿Cargar la copia de tu cuenta? Los datos locales se reemplazarán.')){revision=r.revision;revisionConflict=true;dirty=true;label();return;}}
      suspend=true;const okay=window.CodeQuestApp?.loadCloudSnapshot(r.snapshot);suspend=false;
      if(!okay)throw new Error('No se pudo recuperar el respaldo de esta cuenta.');
      lastUploaded=JSON.stringify(progress());dirty=false;writeOwner(user.id);
   }else{
      if(hasLocal&&owner!==user.id){if(confirm('Esta cuenta es nueva. ¿Guardar en ella el progreso que ya tienes en este dispositivo?')){writeOwner(user.id);dirty=true;await saveCloud(true)}else{clearLocal();writeOwner(user.id);location.reload();return;}}
      else {writeOwner(user.id);dirty=true;await saveCloud(true)}
   }
   label();
 }
 async function signedIn(account){user=account;guest=false;revisionConflict=false;dirty=false;label();try{await pullProgress();hide();window.CODIOnboarding?.refresh?.()}catch(e){show();message('No se pudo recuperar el progreso: '+e.message,true)}}
 async function initialize(){
  if(!hosted){show();return}
  try{const health=await api('/api/health');server=health.accounts===true;}catch{server=false;}
  if(server){try{const r=await api('/api/me');if(r.user){await signedIn(r.user);return;}}catch{}}
  show();
 }
 overlay.addEventListener('submit',async e=>{
  if(e.target.id!=='account-form')return;e.preventDefault();if(busy)return;
  const username=e.target.username.value.trim(),password=e.target.password.value;
  if(!/^[a-zA-Z0-9_]{3,20}$/.test(username)||password.length<10){message('Revisa tu usuario y contraseña.',true);return;}
  busy=true;const submit=e.target.querySelector('button[type=submit]');submit.disabled=true;submit.textContent='Comprobando…';
  try{const r=await api('/api/'+mode,{method:'POST',body:JSON.stringify({username,password})});e.target.password.value='';await signedIn(r.user);}
  catch(err){message(err.message,true);submit.disabled=false;submit.textContent=mode==='register'?'Crear cuenta y guardar':'Entrar y recuperar progreso'}
  finally{busy=false;}
 });
 overlay.addEventListener('click',async e=>{
  const button=e.target.closest('[data-account]');if(!button)return;
  const action=button.dataset.account;
  if(action==='register'||action==='login'){mode=action;render();return}
  if(action==='demo'){guest=true;hide();return}
  if(action==='close'){hide();return}
  if(action==='sync'){await saveCloud(true);render();return}
  if(action==='resolve'){
   try{const remote=await api('/api/progress');
    if(confirm('¿Usar el progreso guardado en la nube? Reemplazará los datos actuales de este dispositivo.')){
      suspend=true;const ok=window.CodeQuestApp.loadCloudSnapshot(remote.snapshot);suspend=false;
      if(!ok)throw new Error('No se pudo cargar el respaldo.');revision=remote.revision;lastUploaded=JSON.stringify(progress());dirty=false;revisionConflict=false;label();render();return;
    }
    if(confirm('¿Conservar tus cambios locales y sobrescribir la copia remota?')){
      revision=remote.revision;revisionConflict=false;await saveCloud(true);render();
    }
   }catch(err){message(err.message,true)}return;
  }
  if(action==='logout'){
    if(dirty&&!confirm('Hay datos sin sincronizar. ¿Quieres cerrar sesión de todas formas?'))return;
    try{await api('/api/logout',{method:'POST',body:'{}'})}catch{}
    clearLocal();try{localStorage.removeItem('codi-account-owner')}catch{}location.reload();
  }
 });
 status?.addEventListener('click',show);
 document.addEventListener('click',e=>{if(e.target.closest('[data-account-open]'))show()});
 window.addEventListener('online',()=>{if(user&&dirty)saveCloud();label()});
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'&&user&&dirty)saveCloud()});
 setInterval(()=>{if(user&&!document.hidden)saveCloud()},30000);
 window.CODIAccount={schedule,saveCloud,show,get user(){return user},get connected(){return Boolean(server&&user)},get dirty(){return dirty}};
 document.addEventListener('DOMContentLoaded',initialize);
})();
