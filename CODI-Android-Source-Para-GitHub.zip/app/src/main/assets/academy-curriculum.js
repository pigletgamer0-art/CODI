/* CodeQuest v0.5: lecciones originales adicionales. */
window.CodeQuestExtraLessons={
  "web": [
    {
      "id": "web7",
      "title": "HTML accesible",
      "objective": "Usar etiquetas semánticas",
      "explanation": "main agrupa el contenido principal; nav los enlaces de navegación. Las etiquetas semánticas mejoran accesibilidad y organización.",
      "example": "<nav><a href=\"#inicio\">Inicio</a></nav>\n<main><h1>Proyecto</h1></main>",
      "starter": "<!-- Escribe tu HTML aquí -->\n",
      "checks": [
        "<nav",
        "<main"
      ],
      "question": "¿Qué etiqueta identifica el contenido principal?",
      "choices": [
        "div",
        "main",
        "span"
      ],
      "answer": 1,
      "hint": "Agrega <main> y <nav> con sus cierres.",
      "xp": 50
    },
    {
      "id": "web8",
      "title": "Flexbox",
      "objective": "Alinear elementos con CSS",
      "explanation": "display: flex organiza elementos sobre un eje. gap separa sin márgenes manuales.",
      "example": "nav { display: flex; gap: 12px; }",
      "starter": "/* Escribe tus estilos CSS aquí */\n",
      "checks": [
        "display",
        "flex",
        "gap"
      ],
      "question": "¿Cuál propiedad activa Flexbox?",
      "choices": [
        "display: flex",
        "position: absolute",
        "text-align: center"
      ],
      "answer": 0,
      "hint": "Escribe una regla CSS con display: flex y gap.",
      "xp": 50
    },
    {
      "id": "web9",
      "title": "CSS Grid",
      "objective": "Construir columnas adaptables",
      "explanation": "Grid distribuye elementos en filas y columnas. repeat y minmax permiten diseños fluidos.",
      "example": ".cards { display: grid; grid-template-columns: repeat(2, 1fr); }",
      "starter": "/* Escribe tus estilos CSS aquí */\n",
      "checks": [
        "display",
        "grid",
        "grid-template-columns"
      ],
      "question": "¿Qué propiedad define las columnas?",
      "choices": [
        "grid-template-columns",
        "font-weight",
        "z-index"
      ],
      "answer": 0,
      "hint": "Usa display: grid; y grid-template-columns.",
      "xp": 50
    },
    {
      "id": "web10",
      "title": "Formularios seguros",
      "objective": "Validar entradas del usuario",
      "explanation": "required y type mejoran la entrada del usuario. La validación del navegador ayuda, pero un servidor debe validar nuevamente cuando exista.",
      "example": "<form><label for=\"edad\">Edad</label><input id=\"edad\" type=\"number\" required></form>",
      "starter": "<!-- Escribe tu HTML aquí -->\n",
      "checks": [
        "<form",
        "<label",
        "required"
      ],
      "question": "¿La validación HTML reemplaza la del servidor?",
      "choices": [
        "Sí",
        "No",
        "Solo con CSS"
      ],
      "answer": 1,
      "hint": "Agrega form, label y required.",
      "xp": 50
    },
    {
      "id": "web11",
      "title": "Eventos del navegador",
      "objective": "Escuchar cambios en campos",
      "explanation": "El evento input responde al escribir. Usa textContent en vez de innerHTML para mostrar texto no confiable.",
      "example": "campo.addEventListener(\"input\", () => { salida.textContent = campo.value; });",
      "starter": "// Escribe tu JavaScript aquí\n",
      "checks": [
        "addEventListener",
        "input",
        "textContent"
      ],
      "question": "¿Qué propiedad muestra texto sin interpretarlo como HTML?",
      "choices": [
        "innerHTML",
        "textContent",
        "outerHTML"
      ],
      "answer": 1,
      "hint": "Usa addEventListener(\"input\",...) y textContent.",
      "xp": 50
    },
    {
      "id": "web12",
      "title": "Diseño móvil",
      "objective": "Adaptarse a tamaños diferentes",
      "explanation": "Usa viewport, unidades relativas y media queries. Prueba con teclado, pantalla vertical y zoom.",
      "example": "@media (max-width: 700px) { .cards { grid-template-columns: 1fr; } }",
      "starter": "/* Escribe tus estilos CSS aquí */\n",
      "checks": [
        "@media",
        "max-width",
        "grid-template-columns"
      ],
      "question": "¿Qué mejora la adaptación al celular?",
      "choices": [
        "Ancho fijo de 1400px",
        "Media queries",
        "Imágenes enormes"
      ],
      "answer": 1,
      "hint": "Agrega @media (max-width:700px) y ajusta columnas.",
      "xp": 50
    },
    {
      "id": "web13",
      "title": "Accesibilidad",
      "objective": "Dar nombres comprensibles a controles",
      "explanation": "Los botones deben explicar su acción; alt describe imágenes importantes y aria-label puede dar nombre a controles con iconos.",
      "example": "<button aria-label=\"Abrir menú\">☰</button>",
      "starter": "<!-- Escribe tu HTML aquí -->\n",
      "checks": [
        "<button",
        "aria-label"
      ],
      "question": "¿Para qué sirve aria-label?",
      "choices": [
        "Poner un fondo",
        "Dar un nombre accesible",
        "Enviar datos"
      ],
      "answer": 1,
      "hint": "Agrega un botón con aria-label informativo.",
      "xp": 50
    },
    {
      "id": "web14",
      "title": "Publicar una web",
      "objective": "Entender estructura de archivos",
      "explanation": "Un sitio básico utiliza index.html, styles.css y app.js. Revisa enlaces relativos y seguridad antes de publicar.",
      "example": "<link rel=\"stylesheet\" href=\"styles.css\">\n<script src=\"app.js\" defer></script>",
      "starter": "<!-- Escribe tu HTML aquí -->\n",
      "checks": [
        "styles.css",
        "app.js",
        "defer"
      ],
      "question": "¿Qué archivo suele ser la entrada de una web estática?",
      "choices": [
        "index.html",
        "database.exe",
        "setup.bat"
      ],
      "answer": 0,
      "hint": "Enlaza styles.css y app.js con defer.",
      "xp": 50
    }
  ],
  "roblox": [
    {
      "id": "rb7",
      "title": "Servicios de Roblox",
      "objective": "Acceder a servicios correctamente",
      "explanation": "game:GetService obtiene servicios Roblox sin depender de que aparezcan como propiedades.",
      "example": "local Players = game:GetService(\"Players\")\nprint(Players.NumPlayers)",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "GetService",
        "Players"
      ],
      "question": "¿Qué obtiene un servicio?",
      "choices": [
        "game:GetService",
        "Instance.delete",
        "script:Run"
      ],
      "answer": 0,
      "hint": "Llama a game:GetService(\"Players\").",
      "xp": 50
    },
    {
      "id": "rb8",
      "title": "Jugadores conectados",
      "objective": "Detectar entradas de jugadores",
      "explanation": "Players.PlayerAdded se ejecuta cuando entra alguien; conecta la función desde un Script del servidor.",
      "example": "local Players = game:GetService(\"Players\")\nPlayers.PlayerAdded:Connect(function(player) print(player.Name) end)",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "PlayerAdded",
        ":Connect"
      ],
      "question": "¿Qué evento avisa que entra un jugador?",
      "choices": [
        "Touched",
        "PlayerAdded",
        "HeartbeatOnly"
      ],
      "answer": 1,
      "hint": "Usa Players.PlayerAdded:Connect(...)",
      "xp": 50
    },
    {
      "id": "rb9",
      "title": "Comunicación cliente-servidor",
      "objective": "Comprender RemoteEvents",
      "explanation": "RemoteEvent permite solicitar acciones al servidor, pero nunca confíes en valores enviados por clientes. Verifica tipos, límites y permisos.",
      "example": "local ReplicatedStorage = game:GetService(\"ReplicatedStorage\")\nlocal remote = ReplicatedStorage:WaitForChild(\"Comprar\")\nremote.OnServerEvent:Connect(function(player, itemId)\n  if typeof(itemId) ~= \"string\" then return end\nend)",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "OnServerEvent",
        "typeof",
        "return"
      ],
      "question": "¿Dónde se debe validar una compra?",
      "choices": [
        "Cliente solamente",
        "Servidor",
        "En la GUI"
      ],
      "answer": 1,
      "hint": "Usa OnServerEvent y comprueba typeof antes de actuar.",
      "xp": 50
    },
    {
      "id": "rb10",
      "title": "Interfaces del juego",
      "objective": "Actualizar texto de una GUI",
      "explanation": "Una interfaz local puede presentar información; nunca uses la GUI como fuente de verdad para dinero o premios.",
      "example": "local label = script.Parent\nlabel.Text = \"¡Bienvenido!\"",
      "starter": "-- Tu código aquí\n",
      "checks": [
        ".Text",
        "script.Parent"
      ],
      "question": "¿Una GUI debe controlar el saldo verdadero?",
      "choices": [
        "Sí",
        "No",
        "Siempre"
      ],
      "answer": 1,
      "hint": "Modifica script.Parent.Text con un texto.",
      "xp": 50
    },
    {
      "id": "rb11",
      "title": "Tablas en Luau",
      "objective": "Guardar varios datos",
      "explanation": "Las tablas agrupan valores. ipairs recorre listas ordenadas; pairs recorre claves de tablas.",
      "example": "local monedas = {5, 10, 20}\nfor i, valor in ipairs(monedas) do print(valor) end",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "local",
        "ipairs",
        "end"
      ],
      "question": "¿Qué función recorre una lista ordenada?",
      "choices": [
        "ipairs",
        "workspace",
        "warnOnce"
      ],
      "answer": 0,
      "hint": "Crea una tabla y recórrela con ipairs.",
      "xp": 50
    },
    {
      "id": "rb12",
      "title": "Temporizador de ronda",
      "objective": "Crear un contador de tiempo",
      "explanation": "task.wait permite esperar sin congelar todo el juego. En rondas reales añade estado, cancelación y limpieza de conexiones.",
      "example": "for segundos = 10, 1, -1 do\n print(segundos)\n task.wait(1)\nend",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "for",
        "task.wait",
        "end"
      ],
      "question": "¿Qué función de espera se recomienda en Luau actual?",
      "choices": [
        "wait()",
        "task.wait()",
        "sleepNow()"
      ],
      "answer": 1,
      "hint": "Haz un for que use task.wait(1).",
      "xp": 50
    },
    {
      "id": "rb13",
      "title": "Datos persistentes",
      "objective": "Conocer DataStoreService",
      "explanation": "DataStoreService conserva progresos en experiencias publicadas. Gestiona errores con pcall y límites de solicitudes.",
      "example": "local DataStoreService = game:GetService(\"DataStoreService\")\nlocal store = DataStoreService:GetDataStore(\"Progreso_v1\")\nlocal ok, data = pcall(function() return store:GetAsync(\"demo\") end)",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "DataStoreService",
        "GetDataStore",
        "pcall"
      ],
      "question": "¿Por qué usar pcall en DataStore?",
      "choices": [
        "Por los fallos posibles de red o servicio",
        "Para dibujar",
        "Para colorear"
      ],
      "answer": 0,
      "hint": "Obtén DataStoreService y maneja pcall.",
      "xp": 50
    },
    {
      "id": "rb14",
      "title": "Antiexploit básico",
      "objective": "Validar una acción sensible",
      "explanation": "El servidor decide premios, daño y compras. El cliente solo envía intenciones. Añade cooldown y validaciones.",
      "example": "remote.OnServerEvent:Connect(function(player, cantidad)\n if typeof(cantidad) ~= \"number\" or cantidad < 1 then return end\nend)",
      "starter": "-- Tu código aquí\n",
      "checks": [
        "OnServerEvent",
        "typeof",
        "return"
      ],
      "question": "¿Quién decide si un jugador recibe monedas?",
      "choices": [
        "El cliente",
        "El servidor",
        "Cualquier GUI"
      ],
      "answer": 1,
      "hint": "Valida cantidad y rechaza entradas inválidas en el servidor.",
      "xp": 50
    }
  ],
  "minecraft": [
    {
      "id": "mc7",
      "title": "Separar paquetes",
      "objective": "Distinguir Behavior y Resource Pack",
      "explanation": "Behavior Pack define comportamiento y Resource Pack contiene texturas y recursos visuales. Ambos pueden conectarse por dependencias.",
      "example": "{ \"header\": {\"name\":\"Mi Behavior Pack\"}, \"modules\": [] }",
      "starter": "{\n  \n}\n",
      "checks": [
        "header",
        "modules"
      ],
      "question": "¿Dónde van normalmente las texturas?",
      "choices": [
        "Resource Pack",
        "Behavior Pack de comandos",
        "level.dat"
      ],
      "answer": 0,
      "hint": "Representa un manifiesto con header y modules; es ejemplo simplificado.",
      "xp": 50
    },
    {
      "id": "mc8",
      "title": "Namespaces",
      "objective": "Evitar conflictos de IDs",
      "explanation": "Los identificadores personalizados deben usar un namespace propio como miaddon:bloque para evitar choques con contenido de otros paquetes.",
      "example": "{ \"identifier\": \"miaddon:bloque_luz\" }",
      "starter": "{\n  \n}\n",
      "checks": [
        "identifier",
        "miaddon:"
      ],
      "question": "¿Para qué sirve miaddon: en un identificador?",
      "choices": [
        "Evitar colisiones de nombres",
        "Cambiar idioma",
        "Activar trucos"
      ],
      "answer": 0,
      "hint": "Usa identifier con un prefijo único como miaddon:.",
      "xp": 50
    },
    {
      "id": "mc9",
      "title": "Bloques personalizados",
      "objective": "Conocer la estructura de bloques",
      "explanation": "minecraft:block y description describen un bloque. El JSON real requiere componentes válidos según versión y registro en packs.",
      "example": "{\"format_version\":\"1.21.80\",\"minecraft:block\":{\"description\":{\"identifier\":\"miaddon:bloque_luz\"},\"components\":{}}}",
      "starter": "{\n  \n}\n",
      "checks": [
        "minecraft:block",
        "description",
        "identifier"
      ],
      "question": "¿Qué clave define un bloque?",
      "choices": [
        "minecraft:block",
        "minecraft:sound",
        "mob:part"
      ],
      "answer": 0,
      "hint": "Agrega minecraft:block, description e identifier.",
      "xp": 50
    },
    {
      "id": "mc10",
      "title": "Ítems personalizados",
      "objective": "Identificar un item en JSON",
      "explanation": "minecraft:item declara un ítem. Comprueba las propiedades admitidas por tu versión de Bedrock.",
      "example": "{\"format_version\":\"1.21.80\",\"minecraft:item\":{\"description\":{\"identifier\":\"miaddon:gema\"},\"components\":{}}}",
      "starter": "{\n  \n}\n",
      "checks": [
        "minecraft:item",
        "identifier",
        "components"
      ],
      "question": "¿Qué clave inicia un ítem personalizado?",
      "choices": [
        "minecraft:item",
        "blockstate",
        "commands"
      ],
      "answer": 0,
      "hint": "Escribe un objeto minecraft:item con identifier y components.",
      "xp": 50
    },
    {
      "id": "mc11",
      "title": "Script API: mundo",
      "objective": "Leer jugadores activos",
      "explanation": "El módulo @minecraft/server expone world.getAllPlayers(); evita hacer trabajo pesado en cada tick.",
      "example": "import {world} from \"@minecraft/server\";\nfor (const jugador of world.getAllPlayers()) { jugador.sendMessage(\"Hola\"); }",
      "starter": "// Tu código aquí\n",
      "checks": [
        "@minecraft/server",
        "getAllPlayers"
      ],
      "question": "¿Qué método obtiene jugadores conectados?",
      "choices": [
        "world.getAllPlayers",
        "player.everyone",
        "system.sleep"
      ],
      "answer": 0,
      "hint": "Importa world y usa getAllPlayers().",
      "xp": 50
    },
    {
      "id": "mc12",
      "title": "Intervalos eficientes",
      "objective": "Usar system.runInterval",
      "explanation": "Los intervalos ejecutan lógica repetida. Usa períodos razonables y cancela tareas si dejas de necesitarlas.",
      "example": "import {system} from \"@minecraft/server\";\nsystem.runInterval(() => { /* tarea breve */ }, 20);",
      "starter": "// Tu código aquí\n",
      "checks": [
        "@minecraft/server",
        "runInterval"
      ],
      "question": "¿Qué evita sobrecargar el juego?",
      "choices": [
        "Procesar todo cada tick",
        "Intervalos razonables",
        "Crear miles de entidades"
      ],
      "answer": 1,
      "hint": "Usa system.runInterval con un período como 20.",
      "xp": 50
    },
    {
      "id": "mc13",
      "title": "Recetas",
      "objective": "Comprender las recetas de fabricación",
      "explanation": "Las recetas tienen identificador, ingredientes y resultado. La estructura exacta depende del tipo de receta y versión.",
      "example": "{\"format_version\":\"1.20.10\",\"minecraft:recipe_shapeless\":{\"description\":{\"identifier\":\"miaddon:receta\"},\"tags\":[\"crafting_table\"],\"ingredients\":[{\"item\":\"minecraft:dirt\"}],\"result\":{\"item\":\"minecraft:stone\"}}}",
      "starter": "{\n  \n}\n",
      "checks": [
        "minecraft:recipe_shapeless",
        "ingredients",
        "result"
      ],
      "question": "¿Qué campo establece el resultado?",
      "choices": [
        "ingredients",
        "result",
        "tags"
      ],
      "answer": 1,
      "hint": "Define ingredients y result dentro de recipe_shapeless.",
      "xp": 50
    },
    {
      "id": "mc14",
      "title": "Pruebas sin perder logros",
      "objective": "Verificar compatibilidad de add-ons",
      "explanation": "Los add-ons no siempre requieren experimentos, pero cada función puede tener restricciones. Confirma versión, manifiestos y logros en un mundo de prueba.",
      "example": "{\"format_version\":2,\"header\":{\"name\":\"Pack de prueba\"},\"modules\":[]}",
      "starter": "{\n  \n}\n",
      "checks": [
        "format_version",
        "header",
        "modules"
      ],
      "question": "¿Cómo verificas si tu pack conserva logros?",
      "choices": [
        "Suponiéndolo",
        "Probando en un mundo de prueba",
        "Cambiando cualquier JSON"
      ],
      "answer": 1,
      "hint": "Crea un manifiesto de ejemplo; en el juego comprueba las condiciones reales.",
      "xp": 50
    }
  ],
  "python": [
    {
      "id": "py7",
      "title": "Condiciones",
      "objective": "Tomar decisiones con if",
      "explanation": "En Python los bloques se indentan, y elif agrega casos intermedios. Considera valores límite.",
      "example": "vidas = 2\nif vidas > 0:\n    print(\"Jugando\")\nelse:\n    print(\"Fin\")",
      "starter": "# Tu código aquí\n",
      "checks": [
        "if",
        "else",
        ":"
      ],
      "question": "¿Qué define un bloque de Python?",
      "choices": [
        "La indentación",
        "Llaves {}",
        "Punto y coma"
      ],
      "answer": 0,
      "hint": "Prueba if ...: y else: con indentación.",
      "xp": 50
    },
    {
      "id": "py8",
      "title": "Listas",
      "objective": "Guardar colecciones",
      "explanation": "Las listas son mutables y ordenadas. append agrega elementos. Prueba la lista vacía antes de acceder al índice 0.",
      "example": "nombres = [\"Ana\", \"Leo\"]\nnombres.append(\"Sol\")\nprint(nombres)",
      "starter": "# Tu código aquí\n",
      "checks": [
        "[",
        "append",
        "print"
      ],
      "question": "¿Qué método agrega un elemento?",
      "choices": [
        "addOne",
        "append",
        "print"
      ],
      "answer": 1,
      "hint": "Crea una lista y usa append.",
      "xp": 50
    },
    {
      "id": "py9",
      "title": "Diccionarios",
      "objective": "Organizar datos con claves",
      "explanation": "Un diccionario guarda parejas clave/valor, ideal para representar propiedades de un objeto.",
      "example": "jugador = {\"nombre\": \"Ana\", \"puntos\": 0}\nprint(jugador[\"puntos\"])",
      "starter": "# Tu código aquí\n",
      "checks": [
        "{",
        "\"puntos\"",
        "print"
      ],
      "question": "¿Qué estructura usa clave y valor?",
      "choices": [
        "Diccionario",
        "Número",
        "Booleano"
      ],
      "answer": 0,
      "hint": "Declara un dict con puntos y muéstralo.",
      "xp": 50
    },
    {
      "id": "py10",
      "title": "Bucles for",
      "objective": "Recorrer colecciones",
      "explanation": "Un for itera los elementos de una lista o rango sin gestionar índices a mano.",
      "example": "for numero in range(3):\n    print(numero)",
      "starter": "# Tu código aquí\n",
      "checks": [
        "for",
        "range",
        "print"
      ],
      "question": "¿Qué función produce un rango de números?",
      "choices": [
        "range",
        "length",
        "wait"
      ],
      "answer": 0,
      "hint": "Usa for numero in range(3):",
      "xp": 50
    },
    {
      "id": "py11",
      "title": "Archivos JSON",
      "objective": "Guardar datos estructurados",
      "explanation": "json.dump serializa datos; para abrir archivos usa with, que cierra el archivo al salir.",
      "example": "import json\nwith open(\"datos.json\", \"w\", encoding=\"utf-8\") as archivo:\n    json.dump({\"puntos\": 2}, archivo)",
      "starter": "# Tu código aquí\n",
      "checks": [
        "import json",
        "with open",
        "json.dump"
      ],
      "question": "¿Qué módulo estándar maneja JSON?",
      "choices": [
        "json",
        "pickle.exe",
        "fileserver"
      ],
      "answer": 0,
      "hint": "Importa json y usa with open y json.dump.",
      "xp": 50
    },
    {
      "id": "py12",
      "title": "Excepciones",
      "objective": "Manejar errores esperables",
      "explanation": "try/except captura fallos concretos. Evita except: sin especificar qué error se espera.",
      "example": "try:\n    edad = int(\"12\")\nexcept ValueError:\n    edad = 0",
      "starter": "# Tu código aquí\n",
      "checks": [
        "try:",
        "except ValueError"
      ],
      "question": "¿Qué captura texto inválido al convertir a entero?",
      "choices": [
        "ValueError",
        "IndexButton",
        "NetworkOnly"
      ],
      "answer": 0,
      "hint": "Usa except ValueError:",
      "xp": 50
    },
    {
      "id": "py13",
      "title": "Clases",
      "objective": "Agrupar datos y métodos",
      "explanation": "Una clase define objetos con estado y métodos; self representa la instancia actual.",
      "example": "class Jugador:\n    def __init__(self, nombre):\n        self.nombre = nombre",
      "starter": "# Tu código aquí\n",
      "checks": [
        "class",
        "def __init__",
        "self"
      ],
      "question": "¿Qué representa self?",
      "choices": [
        "La instancia",
        "La lista global",
        "El archivo"
      ],
      "answer": 0,
      "hint": "Declara class, __init__ y self.nombre.",
      "xp": 50
    },
    {
      "id": "py14",
      "title": "Pruebas unitarias",
      "objective": "Comprobar funciones",
      "explanation": "assert compara una salida real con la esperada. En proyectos grandes usa unittest o pytest según el entorno.",
      "example": "def sumar(a,b):\n    return a+b\nassert sumar(2,3) == 5",
      "starter": "# Tu código aquí\n",
      "checks": [
        "def",
        "assert",
        "return"
      ],
      "question": "¿Qué comprueba una condición esperada?",
      "choices": [
        "assert",
        "printOnly",
        "inputOnly"
      ],
      "answer": 0,
      "hint": "Crea una función y usa assert con un caso.",
      "xp": 50
    }
  ],
  "javascript": [
    {
      "id": "js7",
      "title": "Condiciones",
      "objective": "Controlar decisiones",
      "explanation": "=== compara valor y tipo. Usa condiciones simples y comprueba valores límite.",
      "example": "const puntos = 10;\nif (puntos >= 10) { console.log(\"Ganó\"); }",
      "starter": "// Tu código aquí\n",
      "checks": [
        "const",
        "if",
        "console.log"
      ],
      "question": "¿Cuál comparación estricta es habitual en JavaScript?",
      "choices": [
        "===",
        "=",
        "=>"
      ],
      "answer": 0,
      "hint": "Crea const puntos y condición if.",
      "xp": 50
    },
    {
      "id": "js8",
      "title": "Bucles y arrays",
      "objective": "Recorrer listas con for...of",
      "explanation": "for...of recorre valores; evita modificar la lista que recorres salvo que controles el efecto.",
      "example": "const items = [\"piedra\", \"madera\"];\nfor (const item of items) console.log(item);",
      "starter": "// Tu código aquí\n",
      "checks": [
        "const",
        "for",
        " of "
      ],
      "question": "¿Qué recorre valores de un array?",
      "choices": [
        "for...of",
        "setTimeoutOnly",
        "switchOnly"
      ],
      "answer": 0,
      "hint": "Usa for (const item of items).",
      "xp": 50
    },
    {
      "id": "js9",
      "title": "Objetos",
      "objective": "Modelar una entidad",
      "explanation": "Los objetos guardan propiedades; puedes acceder con punto o corchetes.",
      "example": "const jugador = {nombre:\"Ana\", puntos:0};\nconsole.log(jugador.puntos);",
      "starter": "// Tu código aquí\n",
      "checks": [
        "{",
        "puntos",
        ".puntos"
      ],
      "question": "¿Qué representa jugador.puntos?",
      "choices": [
        "Una propiedad",
        "Un archivo",
        "Un evento"
      ],
      "answer": 0,
      "hint": "Crea un objeto con puntos y léelo.",
      "xp": 50
    },
    {
      "id": "js10",
      "title": "Funciones flecha",
      "objective": "Escribir funciones cortas",
      "explanation": "Una función flecha recibe parámetros y devuelve valores. No reemplaza todos los usos de function (this es diferente).",
      "example": "const sumar = (a,b) => a+b;\nconsole.log(sumar(2,3));",
      "starter": "// Tu código aquí\n",
      "checks": [
        "=>",
        "const",
        "console.log"
      ],
      "question": "¿Qué símbolo aparece en una función flecha?",
      "choices": [
        "=>",
        "<>",
        "=="
      ],
      "answer": 0,
      "hint": "Declara const sumar = (a,b) => a+b.",
      "xp": 50
    },
    {
      "id": "js11",
      "title": "DOM seguro",
      "objective": "Crear texto en el navegador",
      "explanation": "textContent agrega texto sin interpretarlo como HTML. Si llega de usuarios, evita inyectarlo con innerHTML.",
      "example": "const salida = document.querySelector(\"#salida\");\nsalida.textContent = \"Hola\";",
      "starter": "// Tu código aquí\n",
      "checks": [
        "querySelector",
        "textContent"
      ],
      "question": "¿Qué evita interpretar texto como HTML?",
      "choices": [
        "textContent",
        "innerHTML",
        "outerHTML"
      ],
      "answer": 0,
      "hint": "Busca un elemento y asigna .textContent.",
      "xp": 50
    },
    {
      "id": "js12",
      "title": "Promesas",
      "objective": "Esperar una operación asíncrona",
      "explanation": "Una promesa puede resolverse o fallar. async/await hace más legible la espera, y try/catch gestiona errores.",
      "example": "async function cargar() { try { const r = await Promise.resolve(3); return r; } catch (e) { return 0; } }",
      "starter": "// Tu código aquí\n",
      "checks": [
        "async",
        "await",
        "catch"
      ],
      "question": "¿Qué palabra espera una promesa?",
      "choices": [
        "await",
        "sleep",
        "pause"
      ],
      "answer": 0,
      "hint": "Usa async function, await y catch.",
      "xp": 50
    },
    {
      "id": "js13",
      "title": "Módulos",
      "objective": "Separar archivos",
      "explanation": "export publica funciones desde un módulo y import las utiliza; esto facilita pruebas y mantenimiento.",
      "example": "export function sumar(a,b) { return a+b; }\n// Otro archivo: import { sumar } from \"./math.js\";",
      "starter": "// Tu código aquí\n",
      "checks": [
        "export",
        "function",
        "return"
      ],
      "question": "¿Qué palabra publica código de un módulo?",
      "choices": [
        "export",
        "moduleSave",
        "windowOpen"
      ],
      "answer": 0,
      "hint": "Crea una función exportada con return.",
      "xp": 50
    },
    {
      "id": "js14",
      "title": "Probar resultados",
      "objective": "Verificar comportamientos",
      "explanation": "Comprueba resultados con asserts y prueba entradas normales y límites. La consola no sustituye una suite de pruebas.",
      "example": "function doble(n){return n*2;}\nconsole.assert(doble(3) === 6, \"Fallo\");",
      "starter": "// Tu código aquí\n",
      "checks": [
        "function",
        "console.assert",
        "==="
      ],
      "question": "¿Qué comprueba una condición durante una prueba?",
      "choices": [
        "console.assert",
        "alert",
        "prompt"
      ],
      "answer": 0,
      "hint": "Crea una función y usa console.assert().",
      "xp": 50
    }
  ]
};
