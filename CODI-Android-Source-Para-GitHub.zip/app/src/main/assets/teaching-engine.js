/* CODI Academy · clase guiada previa a las preguntas. Todo offline. */
'use strict';
(function(root){
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const image=(id,mood='normal')=>{
  const file=id==='codi'?(mood==='celebrate'?'reaction-celebrando.webp':mood==='thinking'?'reaction-pensando.webp':'reaction-feliz.webp'):`avatar-${id}.webp`;
  return root.CODI_IMAGES?.[file]||'assets/'+file;
 };
 const introNames=['Descubre','Observa','Experimenta','Recuerda'];
 const icons=['🧠','💻','🧩','⭐'];
 const sidekicks=['lumina','nexa','bita','rush'];
 const names={codi:'CODI',bita:'BITA',buggo:'BUGGO',lumina:'LÚMINA',rush:'RUSH',nexa:'NEXA'};
 const snippets=(example)=>String(example||'').split('\n').filter(v=>v.trim()).slice(0,8);
 function tokenFor(lesson){
  const example=String(lesson.example||'');
  const checks=(lesson.checks||[]).filter(s=>typeof s==='string'&&s.length>1&&/[A-Za-z]/.test(s));
  return checks.find(s=>example.includes(s)) || (checks[0]&&example.toLowerCase().includes(checks[0].toLowerCase())?checks[0]:null) || (example.match(/[a-zA-Z][\w.]{2,}/)?.[0]) || 'código';
 }
 function sample(lesson){
  const token=tokenFor(lesson),example=String(lesson.example||'');
  const source=example.includes(token)?example:example.slice(0,Math.min(example.length,400));
  const cut=source.indexOf(token),display=cut>=0?source.slice(0,cut)+'▢▢▢'+source.slice(cut+token.length):source;
  const variants=['print','local','const','function','header','background','return','for','save','import','class','let','value','name','style','width','end','if','world','body','button','wrong'];
  const extra=variants.filter(s=>s.toLowerCase()!==token.toLowerCase()&&!source.includes(s)).slice(0,2);
  while(extra.length<2)extra.push('incorrecto'+extra.length);
  const choices=[token,...extra];
  const rot=String(lesson.id||'').split('').reduce((n,c)=>n+c.charCodeAt(0),0)%3;
  const arranged=choices.map((_,i)=>choices[(i+rot)%3]);
  return {token,display:display.slice(0,500),choices:arranged,answer:arranged.indexOf(token)};
 }
 function explainLine(line,track){
  const text=String(line).trim();
  if(/^\s*(\/\/|#|<!--|\/\*)/.test(text))return 'Es un comentario: ayuda a explicar el código, pero no ejecuta la acción.';
  if(/<\/?[a-z][\w-]*/i.test(text))return 'Esta etiqueta HTML define una parte de la estructura de la página.';
  if(/\b(import|from)\b/.test(text))return 'Aquí se importa una herramienta que utilizará el programa.';
  if(/\b(local|let|const|var)\b/.test(text))return 'Se crea o asigna un dato a una variable para usarlo después.';
  if(/\b(function|def)\b/.test(text))return 'Esta parte define una función: instrucciones que puedes reutilizar.';
  if(/\b(if|else|elif)\b/.test(text))return 'Una condición permite elegir qué instrucciones se ejecutan.';
  if(/\b(for|while)\b/.test(text))return 'Este bucle sirve para repetir una acción de manera controlada.';
  if(/\b(print|console\.log|sendMessage|warn)\b/.test(text))return 'Esta instrucción muestra información o envía un mensaje, útil para comprobar resultados.';
  if(/\b(background|color|font-size|width|height)\s*:/.test(text))return 'Es una propiedad de estilo que modifica cómo se ve un elemento.';
  if(/\b(return|end)\b/.test(text))return 'Esta instrucción finaliza o devuelve un resultado dentro de un bloque.';
  if(/[:{}\[\],]/.test(text)&&track==='minecraft')return 'La puntuación y la estructura son esenciales para que los datos sean válidos.';
  if(/[=]/.test(text))return 'Se está asignando o configurando un valor. Observa qué aparece a cada lado.';
  if(/^[}\]);]+$/.test(text))return 'Este símbolo cierra el bloque, la llamada o la estructura abierta previamente.';
  return 'Observa las palabras y los símbolos de esta línea: forman parte de la secuencia que aprenderás a construir.';
 }
 function render(lesson,step,ctx={}){
  const s=Math.max(0,Math.min(3,Number(step)||0));
  const guide=names[ctx.guide]||'CODI',id=names[ctx.guide]?ctx.guide:'codi';
  const helper=sidekicks[s]===id?'codi':sidekicks[s];
  const helperName=names[helper];
  const messages=[
    `Antes de responder, vamos a entender para qué sirve «${lesson.title}».`,
    'Toca una línea del código y te explicaré qué hace. Puedes explorarlas todas.',
    'Ahora participa: completa una pieza del ejemplo. Aquí equivocarte no quita corazones.',
    '¡Muy bien! Repasemos las ideas y después iremos a las preguntas.'
  ];
  const teammate=[
    'Yo te ayudaré a conectar esta idea con la programación real.',
    'Fíjate en cómo se construye el resultado paso a paso.',
    'Una pequeña prueba guiada ayuda mucho antes del desafío.',
    'Tienes pistas gratis y puedes regresar a estudiar cuando quieras.'
  ];
  const sampleData=sample(lesson);
  const lines=snippets(lesson.example);
  const current=Math.min(Math.max(0,ctx.line||0),Math.max(0,lines.length-1));
  const selected=ctx.selected,solved=Boolean(ctx.solved);
  let body='';
  if(s===0)body=`<div class="teaching-main teaching-discover"><div class="teaching-icon">🧠</div><h2 tabindex="-1" class="teaching-heading">¿Qué vamos a aprender?</h2><p class="teaching-lead">${esc(lesson.explanation)}</p><div class="teaching-goal"><span>🎯 Tu objetivo</span><strong>${esc(lesson.objective)}</strong></div><p class="teaching-note">No necesitas memorizar todo. Vamos a practicarlo juntos.</p></div>`;
  else if(s===1)body=`<div class="teaching-main teaching-observe"><h2 tabindex="-1" class="teaching-heading">Veamos un ejemplo real</h2><p class="teaching-sub">Toca una línea y observa qué significa.</p><div class="teaching-code" aria-label="Ejemplo de código línea por línea">${lines.map((line,i)=>`<button type="button" data-teach-line="${i}" aria-pressed="${current===i}" class="teaching-code-line ${current===i?'selected':''}"><span>${i+1}</span><code>${esc(line)}</code></button>`).join('')}</div><div class="teaching-line-note" id="teaching-line-note" aria-live="polite"><strong>Línea ${current+1}</strong><p>${esc(explainLine(lines[current]||'',ctx.track))}</p></div></div>`;
  else if(s===2)body=`<div class="teaching-main teaching-try"><h2 tabindex="-1" class="teaching-heading">¡Tu turno! Completa el código</h2><p class="teaching-sub">Selecciona la pieza que falta. Puedes intentarlo cuantas veces quieras.</p><pre class="teaching-blank-code">${esc(sampleData.display)}</pre><div class="teaching-answer-grid">${sampleData.choices.map((c,i)=>`<button type="button" class="teaching-answer ${selected===i?'selected':''}" data-teach-choice="${i}" ${solved?'disabled':''}><span>${String.fromCharCode(65+i)}</span><code>${esc(c)}</code></button>`).join('')}</div>${ctx.feedback?`<div id="teaching-feedback" class="teaching-feedback ${solved?'right':'retry'}" role="status">${esc(ctx.feedback)}</div>`:'<div id="teaching-feedback" aria-live="polite"></div>'}<button type="button" class="secondary teaching-verify" data-teach-check ${selected===null||solved?'disabled':''}>${solved?'✓ Completado':'Comprobar respuesta'}</button><details class="teaching-hint"><summary>💡 Necesito una pista</summary><p>${esc(lesson.hint)}</p></details></div>`;
  else body=`<div class="teaching-main teaching-review"><div class="teaching-star">⭐</div><h2 tabindex="-1" class="teaching-heading">¡Listo para practicar!</h2><p class="teaching-sub">Antes de pasar a los retos, recuerda estas tres ideas:</p><div class="teaching-recap"><div><b>1</b><span>Meta</span><p>${esc(lesson.objective)}</p></div><div><b>2</b><span>Pieza clave</span><p><code>${esc(sampleData.token)}</code></p></div><div><b>3</b><span>Consejo de CODI</span><p>${esc(lesson.hint)}</p></div></div><p class="teaching-note">Puedes volver a cualquiera de estas pantallas mientras respondes.</p></div>`;
  const nextText=s===3?'¡Vamos a responder! →':s===2?'Terminé la práctica →':'Continuar →';
  return `<div class="teaching-flow" id="teaching-flow" data-teaching-step="${s}"><div class="teaching-overline"><span>📘 CLASE GUIADA</span><strong>${s+1} / 4</strong></div><div class="teaching-steps" aria-label="Avance de la explicación">${introNames.map((name,i)=>`<div class="teaching-step ${i===s?'active':i<s?'completed':''}"><span>${icons[i]}</span><small>${name}</small></div>`).join('')}</div><section class="teaching-character-bar" aria-label="Personajes que te enseñan"><div class="teaching-avatar"><img src="${image(id,s===3?'celebrate':'normal')}" alt="${esc(guide)}"/></div><div class="teaching-dialogue"><div class="teaching-dialogue-heading"><strong>${esc(guide)}</strong><label>Profesor <select id="teaching-guide-select" aria-label="Cambiar profesor">${Object.entries(names).map(([key,name])=>`<option value="${key}" ${id===key?'selected':''}>${esc(name)}</option>`).join('')}</select></label></div><p>${esc(messages[s])}</p></div></section>${body}<section class="teaching-partner"><img src="${image(helper)}" alt=""/><p><strong>${esc(helperName)}:</strong> ${esc(teammate[s])}</p></section><footer class="teaching-actions">${s===0?'<span class="teaching-quiet">Avanza a tu ritmo</span>':`<button type="button" class="ghost" data-teach-prev>← Atrás</button>`}<button type="button" class="primary" data-teach-next ${s===2&&!solved?'disabled title="Completa la práctica guiada antes de continuar"':''}>${nextText}</button></footer></div>`;
 }
 root.CODITeaching=Object.freeze({render,sample,explainLine});
})(window);
