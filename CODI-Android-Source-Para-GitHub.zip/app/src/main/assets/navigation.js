/* CODI 1.2 — simple, accessible navigation and truly working local settings. */
'use strict';
(function(root){
  const KEY='codi-preferences-v12';const defaults={animations:true,dailyGoal:2};let settings={...defaults};
  try{const stored=JSON.parse(localStorage.getItem(KEY)||'{}');if(stored&&typeof stored==='object')settings={...settings,...stored}}catch{}
  settings.animations=settings.animations!==false;settings.dailyGoal=[1,2,3,4,5].includes(Number(settings.dailyGoal))?Number(settings.dailyGoal):2;
  const panel=document.getElementById('more-panel'),backdrop=document.getElementById('more-backdrop'),toggle=document.getElementById('more-toggle');let lastFocus=null;
  const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  function apply(){document.body.classList.toggle('no-animations',!settings.animations)}
  function persist(){try{localStorage.setItem(KEY,JSON.stringify(settings))}catch{}}
  function openMore(){lastFocus=document.activeElement;panel.hidden=false;backdrop.hidden=false;toggle.setAttribute('aria-expanded','true');panel.querySelector('button')?.focus();}
  function closeMore(){if(panel.hidden)return;panel.hidden=true;backdrop.hidden=true;toggle.setAttribute('aria-expanded','false');(lastFocus?.isConnected?lastFocus:toggle)?.focus();}
  function sync(view){const secondary=!['route','practice','quests','league','profile','lesson'].includes(view);toggle.classList.toggle('active',secondary);toggle.setAttribute('aria-label',secondary?'Más opciones, sección actual':'Más opciones');}
  function renderSettings(){return `<div class="eyebrow">TU EXPERIENCIA</div><h1 class="academy-title">Ajustes de CODI</h1><p class="lead">Personaliza cómo estudias. Se guarda solamente en tu dispositivo.</p><section class="panel settings-panel"><h2>🎯 Meta diaria</h2><p>Elige cuántas lecciones quieres completar al día.</p><div class="daily-selector" role="group" aria-label="Lecciones diarias">${[1,2,3,4,5].map(n=>`<button data-goal="${n}" class="${settings.dailyGoal===n?'chosen':''}" aria-pressed="${settings.dailyGoal===n}">${n} ${n===1?'lección':'lecciones'}</button>`).join('')}</div><h2>✨ Movimiento</h2><p>Las reacciones de los personajes se pueden desactivar para reducir distracciones.</p><button class="secondary" data-animations aria-pressed="${settings.animations}">${settings.animations?'Desactivar animaciones':'Activar animaciones'}</button><h2>🔒 Privacidad</h2><p>La IA y tus rutas funcionan en el navegador. Tu perfil CODI es local: no hay autenticación con correo, sincronización, clasificaciones online ni pagos. Para conservar tus datos al cambiar de dispositivo, exporta un respaldo.</p><div class="actions"><button class="secondary" data-action="export-progress">Exportar mis datos</button><button class="ghost" data-view="profile">Ver perfil</button><button class="secondary" data-onboard-edit>Editar mi avatar</button></div></section>`}
  document.addEventListener('click',e=>{const target=e.target.closest('#more-toggle,#more-dismiss,#more-backdrop,[data-goal],[data-animations]');if(!target)return;
    if(target.id==='more-toggle'){panel.hidden?openMore():closeMore();return}
    if(target.id==='more-dismiss'||target.id==='more-backdrop'){closeMore();return}
    if(target.hasAttribute('data-goal')){settings.dailyGoal=Number(target.dataset.goal);persist();root.CodeQuestApp?.rerender();return}
    if(target.hasAttribute('data-animations')){settings.animations=!settings.animations;persist();apply();root.CodeQuestApp?.rerender();}
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){closeMore();return}if(e.key==='Tab'&&!panel.hidden){const buttons=Array.from(panel.querySelectorAll('button:not(:disabled)'));if(!buttons.length)return;const i=buttons.indexOf(document.activeElement);if(e.shiftKey&&i===0){e.preventDefault();buttons.at(-1).focus()}else if(!e.shiftKey&&i===buttons.length-1){e.preventDefault();buttons[0].focus()}}});
  root.CODINavigation=Object.freeze({closeMore,sync,renderSettings,getGoal:()=>settings.dailyGoal,setGoal:n=>{if([1,2,3,4,5].includes(Number(n))){settings.dailyGoal=Number(n);persist();apply()}}});apply();sync(root.CodeQuestApp?.currentView||'route');
})(window);
