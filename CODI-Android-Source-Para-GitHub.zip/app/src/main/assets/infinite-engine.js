/* CodeQuest v0.6 · Motor didáctico local: lecciones combinatorias, no LLM. */
(function(root){
'use strict';
const MAX=240;
const modes=[
  {name:'Comprender',directive:'Reproduce una versión pequeña del ejemplo y cambia un dato para acercarlo a tu proyecto.'},
  {name:'Construir',directive:'Escribe desde cero una solución mínima inspirada en el ejemplo; utiliza nombres adecuados para tu proyecto.'},
  {name:'Depurar',directive:'Reconstruye las piezas importantes, revisa los errores frecuentes y explica qué casos límite probarás.'},
  {name:'Aplicar',directive:'Integra esta técnica con otra parte de tu proyecto y prepara una prueba manual.'}
];
const normalized=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
const words=s=>new Set(normalized(s).split(/[^a-z0-9áéíóúñ]+/).filter(w=>w.length>3));
const lexicon={
 web:['<main','<form','<button','<input','<nav','<label','display:','grid-template','@media','addEventListener','querySelector','localStorage','function','const','let','return','if (','fetch(','async ','await '],
 roblox:['local ','function','end','Connect','task.wait','game:GetService','Instance.new','GetAsync','UpdateAsync','OnServerEvent','if ','for ','while ','pcall','Vector3.new'],
 minecraft:['format_version','minecraft:','@minecraft/server','world.','system.','subscribe','identifier','header','modules','components','dependencies','import ','runInterval'],
 python:['def ','print(','for ','if ','else:','return ','with ','import ','try:','except ','open(','class ','while ','assert ','json.'],
 javascript:['const ','let ','function','return ','=>','if (','for (','import ','export ','await ','async ','try {','catch (','JSON.','Promise','test(','assert.']
};
const comments={web:'<!-- Escribe tu solución; para CSS o JS usa la sintaxis de la lección -->',roblox:'-- Escribe aquí tu solución en Luau',minecraft:'// Construye un fragmento acorde al formato del ejemplo',python:'# Escribe aquí tu solución en Python',javascript:'// Escribe aquí tu solución en JavaScript'};
function checks(example,track){
 const lower=normalized(example);let keys=lexicon[track]||lexicon.javascript;
 const chosen=keys.filter(key=>lower.includes(normalized(key)));
 if(chosen.length<1)return [];
 // Controles didácticos de patrones; los ejemplos nunca se ejecutan.
 return [...new Set(chosen)].slice(0,3);
}
function topics(track,goal,purpose){
 const target=words(`${goal} ${purpose}`);
 const entries=(root.CodeQuestKnowledge?.entries||[]).filter(e=>e.track===track&&checks(e.code,track).length>0);
 return entries.map((topic,index)=>{
  const term=words(`${topic.tags} ${topic.title}`);let score=0;
  for(const w of term){if(target.has(w))score+=4;else for(const t of target)if(t.length>5&&w.length>5&&(t.startsWith(w)||w.startsWith(t)))score+=1;}
  return {topic,index,score};
 }).sort((a,b)=>b.score-a.score||a.index-b.index).map(x=>x.topic);
}
function build(project,number){
 if(!project||!lexicon[project.track]||!Number.isInteger(number)||number<0||number>=MAX)return null;
 const pool=topics(project.track,project.goal,project.purpose);
 if(!pool.length)return null;
 const idx=number%pool.length,cycle=Math.floor(number/pool.length);
 const mode=modes[cycle%modes.length],subject=pool[idx];
 const required=checks(subject.code,project.track);
 const concept=subject.explanation.trim();
 const title=`${mode.name}: ${subject.title}${cycle>=modes.length?' · repaso '+(Math.floor(cycle/modes.length)+1):''}`;
 const correct=subject.verify.trim();
 const answers=[
   correct,
   'No hace falta probar casos límite ni comprobar el resultado.',
   'Basta con copiar código sin entenderlo ni ejecutarlo.'
 ];
 const offset=number%3;
 const choices=[...answers.slice(offset),...answers.slice(0,offset)];
 return {
  id:`inf-${project.track}-${number}`,title,objective:`${mode.directive} Meta: ${String(project.goal||'tu proyecto').slice(0,100)}`,
  explanation:`${concept}\n\nEn tu proyecto: ${String(project.goal||'tu idea').slice(0,180)}. ${mode.directive} Tu reto: ${subject.practice}`,
  example:subject.code,starter:comments[project.track],checks:required,
  question:`En «${subject.title}», ¿cómo comprobarías que lo hiciste correctamente?`,
  choices,answer:choices.indexOf(correct),
  hint:`Fíjate en ${required.join(', ')}. ${subject.pitfall} ${subject.verify}`,
  xp:50,generated:true,topicId:subject.id,mode:mode.name,verify:subject.verify
 };
}
function buildBatch(project,start,count=4){
 const safeStart=Math.max(0,Math.min(MAX,Math.trunc(Number(start)||0)));
 const n=Math.max(0,Math.min(8,Math.trunc(Number(count)||0),MAX-safeStart));
 return Array.from({length:n},(_,i)=>build(project,safeStart+i)).filter(Boolean);
}
root.CodeQuestInfinite=Object.freeze({version:'0.6',max:MAX,build,buildBatch,topics,knowledgeCount:root.CodeQuestKnowledge?.total||0});
})(typeof window!=='undefined'?window:globalThis);
