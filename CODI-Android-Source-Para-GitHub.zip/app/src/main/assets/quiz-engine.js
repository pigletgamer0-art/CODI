/* CODI v0.9 — motor de preguntas didácticas. Sin servicios externos ni ejecución de código. */
'use strict';
(function(root){
  const esc = value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const MAX_HEARTS=5;
  const sessions = new Map();
  function hash(v){let n=2166136261;for(const char of String(v)){n^=char.charCodeAt(0);n=Math.imul(n,16777619)}return n>>>0}
  function shuffle(items,seed){const a=items.slice();let n=seed||12345;for(let i=a.length-1;i>0;i--){n^=n<<13;n^=n>>>17;n^=n<<5;const j=(n>>>0)%(i+1);[a[i],a[j]]=[a[j],a[i]];}return a}
  function normalize(value){return String(value??'').trim().replace(/\s+/g,' ')}
  function focusToken(lesson){const sample=String(lesson.example||'');const checks=(lesson.checks||[]).filter(s=>typeof s==='string'&&s.length>=2&&/[a-z]/i.test(s));return checks.find(s=>sample.includes(s))||checks.find(s=>sample.toLowerCase().includes(s.toLowerCase()))||checks[0]||'función'}
  function alternatives(token){const variants={
    '<h1':'<h2','</h1>':'</h2>','background':'border','addEventListener':'removeEventListener',
    '.value':'.style','localStorage':'sessionStorage','setItem':'getItem','getItem':'setItem',
    'Instance.new':'Instance.find','.Size':'.Transparency','Vector3.new':'Vector2.new',
    'Touched':'Changed',':Connect':':Disconnect','local':'global','print':'warn','warn':'print',
    'function':'local','playerSpawn':'playerLeave','subscribe':'unsubscribe',
    '@minecraft/server':'@minecraft/client','world.sendMessage':'world.sendChat',
    'format_version':'game_version','modules':'packages','header':'footer',
    'if':'for','for':'while','while':'if','console.log':'console.warn',
    'let':'var','const':'let','def':'class','return':'break','append':'pop',
    'import':'export','async':'await','await':'async','class':'def'
  };
    const other=variants[token]||('no_'+String(token).replace(/[^a-z0-9_]/gi,'').slice(0,22));
    return [other, 'sin_'+String(token).replace(/[^a-z0-9_]/gi,'').slice(0,22)];
  }
  function codeQuestion(lesson,token){
    const lines=String(lesson.example||'').split('\n');const index=lines.findIndex(l=>l.includes(token));
    let selected=lines.length>6?lines.slice(Math.max(0,index-1),Math.max(0,index-1)+5):lines;
    let base=selected.join('\n').trim();if(base.length>300)base=base.slice(0,300);
    const sourceToken=base.includes(token)?token:(base.match(/[a-zA-Z_$][\w.$]*/)?.[0]||token);
    const [bad1,bad2]=alternatives(sourceToken);
    const variants=[base,base.replace(sourceToken,bad1),base.replace(sourceToken,bad2)];
    if(new Set(variants).size!==3){return null}
    const options=shuffle(variants.map((code,id)=>({code,id})),hash(lesson.id+'code'));
    return {type:'code',prompt:'¿Qué fragmento mantiene la pieza clave del ejemplo?',
      options:options.map(x=>x.code),correct:options.findIndex(x=>x.id===0),
      detail:'Fíjate en los nombres y símbolos que aparecen en el ejemplo. Comprobar texto no es lo mismo que ejecutar el programa.'};
  }
  function makeQuestions(lesson){
    const token=focusToken(lesson);
    const plain=String(lesson.example||'');let target=plain;
    const at=plain.indexOf(token);if(at>=0)target=plain.slice(0,at)+'▢▢▢'+plain.slice(at+token.length);
    const quiz=[
      {type:'choice',prompt:lesson.question,options:lesson.choices||[],correct:lesson.answer,detail:lesson.explanation},
      {type:'fill',prompt:'Completa el código con la palabra o símbolo que falta.',code:target,correct:token,
        detail:'Utiliza exactamente el nombre o la sintaxis que aparece en el ejemplo. Las mayúsculas importan al programar.'}
    ];
    const code=codeQuestion(lesson,token);if(code)quiz.push(code);
    const original=plain.split('\n').map(x=>x.trimEnd()).filter(x=>x.trim());
    if(original.length>=2&&original.length<=5&&new Set(original).size===original.length){
      const items=original.map((line,id)=>({line,id}));let pool=shuffle(items,hash(lesson.id+'order'));
      if(pool.every((item,i)=>item.id===i))pool=[...pool.slice(1),pool[0]];
      quiz.push({type:'order',prompt:'Ordena estas líneas como en el ejemplo para reconstruir el fragmento.',
        lines:original,pool:pool.map(i=>i.id),detail:'Mira qué declaraciones van primero y dónde comienzan y terminan los bloques.'});
    }
    return quiz;
  }
  function get(project,lesson){const key=project.id+'::'+lesson.id;if(!sessions.has(key)){
      sessions.set(key,{step:0,hearts:MAX_HEARTS,selected:null,ordered:[],correct:0,misses:0,wrongSteps:[],reviewMode:false,reviewQueue:[],reviewCursor:0,validated:false,feedback:null,hint:false,streak:0,bestStreak:0,passed:project.completed.includes(lesson.id)});
    }return sessions.get(key)}
  function passed(project,lesson){return Boolean(get(project,lesson).passed)}
  function current(project,lesson){const s=get(project,lesson);return makeQuestions(lesson)[s.step]||null}
  function render(project,lesson){const s=get(project,lesson),items=makeQuestions(lesson),q=items[s.step];
    const tracker=`<div class="quiz-top"><div><span class="quiz-label">TU RETO ACTUAL</span><strong>${s.passed?'Reto superado':s.reviewMode?`Repaso de errores ${s.reviewCursor+1} de ${s.reviewQueue.length}`:`Pregunta ${Math.min(s.step+1,items.length)} de ${items.length}`}</strong></div><span class="quiz-hearts" aria-label="${s.hearts} intentos disponibles">${'♥'.repeat(s.hearts)}<span>${'♡'.repeat(MAX_HEARTS-s.hearts)}</span></span></div>
    <div class="quiz-track" role="progressbar" aria-label="Avance del cuestionario" aria-valuemin="0" aria-valuemax="${items.length}" aria-valuenow="${s.reviewMode?items.length:Math.min(s.step,items.length)}"><span style="width:${s.reviewMode?100:Math.min(100,s.step/items.length*100)}%"></span></div>`;
    if(s.passed)return `${tracker}<div class="quiz-pass"><div class="quiz-medal">🏆</div><h3>¡Cuestionario completado!</h3><p>Has respondido ${items.length} desafíos: alternativas, completar código y ${items.some(x=>x.type==='order')?'ordenar líneas':'reconocer sintaxis'}.</p><p>Ahora realiza el ejercicio de programación y revisa tu código para ganar los XP de la lección.</p></div>`;
    const answers = q.type==='choice'?`<div class="quiz-options">${q.options.map((item,i)=>`<button type="button" class="quiz-option ${s.selected===i?'chosen':''}" data-quiz-choice="${i}" ${s.validated||s.hearts===0?'disabled':''}><b>${String.fromCharCode(65+i)}</b><span>${esc(item)}</span></button>`).join('')}</div>`:
      q.type==='fill'?`<pre class="quiz-snippet">${esc(q.code)}</pre><label class="tiny-label" for="quiz-fill-answer">Escribe la parte que falta</label><input type="text" id="quiz-fill-answer" class="quiz-fill" autocomplete="off" spellcheck="false" value="${esc(s.selected||'')}" placeholder="Tu respuesta" ${s.validated||s.hearts===0?'disabled':''}/>`:
      q.type==='code'?`<div class="quiz-options quiz-code-options">${q.options.map((item,i)=>`<button type="button" class="quiz-option ${s.selected===i?'chosen':''}" data-quiz-choice="${i}" ${s.validated||s.hearts===0?'disabled':''}><b>${String.fromCharCode(65+i)}</b><code>${esc(item)}</code></button>`).join('')}</div>`:
      `<p class="subtle">Toca las líneas en el orden correcto. Puedes retirar una si te equivocas.</p><div class="quiz-assembly">${s.ordered.length?s.ordered.map((id,pos)=>`<button class="quiz-assembled" type="button" data-quiz-remove="${pos}" ${s.validated||s.hearts===0?'disabled':''}><span>${pos+1}.</span><code>${esc(q.lines[id])}</code><b>×</b></button>`).join(''):'<span class="quiz-placeholder">Aquí aparecerá tu código ordenado</span>'}</div><div class="quiz-pool">${q.pool.filter(id=>!s.ordered.includes(id)).map(id=>`<button type="button" data-quiz-line="${id}" ${s.validated||s.hearts===0?'disabled':''}><code>${esc(q.lines[id])}</code><span>＋</span></button>`).join('')}</div>`;
    const reviewMarker=s.reviewMode?`<div class="quiz-review-alert">🧠 <strong>Repasa lo que fallaste</strong><p>CODI recuperó una pregunta anterior para reforzarla. No pierdes tu progreso.</p></div>`:'';
    const feedback=s.feedback?`<div id="quiz-feedback" class="quiz-feedback ${s.feedback.ok?'correct':'incorrect'}" role="status"><strong>${s.feedback.ok?'✓ ¡Muy bien!':'↻ Intenta otra vez'}</strong><p>${esc(s.feedback.message)}</p></div>`:'<div id="quiz-feedback" aria-live="polite"></div>';
    const canCheck=q.type==='fill'?Boolean(String(s.selected??'').trim()):q.type==='order'?s.ordered.length===q.lines.length:Number.isInteger(s.selected);
    const controls=s.hearts===0&&!s.validated?`<div class="quiz-empty-hearts"><p>Te quedaste sin intentos. Repasa la explicación y vuelve a probar sin pagar ni esperar.</p><button class="secondary" type="button" data-quiz-refill>↻ Recuperar intentos gratis</button></div>`:
      `<div class="quiz-actions"><button type="button" class="ghost" data-quiz-hint aria-expanded="${s.hint}">💡 ${s.hint?'Ocultar pista':'Ver pista'}</button>${s.validated?`<button type="button" class="primary" data-quiz-next>${s.reviewMode?(s.reviewCursor===s.reviewQueue.length-1?'Terminar repaso →':'Seguir repasando →'):(s.step===items.length-1&&!s.wrongSteps.length?'Terminar preguntas →':'Continuar →')}</button>`:`<button type="button" class="primary" data-quiz-check ${canCheck?'':'disabled'}>Comprobar ✓</button>`}</div>`;
    return `${tracker}${reviewMarker}${root.CODITeam?.exerciseMoment(lesson,q,s)||''}<div class="quiz-heading"><h3>${q.type==='choice'?'Selecciona la respuesta':q.type==='fill'?'Completa el código':q.type==='code'?'Encuentra el fragmento correcto':'Ordena las instrucciones'}</h3><p class="quiz-kind">Tú decides. ${s.validated?'¡Listo! Pulsa Continuar.':'Después pulsa Comprobar para escuchar la reacción.'}</p></div>${answers}${s.hint?`<div class="quiz-hint"><strong>💡 Pista de CODI</strong><p>${esc(lesson.hint)}</p></div>`:''}${feedback}${controls}`;
  }
  function check(project,lesson,typed){const s=get(project,lesson);if(s.passed||s.validated||s.hearts<=0)return {ok:false,ignored:true};
    const q=current(project,lesson);if(q.type==='fill')s.selected=String(typed??s.selected??'');
    if((q.type==='fill'&&!String(s.selected??'').trim())||(q.type==='order'&&!s.ordered.length)||(['choice','code'].includes(q.type)&&!Number.isInteger(s.selected)))return {ok:false,ignored:true,reason:'empty'};
    const valid=q.type==='order'?s.ordered.length===q.lines.length&&s.ordered.every((id,index)=>id===index):
      q.type==='fill'?normalize(s.selected)===normalize(q.correct):Number.isInteger(s.selected)&&s.selected===q.correct;
    if(!valid){s.streak=0;s.misses++;if(!s.reviewMode&&!s.wrongSteps.includes(s.step))s.wrongSteps.push(s.step);s.hearts=Math.max(0,s.hearts-1);s.feedback={ok:false,message:q.type==='fill'?'Revisa cómo se escribe exactamente la parte que falta.':q.type==='order'?'Comprueba el orden de las líneas y vuelve a construirlas.':q.detail};return {ok:false,misses:s.misses};}
    s.correct++;s.streak=(s.streak||0)+1;s.bestStreak=Math.max(s.bestStreak||0,s.streak);s.validated=true;s.feedback={ok:true,message: q.type==='fill'?'¡Completaste la sintaxis correctamente!':q.type==='order'?'¡El orden coincide con el ejemplo!':q.type==='code'?'¡Identificaste el fragmento adecuado!':'¡Respuesta correcta!'};return {ok:true};
  }
  function next(project,lesson){const s=get(project,lesson),questions=makeQuestions(lesson);if(!s.validated)return false;
    if(s.reviewMode){
      s.reviewCursor++;
      if(s.reviewCursor>=s.reviewQueue.length){s.passed=true;return 'passed';}
      s.step=s.reviewQueue[s.reviewCursor];
    }else{
      s.step++;
      if(s.step>=questions.length){
        if(s.wrongSteps.length){
          s.reviewMode=true;s.reviewQueue=s.wrongSteps.slice();s.reviewCursor=0;s.step=s.reviewQueue[0];
        }else{s.passed=true;return 'passed';}
      }
    }
    s.validated=false;s.selected=null;s.ordered=[];s.feedback=null;s.hint=false;
    return 'next';}
  function select(project,lesson,choice){const s=get(project,lesson);if(s.validated||s.hearts===0)return;const q=current(project,lesson);
    if(['choice','code'].includes(q.type))s.selected=choice;
    if(q.type==='order'&&!s.ordered.includes(choice)&&q.lines[choice]!==undefined)s.ordered.push(choice);
    s.feedback=null;}
  function remove(project,lesson,position){const s=get(project,lesson);if(!s.validated&&s.hearts>0)s.ordered.splice(position,1);s.feedback=null;}
  function refill(project,lesson){const s=get(project,lesson);s.hearts=MAX_HEARTS;s.feedback=null;s.selected=null;s.ordered=[];}
  function hint(project,lesson){const s=get(project,lesson);s.hint=!s.hint;}
  function restart(project,lesson){sessions.set(project.id+'::'+lesson.id,{step:0,hearts:MAX_HEARTS,selected:null,ordered:[],correct:0,misses:0,wrongSteps:[],reviewMode:false,reviewQueue:[],reviewCursor:0,validated:false,feedback:null,hint:false,streak:0,bestStreak:0,passed:false});}
  function exportData(){return Object.fromEntries([...sessions.entries()].slice(0,180).map(([key,s])=>[key,{step:s.step,hearts:s.hearts,selected:s.selected,ordered:s.ordered,correct:s.correct,misses:s.misses,wrongSteps:s.wrongSteps,reviewMode:s.reviewMode,reviewQueue:s.reviewQueue,reviewCursor:s.reviewCursor,validated:s.validated,feedback:s.feedback,hint:s.hint,streak:s.streak,bestStreak:s.bestStreak,passed:s.passed}]))}
  function importData(records){sessions.clear();if(!records||typeof records!=='object'||Array.isArray(records))return false;
    for(const [key,x] of Object.entries(records).slice(0,180)){
      if(!/^[a-z0-9-]{4,70}::[a-z0-9-]{2,90}$/i.test(key)||!x||typeof x!=='object')continue;
      const safeNum=(n,max)=>Number.isInteger(n)?Math.max(0,Math.min(max,n)):0;
      sessions.set(key,{step:safeNum(x.step,20),hearts:safeNum(x.hearts,MAX_HEARTS),selected:typeof x.selected==='string'?x.selected.slice(0,150):Number.isInteger(x.selected)?x.selected:null,ordered:Array.isArray(x.ordered)?x.ordered.filter(Number.isInteger).slice(0,15):[],correct:safeNum(x.correct,40),misses:safeNum(x.misses,60),wrongSteps:Array.isArray(x.wrongSteps)?x.wrongSteps.filter(Number.isInteger).slice(0,20):[],reviewMode:!!x.reviewMode,reviewQueue:Array.isArray(x.reviewQueue)?x.reviewQueue.filter(Number.isInteger).slice(0,20):[],reviewCursor:safeNum(x.reviewCursor,20),validated:!!x.validated,feedback:x.feedback&&typeof x.feedback.message==='string'?{ok:x.feedback.ok===true,message:x.feedback.message.slice(0,350)}:null,hint:!!x.hint,streak:safeNum(x.streak,60),bestStreak:safeNum(x.bestStreak,60),passed:!!x.passed});
    }return true;
  }
  root.CODIQuiz=Object.freeze({makeQuestions,get,current,passed,render,check,next,select,remove,refill,hint,restart,exportData,importData,MAX_HEARTS});
})(window);
