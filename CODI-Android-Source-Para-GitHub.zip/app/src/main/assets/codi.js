/* CODI v0.7: reacciones visuales asociadas al progreso y a los ejercicios. */
'use strict';
(()=>{
  const variants={
    feliz:['¡Hola!','Poco a poco vas a construir cosas increíbles.'],
    emocionado:['¡Una idea nueva!','Transformaremos tu proyecto en pequeñas misiones.'],
    pensando:['Vamos a razonarlo','Lee la explicación y prueba un cambio a la vez.'],
    sorprendido:['¡Interesante!','Prueba el código y observa qué ocurre.'],
    confundido:['No pasa nada, repasa','Revisa las pistas y prueba otra respuesta.'],
    orgulloso:['¡Vas muy bien!','Has progresado. ¡Sigue practicando!'],
    celebrando:['¡MISIÓN COMPLETADA!','Un paso más cerca de construir tu proyecto.'],
    saludando:['¡Bienvenido!','Soy CODI, tu compañero de programación.'],
    motivando:['¡Tú puedes!','Dividir el problema en partes lo hace más sencillo.'],
    programando:['Modo programador','Prueba pequeñas partes antes de conectar todo.'],
    cansado:['Hora de descansar','Descansar también ayuda a aprender.'],
    error:['Revisemos ese error','Comprueba los mensajes y vuelve a intentarlo.']
  };
  const panel=document.getElementById('codi-companion-panel');
  const toggle=document.getElementById('codi-companion-toggle');
  const img=toggle.querySelector('img');
  let current='feliz', xpBeforeFinish=0;
  document.addEventListener('click',e=>{if(e.target.closest('[data-action="finish-lesson"]'))xpBeforeFinish=window.CodeQuestApp?.state.xp||0},true);
  function react(name='feliz',custom){
    if(!variants[name])name='pensando';current=name;
    img.src=window.CODI_REACTIONS?.[name]||`assets/reaction-${name}.webp`;
    document.getElementById('codi-stance').textContent=variants[name][0];
    document.getElementById('codi-line').textContent=custom||variants[name][1];
    toggle.title=variants[name][0]+': '+(custom||variants[name][1]);panel.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.closest('.codi-companion')?.classList.remove('codi-notice');void toggle.offsetWidth;toggle.closest('.codi-companion')?.classList.add('codi-notice');
  }
  function hide(){panel.hidden=true;toggle.setAttribute('aria-expanded','false')}
  toggle.addEventListener('click',()=>{if(!panel.hidden)return hide();panel.hidden=false;toggle.setAttribute('aria-expanded','true')});
  document.getElementById('codi-dismiss').addEventListener('click',hide);
  document.getElementById('codi-ask').addEventListener('click',()=>{hide();window.CodeQuestApp?.navigate('tutor')});
  // Ejecutar tras los manejadores principales; no evaluar el código del usuario.
  document.addEventListener('click',e=>{
    const el=e.target.closest('[data-action],[data-view],[data-coach]');if(!el)return;
    const action=el.dataset.action, view=el.dataset.view, coach=el.dataset.coach;
    if(action==='finish-lesson')setTimeout(()=>{if((window.CodeQuestApp?.state.xp||0)>xpBeforeFinish)react('celebrando');else react('confundido','Para avanzar debes aprobar tanto el código como la pregunta.')},0);
    if(action==='check-code')setTimeout(()=>{const f=document.querySelector('#code-feedback')?.textContent||'';react(/correcto|bien|completo|logrado|aprobado|cumple/i.test(f)?'orgulloso':/falt|error|incompleto/i.test(f)?'error':'pensando')},0);
    if(action==='check-quiz')setTimeout(()=>{const f=document.querySelector('#quiz-feedback')?.textContent||'';react(/correct|excelente|bien|acert/i.test(f)?'celebrando':'confundido')},0);
    if(action==='more-lessons')setTimeout(()=>react('emocionado'),0);
    if(view==='tutor'||coach)setTimeout(()=>react('pensando'),0);
  });
  document.addEventListener('submit',e=>{
    if(e.target.id==='create-form')setTimeout(()=>react('emocionado'),10);
    if(e.target.id==='tutor-form'||e.target.id==='lesson-ai-form')setTimeout(()=>react('programando'),10);
  });
  window.CODI={react,hide,variants};
})();
