'use strict';
const $ = selector => document.querySelector(selector);
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad = value => String(value).padStart(2,'0');
const todayLocal = () => {const d=new Date();return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`};
const yesterdayLocal = () => {const d=new Date();d.setDate(d.getDate()-1);return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`};
const KEY='codequest-progress-v1';
const defaultState = () => ({projects:[], activeId:null, xp:0, streak:0, lastActivity:null});
function loadState(){try{const v=JSON.parse(localStorage.getItem(KEY));return v&&Array.isArray(v.projects)?{...defaultState(),...v}:defaultState()}catch{return defaultState()}}
let lessonPhase='learn', lessonSaveTimer=null;
let teachingStep=0, teachingLine=0, teachingChoice=null, teachingSolved=false, teachingFeedback='', teachingReady=false;
let state=loadState(), view=state.projects.length?'route':'home', selectedAnswer=null, codeFeedback=null, quizFeedback=null, chat=[], lastTutorQuestion='', lastTutorIntent='', lastExpertReview=null, lastLessonReview=null, expertDraft='', expertSelectedLanguage='';
let localStorageWarned=false;
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(state))}catch{if(!localStorageWarned){localStorageWarned=true;toast('El navegador no permite guardar automáticamente. Exporta un respaldo para conservar tus avances.')}}updateStats();window.CODIAccount?.schedule()};
const active=()=>state.projects.find(p=>p.id===state.activeId)||null;
const currentLesson=()=>active()?.lessons.find(l=>l.id===active()?.lessonId)||null;
const isDone=(p, id)=>p.completed.includes(id);
function updateStats(){$('#xp-count').textContent=String(state.xp);$('#streak-count').textContent=String(state.streak);window.CODIAdventure?.syncXP(state.xp)}
function activity(){const d=todayLocal();if(state.lastActivity!==d){state.streak=state.lastActivity===yesterdayLocal()?state.streak+1:1;state.lastActivity=d}}
let toastTimer;function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3500)}
const lesson=(id,title,objective,explanation,example,starter,checks,question,choices,answer,hint)=>({id,title,objective,explanation,example,starter,checks,question,choices,answer,hint,xp:50});
// Los chequeos son verificaciones educativas de texto, NO ejecución de código ni un compilador.
const paths={
 web:{label:'Web · HTML, CSS y JavaScript',emoji:'🌐',lessons:[
  lesson('web1','Tu primera página','Construir una página con un título','HTML define la estructura de una página. Un título principal se escribe con la etiqueta h1. Cambia el texto para que describa tu proyecto.','<h1>Mi primera aplicación</h1>','<!-- Crea aquí tu título -->\n', ['<h1','</h1>'],'¿Para qué sirve HTML?',['Para dar estructura al contenido','Para guardar contraseñas','Para instalar aplicaciones'],0,'Una etiqueta de apertura y otra de cierre forman el título.'),
  lesson('web2','Dale tu estilo','Cambiar colores utilizando CSS','CSS controla cómo se ve tu página. Con background puedes elegir un color de fondo. Escribe una regla CSS para body.','body {\n  background: #172554;\n  color: white;\n}','body {\n  /* Agrega un color de fondo */\n}', ['body','background',':'],'¿Qué lenguaje cambia colores y tamaños?',['HTML','CSS','SQL'],1,'Prueba con background: #14213d; dentro de body.'),
  lesson('web3','Haz que responda','Crear un botón y reaccionar a un clic','JavaScript agrega interactividad. addEventListener permite responder cuando una persona pulsa un botón.','const boton = document.querySelector("button");\nboton.addEventListener("click", () => {\n  alert("¡Hola!");\n});','const boton = document.querySelector("button");\n// Escucha el clic aquí\n', ['addEventListener','click'],'¿Qué evento detecta cuando se pulsa un botón?',['scroll','click','load'],1,'Utiliza boton.addEventListener("click", () => { ... });'),
  lesson('web4','Recibe datos','Leer lo que una persona escribe','Un campo input recibe texto. La propiedad value permite leer su contenido cuando se necesita.','const campo = document.querySelector("input");\nconst texto = campo.value;\nconsole.log(texto);','const campo = document.querySelector("input");\n// Obtén el texto escrito\n', ['.value'],'¿Qué propiedad obtiene el texto de un input?',['value','height','color'],0,'Lee campo.value y guárdalo en una constante.'),
  lesson('web5','Guarda el progreso','Usar almacenamiento local en el navegador','localStorage guarda datos pequeños en el dispositivo. Puedes usar setItem para guardar y getItem para recuperar.','localStorage.setItem("progreso", "1");\nconst guardado = localStorage.getItem("progreso");','// Guarda un dato llamado "progreso"\n', ['localStorage','setItem'],'¿Cuál guarda un valor?',['localStorage.setItem','console.clear','document.reload'],0,'Prueba localStorage.setItem("progreso", "1");'),
  lesson('web6','Para cualquier pantalla','Adaptar el diseño al celular','Una media query adapta el sitio al tamaño de pantalla. @media permite definir reglas especiales para teléfonos.','@media (max-width: 600px) {\n  h1 { font-size: 25px; }\n}','/* Estilo para pantallas pequeñas */\n', ['@media','max-width'],'¿Qué permite cambiar estilos según el ancho?',['@media','<script>','print'],0,'Comienza con @media (max-width: 600px) { ... }')
 ]},
 roblox:{label:'Roblox · Luau',emoji:'🎮',lessons:[
  lesson('rb1','Tu primera variable','Guardar información en Luau','En Roblox Studio, Luau usa local para definir variables. Los nombres ayudan a organizar el juego.','local puntos = 0\nprint(puntos)','-- Crea una variable llamada puntos\n',['local','puntos','=','0'],'¿Qué palabra crea una variable local?',['let','local','var'],1,'Escribe local puntos = 0'),
  lesson('rb2','Construye un objeto','Crear una parte en el mundo','Instance.new("Part") crea una pieza. Asignar Parent a workspace hace que aparezca en el mundo.','local parte = Instance.new("Part")\nparte.Parent = workspace','-- Crea una pieza que aparezca en el mundo\n',['Instance.new','Part','workspace'],'¿Dónde están los objetos visibles del mundo?',['ServerStorage','workspace','ReplicatedFirst'],1,'Crea Instance.new("Part") y establece Parent = workspace.'),
  lesson('rb3','Dale propiedades','Modificar tamaño y posición','Vector3.new representa tres coordenadas o dimensiones. Sirve para Size y Position de una Part.','local parte = Instance.new("Part")\nparte.Size = Vector3.new(6, 2, 6)\nparte.Parent = workspace','local parte = Instance.new("Part")\n-- Cambia su tamaño\nparte.Parent = workspace',['.Size','Vector3.new'],'¿Qué representa Vector3?',['Tres números de posición o tamaño','Una imagen','Una lista de jugadores'],0,'Asigna parte.Size = Vector3.new(6, 2, 6).'),
  lesson('rb4','Detecta al jugador','Responder al contacto','Touched se activa al tocar una Part. Con Connect enlazas una función al evento.','parte.Touched:Connect(function(contacto)\n  print("¡Contacto!")\nend)','local parte = script.Parent\n-- Detecta un contacto\n',['Touched',':Connect'],'¿Qué evento detecta el contacto con una pieza?',['Clicked','Touched','ChangedOnly'],1,'Usa parte.Touched:Connect(function(contacto) ... end).'),
  lesson('rb5','Crea una función','Reutilizar acciones','Las funciones organizan acciones que puedes ejecutar varias veces. En Luau se definen con function y terminan con end.','local function saludar(nombre)\n  print("Hola " .. nombre)\nend\nsaludar("Jugador")','-- Crea una función saludar\n',['function','end'],'¿Qué palabra finaliza el bloque de una función Luau?',['stop','end','close'],1,'Prueba local function saludar(nombre) ... end.'),
  lesson('rb6','Prueba tu juego','Detectar problemas','Los mensajes en Output ayudan a comprobar el código. print muestra valores y warn muestra advertencias.','print("Empezó la prueba")\nwarn("Revisa las colisiones")','-- Escribe un mensaje y una advertencia\n',['print','warn'],'¿Qué ventana de Roblox Studio muestra print?',['Output','Explorer','Properties'],0,'Escribe print("Listo") y warn("Comprobar").')
 ]},
 minecraft:{label:'Minecraft Bedrock · Add-ons',emoji:'⛏️',lessons:[
  lesson('mc1','Tu primer manifiesto','Entender cómo se registra un add-on','Cada paquete usa un manifest.json con formato_version, header y modules. El juego necesita identificadores UUID únicos para instalaciones reales.','{\n "format_version": 2,\n "header": {"name":"Mi Add-on"},\n "modules": []\n}','{\n  "format_version": 2\n}\n', ['format_version','header','modules'],'¿Qué archivo describe un paquete Bedrock?',['manifest.json','readme.txt','world.png'],0,'Agrega "header" y "modules". Este es un ejercicio simplificado, no un manifiesto instalable.'),
  lesson('mc2','Datos en JSON','Añadir una propiedad','Los archivos JSON organizan datos con llaves y valores. Usa comillas dobles para las claves y no pongas comas finales.','{\n  "nombre": "Mi bloque",\n  "resistencia": 3\n}','{\n  "nombre": "Mi bloque"\n}\n', ['"nombre"','"resistencia"'],'¿Qué símbolo separa clave y valor en JSON?',[':',';','#'],0,'Añade ",resistencia":3 como otra propiedad, respetando JSON.'),
  lesson('mc3','JavaScript en Bedrock','Importar las funciones de Script API','El módulo @minecraft/server permite trabajar con eventos y jugadores en un behavior pack compatible.','import { world } from "@minecraft/server";\nworld.sendMessage("¡Hola mundo!");','// Importa world y envía un saludo\n', ['@minecraft/server','world.sendMessage'],'¿Cuál es el módulo principal de la Script API?',['@minecraft/server','@roblox/game','minecraft.java'],0,'Importa world y usa world.sendMessage("Hola").'),
  lesson('mc4','Reacciona a eventos','Ejecutar código cuando aparece un jugador','Los eventos afterEvents permiten escuchar acciones. playerSpawn.subscribe recibe una función cuando aparece un jugador.','world.afterEvents.playerSpawn.subscribe((evento) => {\n  evento.player.sendMessage("¡Bienvenido!");\n});','// Ya importaste world\n// Escucha playerSpawn\n', ['playerSpawn','subscribe'],'¿Qué método escucha un evento?',['subscribe','print','removeAll'],0,'Usa world.afterEvents.playerSpawn.subscribe((evento)=>{ ... });'),
  lesson('mc5','Habla con el jugador','Enviar mensajes desde tu script','La propiedad player de un evento puede apuntar al jugador. sendMessage muestra texto en su chat.','const jugador = evento.player;\njugador.sendMessage("Misión iniciada");','const jugador = evento.player;\n// Envía el texto de misión\n', ['sendMessage','jugador'],'¿Cuál envía un mensaje al jugador?',['addTag','sendMessage','teleport'],1,'Usa jugador.sendMessage("Hola");'),
  lesson('mc6','Prepara la prueba','Construir un checklist antes de importar','La compatibilidad depende de versión, dependencias, permisos y comportamiento real. Una prueba en Minecraft sigue siendo obligatoria.','const comprobaciones = ["manifest", "dependencias", "mundo real"];\nconsole.log(comprobaciones);','// Crea una lista de comprobaciones\n', ['const','[',']'],'¿Qué confirma que un add-on realmente funciona?',['Que un ejemplo se vea bien','Probarlo dentro de Minecraft Bedrock','Que alguien diga que funciona'],1,'Usa un arreglo const comprobaciones = ["manifest", "mundo"];')
 ]},
 python:{label:'Python · Desde cero',emoji:'🐍',lessons:[
  lesson('py1','Tu primer mensaje','Mostrar texto en pantalla','print es una función que escribe mensajes. Pon el texto entre comillas.','print("¡Hola, mundo!")','// Escribe tu primer mensaje en Python\n'.replace('//','#'),['print','(',')'],'¿Qué función muestra texto?',['echo','print','alert'],1,'Escribe print("Hola").'),
  lesson('py2','Guarda información','Crear variables','Una variable guarda un dato. En Python se asigna usando =, sin declarar let ni local.','puntos = 10\nprint(puntos)','# Guarda un número en puntos\n', ['puntos','='],'¿Qué operador asigna un valor?',['==','=','!='],1,'Escribe puntos = 10.'),
  lesson('py3','Escucha al usuario','Leer datos con input','input muestra una pregunta y devuelve el texto escrito. Puedes guardar su respuesta en una variable.','nombre = input("¿Cómo te llamas? ")\nprint(nombre)','# Pregunta el nombre\n', ['input','nombre'],'¿Qué función lee lo escrito?',['read','input','print'],1,'Prueba nombre = input("Tu nombre: ").'),
  lesson('py4','Decide qué hacer','Usar condiciones if','if ejecuta una instrucción cuando una condición es verdadera. Python utiliza : e indentación.','edad = 15\nif edad >= 13:\n    print("Puedes entrar")','edad = 15\n# Comprueba si tiene 13 o más\n', ['if',':'],'¿Qué palabra inicia una condición?',['if','while','class'],0,'Escribe if edad >= 13: y una línea indentada.'),
  lesson('py5','Repite una acción','Utilizar un bucle for','for repite instrucciones. range(3) genera los números 0, 1 y 2.','for i in range(3):\n    print(i)','# Repite una acción 3 veces\n', ['for','range',':'],'¿Cuántas veces itera range(3)?',['2','3','4'],1,'Utiliza for i in range(3):'),
  lesson('py6','Construye funciones','Organizar tu proyecto','Una función agrupa pasos reutilizables y comienza con def. Puedes llamarla cuando la necesites.','def saludar():\n    print("¡Hola!")\nsaludar()','# Crea una función llamada saludar\n', ['def','saludar','('],'¿Qué palabra define una función Python?',['function','def','fun'],1,'Prueba def saludar(): y luego saludar().')
 ]},
 javascript:{label:'JavaScript · Lógica y apps',emoji:'⚡',lessons:[
  lesson('js1','Variables con sentido','Guardar el estado de tu proyecto','const declara valores que no se reasignan. let permite actualizar el dato.','let puntos = 0;\npuntos = puntos + 1;','// Crea una variable puntos\n', ['let','puntos'],'¿Cuál permite reasignar un valor?',['const','let','import'],1,'Escribe let puntos = 0;'),
  lesson('js2','Escribe funciones','Agrupar instrucciones','Una función recibe parámetros y puede devolver resultados usando return.','function sumar(a, b) {\n  return a + b;\n}','// Crea una función sumar(a, b)\n', ['function','return'],'¿Qué palabra devuelve un resultado?',['return','console','give'],0,'Escribe function sumar(a,b) { return a+b; }'),
  lesson('js3','Toma decisiones','Comparar datos','if permite ejecutar acciones según el resultado de una comparación. Las llaves delimitan el bloque.','if (puntos > 10) {\n  console.log("¡Nivel superado!");\n}','let puntos = 15;\n// Verifica si hay más de 10 puntos\n', ['if','puntos','>'],'¿Qué símbolo significa mayor que?',['<','>','==='],1,'Prueba if (puntos > 10) { ... }'),
  lesson('js4','Trabaja con listas','Guardar múltiples elementos','Un array agrupa valores. push agrega un elemento al final de la lista.','const tareas = ["Diseñar"];\ntareas.push("Programar");','const tareas = ["Diseñar"];\n// Agrega otra tarea\n', ['tareas','.push'],'¿Qué método añade un elemento al final de un array?',['push','slice','indexOf'],0,'Utiliza tareas.push("Probar");'),
  lesson('js5','Recorre tus datos','Usar bucles','for...of permite recorrer cada elemento de un array para trabajar con él.','const tareas = ["Diseñar", "Programar"];\nfor (const tarea of tareas) {\n  console.log(tarea);\n}','const tareas = ["Diseñar", "Programar"];\n// Muestra cada tarea\n', ['for','of'],'¿Qué sintaxis recorre elementos?',['for...of','try...catch','if...else'],0,'Escribe for (const tarea of tareas) { console.log(tarea); }'),
  lesson('js6','Guarda los cambios','Convertir datos a JSON','JSON.stringify convierte datos en texto, útil para guardarlos en localStorage.','const datos = {nivel: 2};\nlocalStorage.setItem("datos", JSON.stringify(datos));','const datos = { nivel: 2 };\n// Guarda datos como JSON\n', ['JSON.stringify','localStorage'],'¿Qué convierte un objeto en texto JSON?',['JSON.parse','JSON.stringify','Array.isArray'],1,'Usa JSON.stringify(datos) dentro de localStorage.setItem.')
 ]}
};
// v0.5: conservar las seis lecciones originales y sumar ocho más por ruta.
for (const [track, lessons] of Object.entries(window.CodeQuestExtraLessons || {})) {
  if (paths[track]) paths[track].lessons.push(...lessons);
}
// Migración sin borrar progreso, código o XP de las versiones anteriores.
for (const project of state.projects) {
  const route = paths[project.track];
  if (!route || !Array.isArray(project.lessons)) continue;
  const seen = new Set(project.lessons.map(l=>l.id));
  project.lessons.push(...route.lessons.filter(l=>!seen.has(l.id)).map(l=>({...l})));
  project.completed = Array.isArray(project.completed) ? project.completed : [];
  project.drafts = project.drafts && typeof project.drafts==='object' ? project.drafts : {};
}
function choosePath(text,lang){return lang==='auto'?(CodeQuestAI.track(text).label||'web'):lang}
function personalizedLessons(track,goal,purpose){return paths[track].lessons.map((l,i)=>({...l,explanation:l.explanation+(i===0?` Tu meta es: ${goal}. ${purpose?'Lo quieres para: '+purpose+'.':''}`:''),xp:50}))}
function makeProject(goal,purpose,lang,level){const track=choosePath(`${goal} ${purpose}`,lang);return {id:Math.random().toString(36).slice(2)+Date.now().toString(36),goal,purpose,track,level,createdAt:new Date().toISOString(),lessons:personalizedLessons(track,goal,purpose),completed:[],drafts:{},lessonId:null,generatedCount:0,aiGenerated:true,aiEngine:'local-v0.6'}}
function beginOnboardCourse(goal,purpose,track,level,placementStart){
 if(!paths[track])track='web';
 const p=makeProject(String(goal).slice(0,280),String(purpose).slice(0,400),track,['beginner','some','advanced'].includes(level)?level:'beginner');
 p.placementStart=Math.min(4,Math.max(0,Number(placementStart)||0));
 state.projects.unshift(p);state.activeId=p.id;save();render();return p;
}
function routeUnlocked(p,i){return i<=Math.max(0,Math.min(4,Number(p.placementStart)||0))||p.completed.includes(p.lessons[i-1]?.id)||(p.lessons[i]?.generated&&!p.lessons[i-1]?.generated)}
function navigate(next){if(next==='settings'&&!window.CODINavigation)return;if(view==='lesson')persistLessonDraft();view=next;selectedAnswer=null;codeFeedback=null;quizFeedback=null;$('#sidebar').classList.remove('open');window.CODINavigation?.closeMore();document.querySelectorAll('[data-view]').forEach(e=>e.classList.toggle('active',e.dataset.view===next));render();window.scrollTo({top:0,behavior:'instant'})}
function setActive(projectId){const p=state.projects.find(x=>x.id===projectId);if(!p)return;state.activeId=projectId;save();navigate('route')}
function createProject(event){event.preventDefault();const form=event.target;const goal=form.elements.goal.value.trim(),purpose=form.elements.purpose.value.trim(),lang=form.elements.language.value,level=form.elements.level.value;if(goal.length<8){toast('Cuenta un poco más sobre qué quieres crear (mínimo 8 caracteres).');return}if(goal.length>280||purpose.length>400){toast('Usa una descripción más corta para empezar.');return}const p=makeProject(goal,purpose,lang,level);state.projects.unshift(p);state.activeId=p.id;save();toast('¡Tu ruta está lista! IA local creada desde cero, sin internet.');navigate('route')}
const milestones={
 roblox:[['Preparar Roblox Studio','Abre un lugar de prueba y activa Explorer y Output.'],['Crear el prototipo','Construye una Part y programa una interacción pequeña con Luau.'],['Probar con jugadores','Ejecuta Play y revisa Output; prueba el juego como jugador.'],['Publicar con cuidado','Configura permisos y publica una versión de prueba cuando funcione.']],
 minecraft:[['Preparar el add-on','Crea carpetas de behavior pack y un manifest.json válido para tu versión.'],['Crear una función pequeña','Agrega un script que salude cuando entre un jugador.'],['Importar en Minecraft','Prueba el .mcpack en la versión Bedrock correcta y revisa el Content Log.'],['Iterar','Corrige errores, verifica los logros y comprueba compatibilidad.']],
 web:[['Definir una pantalla','Esboza el objetivo principal de tu sitio o aplicación.'],['Construir la interfaz','Crea estructura HTML y estilos CSS para móvil.'],['Agregar una interacción','Haz funcionar un botón o un formulario con JavaScript.'],['Revisar y publicar','Prueba en móvil y computadora antes de compartir la web.']],
 python:[['Elegir una tarea','Define exactamente qué datos entran y qué resultado esperas.'],['Hacer el primer script','Escribe un archivo .py y ejecútalo en Python.'],['Añadir decisiones','Valida entradas y separa el código en funciones.'],['Probar casos reales','Comprueba qué sucede con entradas correctas e incorrectas.']],
 javascript:[['Diseñar la lógica','Escribe qué datos utilizará tu aplicación.'],['Crear funciones','Implementa una función para la primera acción del usuario.'],['Manejar datos','Introduce listas y condiciones para cambiar el estado.'],['Integrar y probar','Conecta la lógica a una interfaz o a Node.js.']]
};
function projectSteps(p){return CodeQuestAI.createPlan(p.goal,p.purpose,p.track,p.level)}
function codeExt(track){return {web:'html',roblox:'lua',minecraft:'js',python:'py',javascript:'js'}[track]||'txt'}
function downloadText(name,content,type='text/plain;charset=utf-8'){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),500)}
function cloudSnapshot(){return {format:'codequest-backup',version:7,exportedAt:null,state,aiMemory:CodeQuestAI.exportMemory(),academy:CodeQuestAcademy.exportData(),adventure:CODIAdventure.exportData(),team:CODITeam.exportData(),onboarding:window.CODIOnboarding?.exportData()||null,quiz:CODIQuiz.exportData?.()||{}}}
function exportProgress(){downloadText('codi-respaldo.json',JSON.stringify({...cloudSnapshot(),exportedAt:new Date().toISOString()},null,2),'application/json');toast('Respaldo exportado. Guárdalo en un lugar seguro.')}
function loadCloudSnapshot(data){
 if(!data||data.format!=='codequest-backup'||!data.state||!Array.isArray(data.state.projects))return false;
 const projects=data.state.projects.slice(0,100).map(q=>{
  if(!q||!paths[q.track]||typeof q.goal!=='string'||q.goal.length>280||!q.goal.trim())return null;
  const p=makeProject(q.goal,String(q.purpose||'').slice(0,400),q.track,['beginner','some','advanced'].includes(q.level)?q.level:'beginner');
  p.id=/^[a-z0-9-]{4,70}$/i.test(q.id)?q.id:p.id;
  p.createdAt=Number.isNaN(Date.parse(q.createdAt))?p.createdAt:q.createdAt;
  const amount=Number.isInteger(q.generatedCount)?Math.max(0,Math.min(CodeQuestInfinite.max,q.generatedCount)):0;
  p.lessons.push(...CodeQuestInfinite.buildBatch(p,0,0));
  for(let n=0;n<amount;n+=4)p.lessons.push(...CodeQuestInfinite.buildBatch(p,n,Math.min(4,amount-n)));
  p.generatedCount=amount;p.placementStart=Math.max(0,Math.min(4,Number(q.placementStart)||0));
  p.completed=Array.isArray(q.completed)?[...new Set(q.completed.filter(id=>p.lessons.some(l=>l.id===id)))]:[];
  p.drafts={};if(q.drafts&&typeof q.drafts==='object')for(const l of p.lessons){if(typeof q.drafts[l.id]==='string')p.drafts[l.id]=q.drafts[l.id].slice(0,20000)}
  return p;
 }).filter(Boolean);
 state=defaultState();state.projects=projects;state.activeId=projects.some(p=>p.id===data.state.activeId)?data.state.activeId:projects[0]?.id||null;
 state.xp=projects.reduce((sum,p)=>sum+p.completed.length*50,0);
 state.streak=Number.isInteger(data.state.streak)?Math.min(3650,Math.max(0,data.state.streak)):0;
 state.lastActivity=/^\d{4}-\d{2}-\d{2}$/.test(data.state.lastActivity)?data.state.lastActivity:null;
 if(data.aiMemory)CodeQuestAI.importMemory(data.aiMemory);
 if(data.academy)CodeQuestAcademy.importData(data.academy);
 if(data.adventure)CODIAdventure.importData(data.adventure);
 if(data.team)CODITeam.importData(data.team);
 if(data.onboarding)window.CODIOnboarding?.importData(data.onboarding);
 if(data.quiz)CODIQuiz.importData?.(data.quiz);
 state.xp=Math.max(state.xp,Math.min(1000000,Number(data.state.xp)||0));
 try{localStorage.setItem(KEY,JSON.stringify(state))}catch{};
 view=state.projects.length?'route':'home';codeFeedback=null;quizFeedback=null;
 render();if(data.onboarding)window.CODIOnboarding?.hide?.();return true;
}

async function importProgress(file){if(!file)return;try{if(file.size>2_000_000)throw Error('Archivo demasiado grande');const data=JSON.parse(await file.text());if(data.format!=='codequest-backup'||!data.state||!Array.isArray(data.state.projects))throw Error('No parece ser un respaldo válido de CODI');const projects=data.state.projects.slice(0,100).map(q=>{if(!q||!paths[q.track]||typeof q.goal!=='string'||q.goal.length>280||!q.goal.trim())return null;const p=makeProject(q.goal,String(q.purpose||'').slice(0,400),q.track,['beginner','some','advanced'].includes(q.level)?q.level:'beginner');p.id=/^[a-z0-9-]{4,70}$/i.test(q.id)?q.id:p.id;p.createdAt=Number.isNaN(Date.parse(q.createdAt))?p.createdAt:q.createdAt;const amount=Number.isInteger(q.generatedCount)?Math.max(0,Math.min(CodeQuestInfinite.max,q.generatedCount)):0;p.lessons.push(...CodeQuestInfinite.buildBatch(p,0,0));for(let n=0;n<amount;n+=4)p.lessons.push(...CodeQuestInfinite.buildBatch(p,n,Math.min(4,amount-n)));p.generatedCount=amount;p.placementStart=Math.max(0,Math.min(4,Number(q.placementStart)||0));p.completed=Array.isArray(q.completed)?[...new Set(q.completed.filter(id=>p.lessons.some(l=>l.id===id)))]:[];p.drafts={};if(q.drafts&&typeof q.drafts==='object')for(const l of p.lessons){if(typeof q.drafts[l.id]==='string')p.drafts[l.id]=q.drafts[l.id].slice(0,20000)}return p}).filter(Boolean);if(!projects.length)throw Error('El respaldo no contiene proyectos válidos');if(!confirm(`¿Reemplazar tus proyectos actuales con ${projects.length} del respaldo?`))return;state=defaultState();state.projects=projects;state.activeId=projects[0].id;state.xp=projects.reduce((sum,p)=>sum+p.completed.length*50,0);state.streak=Number.isInteger(data.state.streak)?Math.min(3650,Math.max(0,data.state.streak)):0;state.lastActivity=/^\d{4}-\d{2}-\d{2}$/.test(data.state.lastActivity)?data.state.lastActivity:null;if(data.aiMemory)CodeQuestAI.importMemory(data.aiMemory);if(data.academy)CodeQuestAcademy.importData(data.academy);if(data.adventure)CODIAdventure.importData(data.adventure);if(data.team)CODITeam.importData(data.team);if(data.onboarding)window.CODIOnboarding?.importData(data.onboarding);state.xp=Math.max(state.xp,Math.min(1000000,Number(data.state.xp)||0));save();navigate('home');toast('¡Respaldo restaurado!')}catch(e){toast(`No se pudo importar: ${e.message}`)}}
function deleteProject(){const p=active();if(!p||!confirm(`¿Eliminar el proyecto «${p.goal}»? Esto no se puede deshacer.`))return;state.projects=state.projects.filter(x=>x.id!==p.id);state.activeId=state.projects[0]?.id||null;state.xp=state.projects.reduce((sum,p)=>sum+p.completed.length*50,0);save();navigate('home');toast('Proyecto eliminado.')}
function downloadCode(){const p=active(),l=currentLesson();if(!p||!l)return;const raw=$('#student-code')?.value||'';const webCSS=p.track==='web'&&['web2','web6','web8','web9','web12'].includes(l.id);const webJS=p.track==='web'&&['web3','web4','web11'].includes(l.id);const ext=webCSS?'css':webJS?'js':p.track==='minecraft'&&['mc7','mc8','mc9','mc10','mc13','mc14'].includes(l.id)?'json':codeExt(p.track);let content=raw;if(p.track==='web'){
  if(l.id==='web1')content=`<!doctype html>\n<html lang="es"><meta charset="utf-8"><title>Mi proyecto</title><body>\n${raw}\n</body></html>`;
  else if(['web2','web6','web8','web9','web12'].includes(l.id))content=raw;
}downloadText(`${l.id}-${p.track}.${ext}`,content);toast('Código descargado.')}
const stripComments=(raw,track)=>{let s=raw.replace(/\/\*[\s\S]*?\*\//g,'').replace(/<!--[\s\S]*?-->/g,'');if(track==='python')return s.replace(/^\s*#.*$/gm,'');if(track==='roblox')return s.replace(/--[^\n]*/g,'');return s.replace(/(^|\n)\s*\/\/[^\n]*/g,'$1')};
function previewHTML(lesson,raw){const content=raw.replace(/<\/script/gi,'<\\/script');const meta=`<meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; connect-src 'none'; form-action 'none'">`;
  if(lesson.id==='web1')return `${meta}<style>body{font-family:sans-serif;padding:20px}</style>${content}`;
  if(['web2','web6','web8','web9','web12'].includes(lesson.id))return `${meta}<style>${content}</style><main><h1>Mi aplicación</h1><p>Así se verá tu diseño.</p><button>Botón de ejemplo</button></main>`;
  if(lesson.id==='web3')return `${meta}<button style="padding:16px;border-radius:10px;cursor:pointer">Haz clic aquí</button><p>Tu JavaScript se probará aquí.</p><script>${content}</script>`;
  if(['web7','web10','web13','web14'].includes(lesson.id))return `${meta}${content}`;
  if(lesson.id==='web11')return `${meta}<input placeholder="Escribe aquí"><div id="salida"></div><script>${content}</script>`;
  if(lesson.id==='web4')return `${meta}<input placeholder="Escribe aquí" value="CODI"><p>Revisa la consola para observar la lectura.</p><script>${content}</script>`;
  return null;
}
function previewCode(){const p=active(),l=currentLesson();if(!p||!l)return;const html=previewHTML(l,$('#student-code').value);if(!html)return toast('Esta lección no tiene vista previa visual; descarga el código para probarlo.');const frame=$('#web-preview');if(frame){frame.srcdoc=html;frame.hidden=false;toast('Vista previa actualizada. Se ejecuta aislada.')}}

const fmtDate = value => new Date(value).toLocaleDateString('es-CL',{day:'numeric',month:'short',year:'numeric'});
function heroArt(){return `<div class="hero-art codi-hero-art" aria-hidden="true"><img src="assets/mascot.webp" class="codi-hero-mascot" alt="" width="480" height="480"/><span class="codi-hero-spark">&lt;/&gt;</span></div>`}
function renderHome(){const p=active();$('#breadcrumb').textContent='Panel de aprendizaje';return `<div class="hero"><div class="hero-copy"><div class="eyebrow">✦ IA LOCAL CREADA DESDE CERO · SIN SERVICIOS EXTERNOS</div><h1>De una idea a <em>tu próximo gran proyecto.</em></h1><p class="lead">Aprende a programar construyendo lo que de verdad te interesa. Sin clases aburridas, a tu ritmo y desde cero.</p><div class="actions"><button class="primary" data-action="focus-create">✦ Crear mi ruta de aprendizaje →</button>${p?'<button class="secondary" data-view="route">Continuar mi ruta</button>':''}</div></div>${heroArt()}</div>
  ${p?`<div class="section-head"><h2>Continúa donde quedaste</h2><span class="badge">${escapeHTML(paths[p.track]?.emoji||'💡')} En progreso</span></div><div class="panel panel-accent"><div class="project-summary"><div><span class="overline">PROYECTO ACTUAL</span><h2>${escapeHTML(p.goal)}</h2><p class="subtle">${escapeHTML(paths[p.track]?.label||p.track)} · ${p.completed.length} de ${p.lessons.length} lecciones</p></div><div><span class="big-num">${Math.round(100*p.completed.length/p.lessons.length)}%</span><p class="tiny-label">Completado</p></div></div><div class="progress-track"><div class="progress-bar" style="width:${100*p.completed.length/p.lessons.length}%"></div></div><div class="actions mt-20"><button class="primary" data-view="route">Abrir mi ruta →</button></div></div>`:''}
  ${CODIAdventure.homeDash(p)}<div class="section-head"><h2>Tu academia</h2><span class="subtle">Elige cómo quieres aprender</span></div><div class="codi-feature-menu">
  ${[['route','aprender','Aprender','Avanza en tus lecciones'],['practice','practicar','Practicar','Pon a prueba lo aprendido'],['projects','proyectos','Proyectos','Programa en tu taller'],['tutor','tutor','Tutor CODI','Resuelve dudas y revisa código']].map(([id,icon,title,desc])=>`<button class="codi-feature" data-view="${id}"><img src="${window.CODI_MEDIA?.[icon]||('assets/'+icon+'.webp')}" alt="" loading="lazy"/><span><strong>${title}</strong><small>${desc}</small></span><b aria-hidden="true">↗</b></button>`).join('')}
</div><div class="section-head" id="create-section"><h2>¿Qué quieres crear?</h2><span class="subtle">Empieza aquí ↓</span></div><form class="panel" id="create-form"><div class="form-grid"><div class="form-field full"><label for="goal">Tu gran idea</label><textarea name="goal" id="goal" minlength="8" maxlength="280" required placeholder="Ej.: Quiero crear un juego de Roblox donde los jugadores sobrevivan a desastres"></textarea></div><div class="form-field full"><label for="purpose">¿Para qué servirá?</label><input name="purpose" id="purpose" maxlength="400" placeholder="Ej.: Para jugar con amigos, aprender y publicarlo"/></div><div class="form-field"><label for="language">¿Dónde quieres crearlo?</label><select id="language" name="language"><option value="auto">✨ Recomiéndame una ruta</option><option value="web">🌐 Sitio web / app web</option><option value="roblox">🎮 Roblox Studio (Luau)</option><option value="minecraft">⛏️ Minecraft Bedrock (add-ons)</option><option value="python">🐍 Python</option><option value="javascript">⚡ JavaScript</option></select></div><div class="form-field"><label for="level">Tu experiencia</label><select id="level" name="level"><option value="beginner">Estoy empezando</option><option value="some">Sé algunas cosas</option><option value="advanced">Ya sé programar</option></select></div></div><div class="actions mt-20"><button type="submit" class="primary">Crear ruta gratuita →</button><span class="hint-small">Modelo local entrenable · Sin conexión a IA externa</span></div></form>
  <div class="section-head"><h2>Tu progreso, bajo tu control</h2></div><div class="panel"><p class="subtle">Todo queda guardado solo en este navegador. Puedes llevar tus proyectos a otro dispositivo con un archivo de respaldo.</p><div class="actions"><button class="secondary" data-action="export-progress">⬇ Exportar respaldo</button><button class="ghost" data-action="import-progress">⬆ Importar respaldo</button></div></div><div class="section-head"><h2>Aprender puede ser divertido</h2></div><div class="feature-grid"><div class="feature"><span class="feature-icon">🧩</span><strong>Pequeñas misiones</strong><p>Aprende una habilidad y ponla en práctica con tu propio código.</p></div><div class="feature"><span class="feature-icon">⚡</span><strong>XP y progreso</strong><p>Supera lecciones, gana puntos y mantén tu racha de aprendizaje.</p></div><div class="feature"><span class="feature-icon">🧠</span><strong>Tutor CODI propia</strong><p>Clasifica tu idea y tus dudas, propone pasos y mejora con tus correcciones, sin conectarse a servidores.</p></div></div>
  ${state.projects.length>1?`<div class="section-head"><h2>Tus otros proyectos</h2></div><div class="path-list">${state.projects.filter(x=>x.id!==state.activeId).map(x=>`<button class="path-item" data-project="${escapeHTML(x.id)}"><span class="path-icon">${escapeHTML(paths[x.track]?.emoji||'💡')}</span><span><span class="path-name">${escapeHTML(x.goal)}</span><span class="path-description">${escapeHTML(fmtDate(x.createdAt))} · ${x.completed.length}/${x.lessons.length} lecciones</span></span><span class="path-end">Abrir →</span></button>`).join('')}</div>`:''}<p class="footer-note">CODI v0.8 · El clasificador es una IA pequeña entrenable con 54 temas técnicos, 70 lecciones base y misiones generadas y revisión estática de código, no un LLM. Los ejercicios se revisan mediante reglas didácticas de texto. Para ejecutar y probar tu proyecto de verdad debes usar su entorno (navegador, Roblox Studio, Minecraft, Python, etc.).</p>`}
function addGeneratedLessons(){
 const p=active();if(!p)return;
 const count=Number.isInteger(p.generatedCount)?p.generatedCount:0;
 if(count>=CodeQuestInfinite.max)return toast('Alcanzaste el límite de este proyecto. Puedes crear otro proyecto con una meta nueva.');
 const additions=CodeQuestInfinite.buildBatch(p,count,4);
 if(!additions.length)return toast('No encontré temas adecuados para esta ruta.');
 p.lessons.push(...additions);
 p.generatedCount=count+additions.length;
 save();navigate('route');toast(`¡${additions.length} misiones nuevas añadidas por el motor local!`);
}
function renderRoute(){const p=active();$('#breadcrumb').textContent='Aprender · Tu camino';if(!p)return `<div class="empty-state"><img src="assets/reaction-saludando.webp" alt="CODI te saluda" width="160"><strong>Aún no tienes una ruta.</strong><p>Cuéntale a CODI qué quieres programar para comenzar.</p><button class="primary" data-view="home">Crear mi primer curso</button></div>`;
 const next=p.lessons.find((l,i)=>!p.completed.includes(l.id)&&i>=(Number(p.placementStart)||0)&&routeUnlocked(p,i))||p.lessons.find((l,i)=>!p.completed.includes(l.id)&&routeUnlocked(p,i));
 const today=window.CodeQuestAcademy.exportData().daily;const date=todayLocal();const learned=(today?.date===date?Number(today.lesson)||0:0);const dailyGoal=window.CODINavigation?.getGoal()||2;
 const chooser=`<details class="course-switcher"><summary>📚 ${escapeHTML(paths[p.track].label)} <span>Cambiar curso ▾</span></summary><div class="course-list">${state.projects.map(course=>`<button data-project="${escapeHTML(course.id)}" class="${course.id===p.id?'current-course':''}">${escapeHTML(paths[course.track].emoji)} ${escapeHTML(course.goal.slice(0,68))} ${course.id===p.id?'✓':''}</button>`).join('')}<button data-view="home">✦ Crear un curso nuevo</button></div></details>`;
 const quick=`<div class="route-command"><div class="route-command-info"><span class="eyebrow">TU SIGUIENTE PASO</span><h2>${next?escapeHTML(next.title):'¡Ruta completada!'}</h2><p>${next?escapeHTML(next.objective):'Puedes repasar o generar nuevas lecciones.'}</p><div class="daily-goal" aria-label="Meta diaria: ${learned} de ${dailyGoal} lecciones"><span>🎯 Meta de hoy: <strong>${Math.min(learned,dailyGoal)}/${dailyGoal}</strong></span><div class="goal-track"><i style="width:${Math.min(100,learned/dailyGoal*100)}%"></i></div></div></div><div class="route-quick-actions">${next?`<button class="primary" data-lesson="${escapeHTML(next.id)}">▶ Continuar lección</button>`:'<button class="primary" data-view="practice">Repasar lecciones</button>'}<button class="secondary" data-view="practice">🎯 Practicar</button><button class="ghost" data-action="jump-current">↧ Mi nivel actual</button></div></div>`;
 return chooser+quick+CODIAdventure.renderRoute(p,{paths,projectSteps});}

function persistLessonDraft(){
 const p=active(),l=currentLesson(),editor=$('#student-code');
 if(p&&l&&editor&&p.drafts[l.id]!==editor.value){p.drafts[l.id]=editor.value;save();}
}
function openLesson(id){
 const p=active();if(!p)return;
 const idx=p.lessons.findIndex(l=>l.id===id);
 if(idx<0||!routeUnlocked(p,idx))return toast('Completa primero la lección anterior.');
 p.lessonId=id;selectedAnswer=null;codeFeedback=null;quizFeedback=null;
 const finished=isDone(p,id);
 if(finished)CODIQuiz.restart(p,p.lessons[idx]);
 lessonPhase='start';teachingStep=0;teachingLine=0;teachingChoice=null;teachingSolved=false;teachingFeedback='';teachingReady=finished;
 save();navigate('lesson');
}
function setLessonPhase(phase){
 const p=active(),l=currentLesson();if(!p||!l||!['start','learn','quiz','code','result'].includes(phase))return;
 if(phase==='result'&&!isDone(p,l.id))return;
 if(phase==='quiz'&&!teachingReady&&!isDone(p,l.id))return toast('Primero termina las cuatro pantallas de aprendizaje.');
 if(phase==='code'&&!CODIQuiz.passed(p,l)&&!isDone(p,l.id))return toast('Responde las preguntas antes de programar.');
 persistLessonDraft();lessonPhase=phase;render();
 window.scrollTo({top:0,behavior:'instant'});
 document.querySelector('.lesson-phase-heading')?.focus({preventScroll:true});
 CODITeam.syncLessonScene(l,lessonPhase,{track:p.track,quiz:CODIQuiz.get(p,l),codeOk:codeFeedback?.ok,done:isDone(p,l.id)});
}

function lessonCompletionPercent(p,l){
 if(lessonPhase==='result')return 100;
 if(lessonPhase==='start')return 0;
 if(lessonPhase==='result')return 100;
 if(lessonPhase==='learn')return 8+3*teachingStep;
 const q=CODIQuiz.get(p,l),total=CODIQuiz.makeQuestions(l).length;
 if(lessonPhase==='quiz')return q.reviewMode?82:Math.max(18,Math.min(82,Math.round(18+(q.passed?total:q.step+(q.validated?0.65:0))/Math.max(1,total)*64)));
 return codeFeedback?.ok?98:89;
}
function lessonStepMenu(p,l){
 const allowed=CODIQuiz.passed(p,l)||isDone(p,l.id);
 const quizAllowed=teachingReady||isDone(p,l.id);
 const order=[['learn','📘','Aprende'],['quiz','🧩','Preguntas'],['code','⌨️','Programa']];
 const activeIndex=order.findIndex(([id])=>id===lessonPhase);
 return `<nav class="lesson-steps" aria-label="Etapas de esta lección">${order.map(([id,icon,label],idx)=>`<button type="button" class="lesson-step ${lessonPhase===id?'active':''} ${activeIndex>idx?'passed':''}" data-lesson-phase="${id}" ${id==='code'&&!allowed?'disabled aria-label="Programa: primero responde las preguntas"':id==='quiz'&&!quizAllowed?'disabled aria-label="Preguntas: completa la clase guiada"':''} aria-current="${lessonPhase===id?'step':'false'}"><span class="lesson-step-number">${icon}</span><span>${label}</span>${activeIndex>idx?'<small>✓</small>':''}</button>`).join('')}</nav>`;
}
function lessonGuide(l){return `<details class="lesson-mentor-details"><summary>🤖 Mi tutor · Cambiar personaje o pedir ayuda <span aria-hidden="true">⌄</span></summary>${CODITeam.guideMarkup(l)}</details>`}
function updateTeachingStep(step){
 const p=active(),l=currentLesson();if(!p||!l||lessonPhase!=='learn')return;
 teachingStep=Math.max(0,Math.min(3,step));
 render();window.scrollTo({top:0,behavior:'instant'});
 document.querySelector('.teaching-heading')?.focus({preventScroll:true});
}
function teachingAction(control){
 const p=active(),l=currentLesson();if(!p||!l||lessonPhase!=='learn')return;
 if(control.hasAttribute('data-teach-prev'))return updateTeachingStep(teachingStep-1);
 if(control.hasAttribute('data-teach-next')){
   if(teachingStep===2&&!teachingSolved)return toast('Completa la práctica guiada para continuar.');
   if(teachingStep===3){teachingReady=true;setLessonPhase('quiz');return;}
   return updateTeachingStep(teachingStep+1);
 }
 if(control.hasAttribute('data-teach-line')){
  const line=Number(control.dataset.teachLine);if(!Number.isInteger(line))return;
  teachingLine=line;
  document.querySelectorAll('[data-teach-line]').forEach(x=>{const picked=Number(x.dataset.teachLine)===line;x.classList.toggle('selected',picked);x.setAttribute('aria-pressed',String(picked));});
  const source=String(l.example||'').split('\n').filter(x=>x.trim()).slice(0,8)[line];
  const target=document.querySelector('#teaching-line-note');if(target&&source!==undefined){
   target.querySelector('strong').textContent='Línea '+(line+1);
   target.querySelector('p').textContent=CODITeaching.explainLine(source,p.track);
  }
  return;
 }
 if(control.hasAttribute('data-teach-choice')){
   if(teachingSolved)return;
   teachingChoice=Number(control.dataset.teachChoice);teachingFeedback='';render();return;
 }
 if(control.hasAttribute('data-teach-check')){
  if(teachingChoice===null||teachingSolved)return;
  const sample=CODITeaching.sample(l);teachingSolved=teachingChoice===sample.answer;
  teachingFeedback=teachingSolved?'¡Excelente! Completaste el ejemplo. Ahora puedes avanzar.':'Todavía no. Revisa el ejemplo y prueba otra opción. No pierdes corazones.';
  render();return;
 }
}
function renderLesson(){
 const p=active(),l=currentLesson();if(!p||!l){view='route';return renderRoute()}
 $('#breadcrumb').textContent=`Lección · ${l.title}`;
 const i=p.lessons.findIndex(x=>x.id===l.id),done=isDone(p,l.id);
 const progress=CODIQuiz.get(p,l),percent=lessonCompletionPercent(p,l);
 const header=`<header class="lesson-focus-header"><button class="focus-close" data-view="route" aria-label="Salir de la lección y guardar el avance" title="Salir y guardar">✕</button><div class="lesson-progress-info"><span class="focus-title">${lessonPhase==='start'?'PREPARADO PARA EMPEZAR':lessonPhase==='result'?'¡LECCIÓN SUPERADA!':`LECCIÓN ${i+1} · ${progress.passed?'DESAFÍO FINAL':lessonPhase==='quiz'?(progress.reviewMode?`REPASO ${progress.reviewCursor+1}/${progress.reviewQueue.length}`:`PREGUNTA ${Math.min(progress.step+1,CODIQuiz.makeQuestions(l).length)}`):'APRENDE'}`}</span><div class="focus-progress" role="progressbar" aria-label="Progreso de la lección" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}"><i style="width:${percent}%"></i></div></div><span class="focus-hearts" aria-label="${progress.hearts} intentos disponibles">❤️ ${progress.hearts}/${CODIQuiz.MAX_HEARTS}</span></header>`;
 const intro=`<div class="lesson-intro compact-intro"><span class="eyebrow">${escapeHTML(paths[p.track]?.label||'PROGRAMACIÓN')} · ${l.xp} XP</span><h1 class="lesson-phase-heading" tabindex="-1">${escapeHTML(l.title)}</h1><p>${escapeHTML(l.objective)}</p></div>`;
 const start=`<div class="lesson-start-card lesson-stage"><img src="${window.CODI_IMAGES?.['reaction-motivando.webp']||'assets/reaction-motivando.webp'}" alt="CODI te da la bienvenida" class="lesson-start-mascot"/><span class="eyebrow">${done?'🔁 REPASO SIN XP EXTRA':'🟢 NUEVA LECCIÓN'}</span><h2>${escapeHTML(l.title)}</h2><p>${escapeHTML(l.objective)}</p><div class="lesson-start-facts"><span>📘 Explicación</span><span>🧩 ${CODIQuiz.makeQuestions(l).length} desafíos</span><span>⌨️ Código real</span></div><button type="button" class="primary lesson-start-button" data-lesson-phase="learn">${done?'Volver a practicar':'EMPEZAR LECCIÓN'} →</button><p class="lesson-start-note">Avanza a tu ritmo · Tutor y pistas gratis</p></div>`;
 const result=`<div class="lesson-results lesson-stage" role="status"><div class="lesson-results-star">🏆</div><div class="lesson-finale-cast" aria-label="El equipo CODI te felicita">${['codi','bita','buggo','lumina','rush','nexa'].map((name,i)=>`<img src="${window.CODI_IMAGES?.['avatar-'+name+'.webp']||'assets/'+(name==='codi'?'reaction-feliz.webp':'avatar-'+name+'.webp')}" alt="" style="--delay:${i*90}ms"/>`).join('')}</div><span class="eyebrow">LECCIÓN COMPLETADA</span><h2>¡Lo lograste!</h2><p>${escapeHTML(l.title)}</p><div class="lesson-results-stat"><div><strong>+${done?l.xp:0}</strong><small>XP por completar</small></div><div><strong>${Math.round(100*CODIQuiz.makeQuestions(l).length/Math.max(1,CODIQuiz.makeQuestions(l).length+(progress.misses||0)))}%</strong><small>Precisión</small></div><div><strong>${progress.misses||0}</strong><small>Errores corregidos</small></div></div><p class="lesson-results-detail">CODI y el equipo están orgullosos de tu avance. Guarda lo aprendido y continúa construyendo.</p><div class="lesson-results-actions"><button class="secondary" data-view="route">Volver al camino</button><button class="primary" data-action="next-lesson">${i===p.lessons.length-1?'Ir a mi ruta':'SIGUIENTE LECCIÓN →'}</button></div></div>`;
 const stepMenu=['start','result'].includes(lessonPhase)?'':lessonStepMenu(p,l);
 const scene=lessonPhase==='code'?CODITeam.lessonScene(l,lessonPhase,{track:p.track,quiz:progress,codeOk:codeFeedback?.ok,done:false}):'';
 const learn=`<div class="lesson-stage lesson-learn">${CODITeaching.render(l,teachingStep,{track:p.track,line:teachingLine,selected:teachingChoice,solved:teachingSolved,feedback:teachingFeedback,guide:CODITeam.guideId})}</div>`;
 const quiz=`<div class="lesson-stage lesson-questions"><div class="lesson-question-header"><span>🎮 HABLA Y APRENDE CON EL EQUIPO</span><p>El personaje te plantea un reto. Contesta, comprueba y observa su reacción.</p></div><section class="panel quiz-shell" id="codi-quiz-pane" aria-label="Cuestionario interactivo">${CODIQuiz.render(p,l)}</section>${lessonGuide(l)}<div class="lesson-mini-nav"><button class="ghost" data-lesson-phase="learn">← Volver a la explicación</button>${CODIQuiz.passed(p,l)?'<button class="primary" data-lesson-phase="code">Ir al editor →</button>':''}</div></div>`;
 const code=`<div class="lesson-stage lesson-program"><section class="panel lesson-editor-card"><div class="lesson-editor-heading"><div><span class="lesson-block-label">⌨️ DESAFÍO FINAL</span><h2>Programa lo que aprendiste</h2></div><span class="info-pill">Práctica guiada</span></div><p>Modifica el código y comprueba los elementos principales. La revisión no ejecuta tu programa.</p><label class="tiny-label" for="student-code">Tu código</label><textarea class="code-editor mt-12" id="student-code" spellcheck="false" autocomplete="off" autocapitalize="off" aria-label="Editor de código">${escapeHTML(p.drafts[l.id]??l.starter)}</textarea><div class="lesson-editor-toolbar"><button class="secondary" data-action="check-code">✓ Revisar código</button><button class="secondary" data-action="review-lesson-code">🔍 Analizar</button><button class="ghost" data-action="restore-code">↻ Reiniciar</button><button class="ghost" data-action="download-code">⬇ Descargar</button>${p.track==='web'&&['web1','web2','web3','web4','web6','web7','web8','web9','web10','web11','web12','web13','web14'].includes(l.id)?'<button class="ghost" data-action="preview-code">▶ Vista previa</button>':''}</div><div id="code-feedback" class="mt-12" role="status" aria-live="polite">${codeFeedback?feedbackHTML(codeFeedback):''}</div><pre class="review-result mt-12" id="expert-feedback" aria-live="polite">${escapeHTML(lastLessonReview||'')}</pre>${p.track==='web'?'<iframe id="web-preview" title="Vista previa segura del código" sandbox="allow-scripts" referrerpolicy="no-referrer" hidden></iframe>':''}</section>${lessonGuide(l)}<footer class="lesson-bottom-bar"><button class="ghost" data-lesson-phase="quiz">← Preguntas</button>${done?`<button class="primary" data-action="next-lesson">${i===p.lessons.length-1?'Volver a la ruta':'Siguiente lección →'}</button>`:`<button class="primary" data-action="finish-lesson">Terminar lección · +${l.xp} XP →</button>`}</footer></div>`;

 return `<div class="lesson-play lesson-flow phase-${lessonPhase}">${header}${['start','result'].includes(lessonPhase)?'':intro}${stepMenu}${scene}${lessonPhase==='start'?start:lessonPhase==='result'?result:lessonPhase==='quiz'?quiz:lessonPhase==='code'?code:learn}</div>`;
}
function feedbackHTML(result){return `<div class="feedback ${result.ok?'success':'warn'}">${result.ok?'✓ ':'↻ '}${escapeHTML(result.message)}</div>`}
function checkCode(){const p=active(),l=currentLesson();if(!p||!l)return false;const raw=$('#student-code').value;p.drafts[l.id]=raw;save();const normalized=stripComments(raw,p.track).toLowerCase();const missing=l.checks.filter(word=>!normalized.includes(word.toLowerCase()));const unchanged=raw.trim()===l.starter.trim();CodeQuestAI.recordAttempt(l.id,!unchanged&&!missing.length);codeFeedback=unchanged?{ok:false,message:'Primero modifica el código inicial para resolver el ejercicio.'}:missing.length?{ok:false,message:`Aún faltan estas piezas: ${missing.join(', ')}. ${l.hint}`}:{ok:true,message:'¡Bien! Encontramos las piezas clave. Esto no demuestra que el programa funcione: pruébalo en su entorno.'};$('#code-feedback').innerHTML=feedbackHTML(codeFeedback);CODITeam.guideFeedback(codeFeedback.ok,l);return codeFeedback.ok}
function updateQuiz(){
 const p=active(),l=currentLesson(),panel=$('#codi-quiz-pane');if(!p||!l||!panel)return;
 panel.innerHTML=CODIQuiz.render(p,l);window.CODIAccount?.schedule();
 const tracker=$('.focus-progress');if(tracker){const value=lessonCompletionPercent(p,l);tracker.setAttribute('aria-valuenow',String(value));const bar=tracker.querySelector('i');if(bar)bar.style.width=value+'%';}
 const health=$('.focus-hearts');if(health)health.textContent=`❤️ ${CODIQuiz.get(p,l).hearts}/${CODIQuiz.MAX_HEARTS}`;
 const subtitle=$('.focus-title'),quiz=CODIQuiz.get(p,l);if(subtitle&&lessonPhase==='quiz')subtitle.textContent=quiz.reviewMode?`REPASO DE ERRORES · ${quiz.reviewCursor+1}/${quiz.reviewQueue.length}`:`LECCIÓN · PREGUNTA ${Math.min(quiz.step+1,CODIQuiz.makeQuestions(l).length)}`;
}
function checkQuiz(){
 const p=active(),l=currentLesson();if(!p||!l)return false;
 const raw=$('#quiz-fill-answer')?.value;
 const result=CODIQuiz.check(p,l,raw);
 if(!result.ignored){
   CodeQuestAI.recordAttempt(l.id,result.ok);
   if(!result.ok)CODIAdventure.recordMistake(p.id,l.id,false);
   CODI?.react(result.ok?'orgulloso':'confundido',result.ok?'¡Bien! Respondiste correctamente.':'Revisa la pista e inténtalo de nuevo.');
   CODITeam.guideFeedback(result.ok,l);
 }
 updateQuiz();CODITeam.syncLessonScene(l,lessonPhase,{track:p.track,quiz:CODIQuiz.get(p,l),codeOk:codeFeedback?.ok,done:isDone(p,l.id)});return result.ok;
}
function quizAction(control){
 const p=active(),l=currentLesson();if(!p||!l)return;
 if(control.hasAttribute('data-quiz-actor-hint')){const session=CODIQuiz.get(p,l);if(!session.hint)CODIQuiz.hint(p,l);updateQuiz();return;}
 if(control.dataset.quizChoice!==undefined){CODIQuiz.select(p,l,Number(control.dataset.quizChoice));updateQuiz();return;}
 if(control.dataset.quizLine!==undefined){CODIQuiz.select(p,l,Number(control.dataset.quizLine));updateQuiz();return;}
 if(control.dataset.quizRemove!==undefined){CODIQuiz.remove(p,l,Number(control.dataset.quizRemove));updateQuiz();return;}
 if(control.hasAttribute('data-quiz-check')){checkQuiz();return;}
 if(control.hasAttribute('data-quiz-next')){
   const result=CODIQuiz.next(p,l);
   updateQuiz();
   if(result==='passed'){
      CODI?.react('celebrando','¡Respondiste todo! Ahora completa tu ejercicio de código.');CODITeam.guideFeedback(true,l,true);
      setLessonPhase('code');
   }
   return;
 }
 if(control.hasAttribute('data-quiz-hint')){CODIQuiz.hint(p,l);updateQuiz();return;}
 if(control.hasAttribute('data-quiz-refill')){CODIQuiz.refill(p,l);updateQuiz();return;}
}
function finishLesson(){
 const p=active(),l=currentLesson();if(!p||!l)return;
 if(!CODIQuiz.passed(p,l)&&!isDone(p,l.id)){toast('Contesta correctamente las preguntas antes de terminar la lección.');return}
 const codeOK=checkCode();if(!codeOK){toast('Todavía necesitas completar el desafío de código.');return}
 if(!isDone(p,l.id)){
   p.completed.push(l.id);state.xp+=l.xp;activity();CodeQuestAcademy.record('lesson');CODIAdventure.awardLesson(p.id,l.id);save();
   toast(`¡Misión superada! +${l.xp} XP ⚡`);
 }
 setLessonPhase('result');
 CODI?.react('celebrando','¡Lo conseguiste! Mira tus resultados y sigue aprendiendo.');
}
function showExpertReview(locationName){
 const p=active(),l=currentLesson();let code='',track=p?.track||'javascript';
 if(locationName==='lesson')code=$('#student-code')?.value||'';
 else{code=$('#expert-code')?.value||'';track=$('#expert-language')?.value||track;expertDraft=code;expertSelectedLanguage=track}
 const review=CodeQuestExpert.reviewCode(code,track);const formatted=CodeQuestExpert.formatReview(review);
 if(locationName==='lesson'){
   const out=$('#expert-feedback');if(out)out.textContent=formatted;
   lastLessonReview=formatted;
 }else{
   lastExpertReview=formatted;
   const out=$('#expert-review');if(out)out.textContent=formatted;
 }
}
function renderTutor(){const p=active();$('#breadcrumb').textContent='Tutor CODI · local';return `<button class="back-link" data-view="${p?'route':'home'}">← Volver</button><span class="eyebrow">🧠 IA PROPIA DE CODI · 100% LOCAL</span><h1 class="page-title" style="font-size:clamp(30px,4vw,46px);margin:10px 0 9px">Tu tutor de programación.</h1><p class="lead">Clasificador entrenable desde cero + base local de ${CodeQuestExpert.knowledgeCount} temas técnicos + revisión heurística de código. Todo sin API externa. No es un LLM generativo.</p><div class="lesson-layout"><div class="panel"><div class="space-between mb-20"><strong>💬 Tutor CODI</strong><span class="info-pill">Sin APIs · Sin internet</span></div><div class="chat-box" id="chat-box" aria-live="polite">${chat.length?chat.map(m=>`<div class="chat-message ${m.role==='user'?'user':'bot'}">${escapeHTML(m.text)}</div>`).join(''):`<div class="empty-state"><strong>¡Hola! Soy CODI, tu tutor 👋</strong>Pregúntame sobre ${escapeHTML(p?.goal||'tu proyecto')}. Aprendo a clasificar mejor las dudas si corriges mis respuestas.</div>`}</div><form id="tutor-form" class="mt-20"><label class="tiny-label" for="tutor-question">Tu pregunta</label><textarea class="ask-field mt-12" name="question" id="tutor-question" required maxlength="3000" placeholder="Ej.: ¿Cómo validar RemoteEvents de Roblox de manera segura?"></textarea><div class="actions mt-12"><button class="primary" type="submit">Preguntar a la IA ↗</button><button class="ghost" type="button" data-action="ask-hint">Pedir una pista</button></div></form><section class="panel expert-workbench"><div class="space-between"><h3>🛠️ Revisión profesional de código</h3><span class="info-pill">Análisis estático · sin ejecutar</span></div><p class="subtle">Pega un fragmento. El motor señalará patrones de riesgo y posibles errores con propuestas concretas. No sustituye un compilador ni valida toda la lógica.</p><label class="tiny-label" for="expert-language">Lenguaje</label><select id="expert-language" class="ai-select">${Object.entries(paths).map(([key,value])=>`<option value="${key}" ${key===(expertSelectedLanguage||p?.track||'javascript')?'selected':''}>${escapeHTML(value.label)}</option>`).join('')}</select><label class="tiny-label mt-12" for="expert-code">Código a revisar</label><textarea id="expert-code" class="code-editor mt-12" spellcheck="false" maxlength="60000" placeholder="Pega aquí tu código..." aria-label="Código para revisar">${escapeHTML(expertDraft)}</textarea><div class="actions mt-12"><button class="primary" type="button" data-action="review-tutor-code">Analizar mi código ✓</button></div><pre class="review-result mt-12" id="expert-review" aria-live="polite">${escapeHTML(lastExpertReview||'Aquí aparecerán los problemas detectados y recomendaciones.')}</pre></section>${lastTutorQuestion?`<div class="trainer"><strong>¿Te entendió correctamente?</strong><p class="subtle">Ayúdala a aprender qué clase de respuesta buscabas. Tu corrección se guarda en el navegador.</p><div class="actions"><label class="tiny-label" for="teach-intent">Quería una respuesta de tipo:</label><select id="teach-intent" class="ai-select">${Object.entries(CodeQuestAI.intentLabels).map(([key,label])=>`<option value="${key}" ${key===lastTutorIntent?'selected':''}>${escapeHTML(label)}</option>`).join('')}</select><button class="secondary" data-action="teach-intent">Enseñar</button><button class="ghost" data-action="like-answer">Me ayudó ✓</button></div></div>`:''}</div><aside class="lesson-aside"><div class="panel panel-accent"><h3>🔒 IA hecha desde cero</h3><p>Clasificador local + ${CodeQuestExpert.knowledgeCount} artículos técnicos originales + analizador de patrones. Corrige la clasificación con tus ejemplos. No usa ChatGPT, Gemini, servidores ni modelos externos.</p><span class="badge">Modelo pequeño y offline</span></div><div class="panel"><h3>💡 Preguntas técnicas</h3><div class="path-list"><button class="choice" data-prompt="¿Cómo validar RemoteEvents en Roblox?">Seguridad en Roblox</button><button class="choice" data-prompt="¿Cómo crear un manifest JSON de Bedrock?">Add-ons Bedrock</button><button class="choice" data-prompt="¿Qué es async await en JavaScript?">JavaScript asíncrono</button><button class="choice" data-prompt="¿Cómo escribir pruebas unitarias?">Pruebas profesionales</button><button class="choice" data-prompt="Explícame la lección actual">Explícame esta lección</button><button class="choice" data-prompt="Dame una pista para el ejercicio">Dame una pista</button><button class="choice" data-prompt="¿Cuál es el siguiente paso?">¿Qué hago después?</button><button class="choice" data-prompt="¿Cómo compruebo si funciona?">¿Cómo pruebo mi código?</button><button class="choice" data-prompt="¿Qué funciones puedo agregar a mi proyecto?">Ideas para mi proyecto</button></div></div></aside></div>`}
function askTutor(event){event.preventDefault();const input=$('#tutor-question'),question=input?.value.trim();if(!question)return;lastTutorQuestion=question;const result=CodeQuestAI.tutor(question,{project:active(),lesson:currentLesson()});CodeQuestAcademy.record('ai');lastTutorIntent=result.intent;chat.push({role:'user',text:question});chat.push({role:'bot',text:result.text});if(chat.length>32)chat=chat.slice(-32);render();$('#chat-box')?.scrollTo(0,$('#chat-box').scrollHeight)}
function teachTutor(){if(!lastTutorQuestion)return;const label=$('#teach-intent')?.value;if(!label||!CodeQuestAI.teachIntent(lastTutorQuestion,label))return toast('No pude guardar la corrección.');const result=CodeQuestAI.tutor(lastTutorQuestion,{project:active(),lesson:currentLesson()});lastTutorIntent=result.intent;chat.push({role:'bot',text:'Gracias por enseñarme. Ahora intento responder mejor:\n'+result.text});if(chat.length>32)chat=chat.slice(-32);render();toast('La IA aprendió de tu corrección en este dispositivo.')}
function trainProjectTrack(){const p=active();if(!p)return;const selected=$('#correct-track')?.value;if(!paths[selected])return;if(selected===p.track)return toast('Tu proyecto ya usa esa ruta.');if(p.completed.length&&!confirm('Al cambiar de ruta se reiniciarán las lecciones de este proyecto. ¿Continuar?'))return;if(!CodeQuestAI.teachTrack(`${p.goal} ${p.purpose}`,selected))return;state.xp=Math.max(0,state.xp-p.completed.length*50);p.track=selected;p.lessons=personalizedLessons(selected,p.goal,p.purpose);p.completed=[];p.drafts={};p.lessonId=null;save();navigate('route');toast('Ruta corregida. La IA aprendió esta relación.')}

function render(){updateStats();const av=document.querySelector('.avatar');if(av&&!window.CODIOnboarding?.profile)av.textContent=CodeQuestAcademy.exportData().avatar;let html;if(view==='home')html=renderHome();else if(view==='route')html=renderRoute();else if(view==='lesson')html=renderLesson();else if(view==='tutor')html=renderTutor();else if(view==='team'){$('#breadcrumb').textContent='Equipo CODI · Historia tecnológica';html=CODITeam.render();}else if(view==='settings'){$('#breadcrumb').textContent='Ajustes';html=window.CODINavigation.renderSettings();}else if(CodeQuestAcademy.nav[view])html=CODITeam.viewGuide(view)+CodeQuestAcademy.render(view);else{view='home';html=renderHome()}$('#main').innerHTML=html;document.body.classList.toggle('lesson-mode',view==='lesson');document.body.dataset.lessonPhase=view==='lesson'?lessonPhase:'';window.CODINavigation?.sync(view);window.CODIOnboarding?.refresh();document.querySelectorAll('.nav-link,.bottom-link').forEach(b=>b.classList.toggle('active',b.dataset.view===(view==='lesson'?'route':view)))}
function eventHandler(event){const control=event.target.closest('[data-teach-prev],[data-teach-next],[data-teach-line],[data-teach-choice],[data-teach-check],[data-lesson-phase],[data-guide-action],[data-quiz-choice],[data-quiz-line],[data-quiz-remove],[data-quiz-check],[data-quiz-next],[data-quiz-hint],[data-quiz-refill],[data-quiz-actor-hint],[data-team-id],[data-team-reaction],[data-team-answer],[data-team-restart],[data-action],[data-view],[data-project],[data-lesson],[data-answer],[data-prompt]');if(!control)return;if([...control.attributes].some(a=>a.name.startsWith('data-teach-'))){teachingAction(control);return;}if(control.dataset.lessonPhase){setLessonPhase(control.dataset.lessonPhase);return;}if([...control.attributes].some(a=>a.name.startsWith('data-quiz-'))){quizAction(control);return;}if(control.dataset.guideAction){CODITeam.guideAction(control.dataset.guideAction,currentLesson());return}if(control.dataset.teamId){CODITeam.select(control.dataset.teamId);render();return}if(control.dataset.teamReaction){CODITeam.react(control.dataset.teamReaction);render();return}if(control.dataset.teamAnswer!==undefined){const r=CODITeam.answer(control.dataset.teamOwner,Number(control.dataset.teamAnswer));render();if(r.finished)toast('¡Reto completado! +15 XP la primera vez.');return}if(control.dataset.teamRestart){CODITeam.restart(control.dataset.teamRestart);render();return}if(control.dataset.view){navigate(control.dataset.view);return}if(control.dataset.project){setActive(control.dataset.project);return}if(control.dataset.lesson){openLesson(control.dataset.lesson);return}if(control.dataset.answer!==undefined){selectedAnswer=Number(control.dataset.answer);quizFeedback=null;document.querySelectorAll('[data-answer]').forEach(el=>el.classList.toggle('picked',Number(el.dataset.answer)===selectedAnswer));$('#quiz-feedback').innerHTML='';return}if(control.dataset.prompt){const field=$('#tutor-question');if(field){field.value=control.dataset.prompt;field.focus()}return}switch(control.dataset.action){case 'more-lessons':addGeneratedLessons();break;case 'review-tutor-code':showExpertReview('tutor');break;case 'review-lesson-code':showExpertReview('lesson');break;case 'train-track':trainProjectTrack();break;case 'teach-intent':teachTutor();break;case 'like-answer':CodeQuestAI.like();toast('Gracias, guardé tu valoración localmente.');break;case 'focus-create':$('#create-section')?.scrollIntoView({behavior:'smooth'});$('#goal')?.focus({preventScroll:true});break;case 'jump-current':document.querySelector('.map-node.node-current')?.scrollIntoView({behavior:'smooth',block:'center'});break;case 'check-code':checkCode();break;case 'download-code':downloadCode();break;case 'preview-code':previewCode();break;case 'export-progress':exportProgress();break;case 'import-progress':$('#import-file')?.click();break;case 'delete-project':deleteProject();break;case 'check-quiz':checkQuiz();break;case 'restore-code':{const l=currentLesson(),p=active();if(l&&p){$('#student-code').value=l.starter;p.drafts[l.id]=l.starter;codeFeedback=null;lastLessonReview=null;save();$('#code-feedback').innerHTML='';toast('Editor reiniciado.')}break}case 'finish-lesson':finishLesson();break;case 'next-lesson':{const p=active(),l=currentLesson();if(!p||!l)return;const next=p.lessons[p.lessons.findIndex(x=>x.id===l.id)+1];next?openLesson(next.id):navigate('route');break}case 'ask-hint':{const field=$('#tutor-question');if(field){field.value='Dame una pista pequeña para el ejercicio actual';field.focus()}break}}}
document.addEventListener('click',eventHandler);
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='quiz-fill-answer'&&!e.isComposing){e.preventDefault();checkQuiz()}});
document.addEventListener('submit',event=>{if(event.target.id==='create-form')createProject(event);if(event.target.id==='tutor-form')askTutor(event)});
document.addEventListener('change',event=>{if(event.target.id==='expert-language')expertSelectedLanguage=event.target.value;if(event.target.id==='teaching-guide-select'){CODITeam.chooseGuide(event.target.value,currentLesson());render();return;}if(event.target.id==='guide-selector'||event.target.id==='exercise-guide-select'){const p=active(),l=currentLesson();CODITeam.chooseGuide(event.target.value,l);if(p&&l&&lessonPhase==='quiz')CODITeam.refreshExerciseMoment(l,CODIQuiz.current(p,l),CODIQuiz.get(p,l));}});
document.addEventListener('input',event=>{if(event.target.id==='quiz-fill-answer'){const btn=document.querySelector('[data-quiz-check]');if(btn)btn.disabled=!event.target.value.trim();}if(event.target.id==='expert-code')expertDraft=event.target.value;if(event.target.id==='student-code'){const p=active(),l=currentLesson();if(p&&l){p.drafts[l.id]=event.target.value;clearTimeout(lessonSaveTimer);lessonSaveTimer=setTimeout(save,250);codeFeedback=null;$('#code-feedback').innerHTML=''}}});
$('#menu-btn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
document.querySelector('#import-file')?.addEventListener('change',async event=>{await importProgress(event.target.files?.[0]);event.target.value=''});
if('serviceWorker' in navigator&&['https:','http:'].includes(location.protocol))navigator.serviceWorker.register('./sw.js').catch(()=>{});
window.CodeQuestApp={get state(){return state},active,currentLesson,get paths(){return paths},save,rerender:render,navigate,openLesson,beginOnboardCourse,downloadText,toast,markActivity:activity,cloudSnapshot,loadCloudSnapshot};
render();
